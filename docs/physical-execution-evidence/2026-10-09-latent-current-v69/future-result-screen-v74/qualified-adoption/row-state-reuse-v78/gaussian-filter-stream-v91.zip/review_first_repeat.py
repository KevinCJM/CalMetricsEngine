"""Independent audit of a completed full-chain repetition (never starts one)."""
from pathlib import Path
import hashlib
import json
import statistics
import argparse

D = Path(__file__).resolve().parent
CASES = {'hmm100k_d32_k12_F': (100000, 32, 12, 'F'),
         'hmm100k_d32_k12_C': (100000, 32, 12, 'C'),
         'hmm250k_d8_k8_C': (250000, 8, 8, 'C'),
         'hmm250k_d8_k8_F': (250000, 8, 8, 'F')}
parser = argparse.ArgumentParser()
parser.add_argument('case', nargs='?', choices=CASES, default='hmm100k_d32_k12_F')
args = parser.parse_args()
rows, width, states, order = CASES[args.case]
P = D / 'repeat-performance' / args.case


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


s = json.loads((P / 'state.json').read_text())
a = json.loads((P / 'analysis.json').read_text())
assert s['status'] == 'passed_complete_case_not_adopted'
assert a['status'] == 'complete_repetition_not_adopted'
assert not s['production_modified'] and not s['goal_complete']
assert s['case'] == a['case'] == dict(model='hmm', n=rows, d=width, k=states,
                                    iterations=60, layout=order, rounds=3,
                                    all_outputs=13, cpu_budget=1)
assert sha(s['driver']) == s['driver_sha256']
assert s['candidate_build_id'] == a['build_id']
records = {(x['metric'], x['backend']): x for x in s['records']}
assert len(records) == len(s['records']) == 9
assert set(records) == {(m, b) for m in ['time', 'heap', 'rss']
                       for b in ['actual', 'candidate', 'njit']}
reference = records['time', 'actual']['raw']['verification']
baseline_names = [x['name'] for x in reference['all_thirteen_outputs']]
assert len(set(baseline_names)) == 13
summaries = []
for (metric, backend), record in records.items():
    assert sha(record['log']) == record['log_sha256']
    raw = json.loads(Path(record['log']).read_text().splitlines()[-1])
    assert raw == record['raw']
    v = raw['verification']
    assert v['status'] == 'passed'
    assert [x['name'] for x in v['all_thirteen_outputs']] == baseline_names
    assert v['input_hashes'] == reference['input_hashes']
    assert len(v['input_hashes']) == 6 and len(v['old_result_hashes']) == 13
    assert v['input_unchanged'] and v['old_outputs_unchanged']
    assert v['two_generation_and_input_nonalias']
    assert v['mathematical_invariants'] == reference['mathematical_invariants']
    assert all(x['max_absolute_error'] <= 0.000049
               for x in v['all_thirteen_outputs'])
    if backend != 'njit':
        assert raw['build_id'] == s[backend + '_build_id']
        assert raw['audit']['cpu_budget'] == raw['audit']['cpu_tokens'] == 1
        assert v['old_result_hashes'] == reference['old_result_hashes']
    if (metric, backend) != ('time', 'actual'):
        parity = raw['post_measurement_parity']
        assert parity['status'] == 'passed' and len(parity['outputs']) == 13
        for x in parity['outputs']:
            assert x['max_abs_difference'] <= 0.000049
            if backend != 'njit' or x['dtype'] == 'int64':
                assert x['exact_required'] and x['max_abs_difference'] == 0
            if backend != 'njit':
                assert x['sha256'] == reference['old_result_hashes'][x['output']]
    if metric == 'time':
        assert len(raw['seconds']) == 3
        assert statistics.median(raw['seconds']) == raw['median_seconds']
    elif metric == 'heap':
        assert set(raw['stages']) == {'0', '1', '2'}
        assert all(x['table_overflows'] == 0 for x in raw['stages'].values())
        assert raw['warm_peak_bytes'] == raw['stages']['2']['peak_bytes']
    else:
        assert raw['warm_incremental_rss_bytes'] == raw['warm_peak_bytes'] - raw['baseline_bytes']
    summaries.append(dict(metric=metric, backend=backend, log_sha256=record['log_sha256'],
                          max_error=max(x['max_absolute_error'] for x in v['all_thirteen_outputs'])))

for field, metric, key in [('seconds', 'time', 'median_seconds'),
    ('tracked_heap_bytes', 'heap', 'warm_peak_bytes'), ('rss_total_bytes', 'rss', 'warm_peak_bytes'),
    ('rss_baseline_bytes', 'rss', 'baseline_bytes'), ('rss_incremental_bytes', 'rss', 'warm_incremental_rss_bytes')]:
    assert a[field] == {b: records[metric, b]['raw'][key]
                       for b in ['actual', 'candidate', 'njit']}
audits = {}
for backend in ['actual', 'candidate']:
    chunks = records['time', backend]['raw']['audit']['native_chunks']
    audits[backend] = {k: sum(x[k] for x in chunks) for k in [
        'algorithm_copy_bytes', 'numeric_arena_bytes', 'operator_workspace_capacity_bytes',
        'eigen_density_calls', 'gaussian_filter_streams', 'root_copy_bytes', 'input_copy_bytes']}
assert audits['candidate']['gaussian_filter_streams'] == 1
assert audits['candidate']['input_copy_bytes'] == audits['actual']['input_copy_bytes'] == 0
out = dict(status='passed_independent_complete_repeat_audit_not_adopted',
    case=s['case'], build_id=a['build_id'], analysis_sha256=sha(P / 'analysis.json'),
    state_sha256=sha(P / 'state.json'), records=summaries, measurements=a,
    native_audits=audits,
    comparisons={field: {
        'candidate_minus_actual': values['candidate'] - values['actual'],
        'candidate_minus_njit': values['candidate'] - values['njit'],
        'candidate_over_actual': values['candidate'] / values['actual'],
        'candidate_over_njit': values['candidate'] / values['njit']}
        for field, values in a.items() if field.endswith('_bytes') or field == 'seconds'},
    decision='Hold adoption for all four complete repetitions and the workload-level timing/memory tradeoff review. This is one generated full-algorithm fixture, not whole-engine or deployed business acceptance.',
    precision='All thirteen C++ outputs byte-identical to actual reference; NI float tails within 0.000049 and discrete outputs exact.',
    memory_scope='Tracked malloc excludes stack/mmap/unintercepted zones. Sampled RSS includes baseline and allocator retention. Copy counters are cumulative, not measured peak memory.',
    production_modified=False, goal_complete=False)
dest = D / ('first-wide-f-complete-reviewed.json' if args.case == 'hmm100k_d32_k12_F'
            else args.case + '-complete-reviewed.json')
out['reviewer_sha256'] = sha(__file__)
dest.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k: out[k] for k in ['status', 'case', 'comparisons', 'native_audits']}))
