# V91: borrow completed F roots without changing layout or mathematics

## Verified reason and preserved evidence

V90 dfcfc5c passed24 of31 new regressions;7 memory assertions failed. All
mathematical/status/ownership assertions reached before those failures passed.
Four failures were F-result cases: the external input view was admitted, but
root_c deliberately declined normalization reuse. The complete D8/K8 F case
still copied36968320 bytes versus under8MiB for C. Two D4/K12 failures used an
inapplicable universal8MiB bound; its C control also copied12010112 bytes.
Do not present V90 as accepted; its original source, wheel and failures remain.

## Dependency, memory and ownership proof

Existing structural row_subview_same_tree recognizes only identical arithmetic
and broadcast trees rooted in the same raw take; the full root must have a lower
node ID and its unique direct writer must have completed. Keep this proof, all
index/rank/dtype/shape/slot bounds, external physical-span overlap checks,
per-call index content validation, strict/non-isolated scope and original
prepare calls. Allow that already independent root to have C or F continuous
storage. Retain its actual strides and advance by first*source.stride0.
The selected value remains a read-only logical view. Neither prior-call results
nor external inputs are writable scratch. Current-root backing outlives every
consumer; the existing fit loan ignores non-arena backing. No new allocation,
kernel, public operator, semantic DAG edge, output or numerical algorithm exists.

The same conservative arena planner and existing minimum three-history guard
continue to cover reservations; don't eliminate a history simply to reduce
reported memory. Padding, reverse/overlap/broadcast backing, mismatched interval
geometry and unproved indices retain their supported materialized path.
Worker request30/response29 rejects old admission before decode/shared attach.

## Qualification and complete performance

First run the31 row/error/layout/transport/retained-result regressions and native
tests plus affected graph/fit/budget/ownership suites. If these pass, screen the
complete F250000/D8/K8 HMM60 chain against current0ebc and warmed NJIT using the
frozen driver, all13 outputs, CPU1, owned input preparation and retained old
generation. Three warm epochs per fresh time/heap/RSS process, rotated backend
order, full canonical parity and independent invariants; no concurrent compute.
The D8/K8 <8MiB copy assertion must pass in both C/F; the D4/K12 case preserves
its existing3*training_count*K*8 history bound and canonical workspace saving.
No value/status/ownership/error assertion is relaxed.

Only candidates with full-request practical benefit proceed to full normal,
related sanitizer and library-OFF qualification, repeat complete C/F/wider
measurements, actual source adoption and a rebuilt production wheel comparison.
A private probe isn't adoption; broader matrix/solver/frontier/exploration and
the whole-engine goal remain open. Preserve source/package and failed evidence.

## Discipline and Excel

Applies computation D1,D5,D6,D8 and Excel X1,X4,X9,X10. Layout changes keep the
same logical axes and arithmetic, consumer range and reduction order. Logical
Excel formulas and mathematical parameters don't change; normal requests don't
call or retain Excel work. Related export numerical/structural regressions are
required for adoption; no claim of fresh desktop Excel recalculation is made.
No repository edits, commit/push, PR or platform service migration in this trial.
