# V91 current review and evidence boundary

The current build is723c06b38e087d4ec82a6830c39420a56177125de79c3908cf04f130ffeb5bc6.
The wheel SHA is c3c99b9eab5e16467eb7cb0e3b6c49f4b8678ea1cea424f034829b1e9bf8f740.
All25 installed package payload files match the wheel; Python payload matches
the frozen source.93 native source/build files and202 test source files are pinned.

## New physical change

The new geometry rule preserves the existing same-tree, per-call index,
dtype/shape, interval, complete external-span overlap and completed unique-root
proofs. It permits positive continuous F input backing and C/F independent roots.
Row views retain original strides and advance by the logical row stride. There
is no numerical cache, input mutation, new logical operator, modified fitting
algorithm, narrower output or altered stopping criterion. Public selected roots
still keep independent storage. Unsupported geometry retains materialization.
The existing minimum-three-history guard and arena planner are unchanged.
Worker request30/response29 rejects prior admission before decode/shared attach.

The private V90 external-only variant failed7 memory checks and is retained as
rejected evidence. The F-root gap is now covered. Its D4/K12 universal8MiB
expectation was invalid even for the original C case; the original three-history
bound is retained there. The D8/K8 C/F8MiB copy regression assertion still applies.
No mathematical, error, status, dtype/shape or ownership assertion was weakened.

## Completed acceptance

31 new cases passed; these are a subset of2385 unique related normal Python
cases. The four explicit nested-budget cases are also a subset. Native9/9 passed.
Source, installed payload, original repository hashes and Git states were checked.

The fresh F250000/D8/K8 HMM60 screen has9 terminal records: separate heap,
time and RSS children for current0ebc, V91 and warmed NJIT. All13 outputs match
the current native canonical values byte-for-byte; NJIT float tails and independent
probability/variance invariants pass. Exact states/order/iterations, unchanged
owned inputs, retained old results and cross-generation nonalias checks pass.
SameCPU1, owned input preparation and all output lifetimes are included; definition
construction, JIT and post-measurement validation are excluded.Three warm epochs
per process and rotated backend order; no competing native build/test/benchmark.

| Complete metric | Current0ebc | V91 | Warm NJIT |
| --- | ---: | ---: | ---: |
| Median seconds |12.814144291|12.743439292|31.162566125|
| Tracked heap peak bytes |150815242|118816158|136261480|
| RSS total peak bytes |263831552|229474304|318275584|
| RSS baseline bytes |124764160|126599168|159514624|
| RSS increase over baseline bytes |139067392|102875136|158760960|

V91 removes32000000 algorithm-copy bytes,16000000 arena bytes and16000000
operator workspace bytes versus current0ebc in this complete case. Observed time
versus current C++ is effectively unchanged; don't claim a substantial new speed
gain from the0.071s difference. Compared with NJIT, the complete time benefit is
about2.45x, tracked heap falls12.8% and total RSS falls27.9%. RSS and tracked heap
have different coverage and must not be added. Tracked malloc excludes stack,
mmap and unintercepted zones; sampled RSS includes baseline and allocator retention.
The input is a generated deterministic platform-algorithm fixture, not live
business data or a deployed platform qualification.

## Pending

All162 top-level normal modules now passed:17066 unique Python cases (2385 related +14681 other), with9 native tests and zero failures/errors/skips. Coverage and unique XML IDs, source pins and all25 wheel payload files were independently checked in all-normal-reviewed.json. Affected ASan+UBSan acceptance now passed:2385 related Python and9 native tests, same test IDs as normal, zero failures/errors/skips and all25 installed wheel payloads checked. Leak detection remains disabled. Library-OFF acceptance now passed:2385 related Python and9 native tests, zero failures/errors/skips, all25 payloads and OFF compiler flags checked. The five serial full-safety jobs are terminal and passed. No repeat measurements or actual adoption are implied by those results.
The sanitizer's leak detector is disabled; no whole-suite sanitizer or leak-free
claim. Repeat complete C/F and wider chain measurements remain necessary for
adoption.Only after those checks: review all four native differences relative to
the actual project, synchronize authoritative documentation, adopt into actual
source, build an actual package and repeat the fair full-chain comparison.

Actual project source/tests/docs remain unchanged. Graph/direct output contracts,
Excel mathematical recipes and normal-request Excel isolation are unchanged;
related export regressions passed, no fresh desktop Excel recalculation claimed.
Broader long-K matrix, solver/frontier/exploration coverage and substantial
whole-engine benefits remain open. No commit/push, PR or service migration.

## Combined change relative to the actual project

Reviewed the complete four-file native diff in native-actual-diff.patch, not only
the two incremental V91 files. The shared maxD32/maxK16 constants agree with
stream eligibility, validation and replay. Stream validation still visits every
row at the original producer position before ordered filter replay; errors are
not deferred into a later consumer. density_rows receives the original source
row extent during128-row replay so F/overlapping inputs keep the full-operation
library selection and feature-reduction order.

The history guard uses the same arena planner in a nonrecursive unrestricted
mode. It admits all possible row-view and stream elisions for a lower bound;
declining any elision increases slot maxima. New stream geometries require
three available NK histories, allowing one uniquely unpublished scatter root
when eligible. The shared future-root proof is reused at actual fit execution;
byte-span, overlap, alignment, save/restore and supported-scope guards remain
there. Current independent completed F roots remain outside writable arena
loans; selected views retain logical strides and bounds. Unsupported layouts,
indices and error scopes keep the canonical materialized route.

Actual0ebc source uses request26/response25. Candidate request30/response29
rejects the intermediate row/history admission generations before shared
attach. The earlier working note27/26 was inaccurate; don't rewrite historical
26/25 documentation as27/26. Update current protocol claims only on adoption.
No new operator, DAG semantics, iterative algorithm, output or precision policy
is introduced by these four files. Current-source adoption remains pending.

The frozen full driver retains13 outputs and one previous generation, owns
identical six-input copies in both implementations, fixes all backend core
budgets to1, excludes definitions/JIT and post-run checks, and verifies all
input hashes, exact discrete results, mathematical probability/variance
invariants and cross-generation/input nonalias. New repeat_complete.py covers
C250k/D8/K8, F250k/D8/K8 and C/F100k/D32/K12 in fresh heap/time/RSS processes.
Its four case plan checks passed. All nine fresh wider-F measurements now completed;
the independent full-record audit passed in first-wide-f-complete-reviewed.json.
Two cases are complete; the remaining F250k/D8/K8 and C100k/D32/K12 cases are running serially. The full safety gate,
source/wheel payload and benchmark/probe pins remain prerequisites.
Generated algorithm fixtures still do not prove live-business deployment.

F100k/D32/K12 was added because current density_rows uses grouped Eigen
state lanes for C-contiguous D>=32/K divisible by4, while its F column route
currently requiresK<=8. A borrowed F root therefore need not have the same
physical-library path as a copied C training matrix. This is a verified
dispatch boundary, not evidence of a measured complete regression. The full
F wide model must be measured before general adoption; don't infer its
performance from the accepted D8/K8 F case or force C as a universal layout.

## Completed wider-F repetition: admission tradeoff still under review

Fresh CPU1 100000x32/K12 F input, HMM60 plus GMM30 pretraining, all thirteen
outputs and two retained result generations: actual C++ 13.475452583 seconds,
candidate 14.160757625, warmed NJIT 42.949316583. Tracked malloc peaks are
165194034/136376694/144136024 bytes; total RSS peaks are
287473664/257490944/501825536 bytes (actual/candidate/NI).
The candidate is 0.685305 seconds (5.09%) slower than actual C++ in this
repetition, while saving 28817340 tracked-heap bytes and 29982720 total-RSS
bytes. This is a material memory improvement, not a new speed improvement.
Compared with NI, total time falls 67.03%, tracked heap 5.38%, and total RSS
48.69%. Baseline and incremental RSS are recorded separately in the audit.

All nine raw logs match their recorded SHA256 and parsed measurement records;
all three metrics verify six identical input payloads, thirteen outputs,
mathematical invariants, exact discrete values and untouched independent old
results. All C++ output bytes agree with the actual reference; the largest
NI float tail is about 4.12e-11. Tracked-heap tables report zero overflows.
Native audit confirms algorithm_copy_bytes 434613888 -> 2637216, arena
49008288 -> 27408288 and operator_workspace_capacity_bytes
14419168 -> 34624. These counters do not replace measured peak memory.
The current Eigen-density dispatch changes from 35252 calls to zero; stream
count changes from zero to one. Do not hide that path and timing change.

Hold adoption until the remaining C/F D8/K8 and C D32/K12 complete repetitions
and workload-level tradeoff review. Production source remains unchanged.
The long-K case and other major platform chains remain open.

## Completed C250k/D8/K8 repetition

The second nine-measurement case and independent raw-record audit passed.
Actual/candidate/NI time is12.793933833/12.856574250/31.168567625 seconds;
tracked heap126815942/118816158/136261480 bytes; totalRSS
235552768/230129664/325304320 bytes. Candidate vs actual: +0.062640 seconds
(0.49%), -7999784 tracked-heap bytes and -5423104 totalRSS bytes. This is
essentially unchanged time with less workspace, not a significant new speed
win. Against warmed NI, candidate time is58.75% lower, tracked heap12.80%
lower and totalRSS29.26% lower. Capacity reduction is8000000 arena bytes;
algorithm_copy_bytes remains6508320, not zero. Both heap and RSS are
separately measured and all thirteen native outputs are bit-identical.
All input/old-result/nonalias/CPU checks pass. The remaining two repeats
and actual-source adoption/rebuild are pending. Broader goal stays open.

## Fresh F250k complete repeat

The independent nine-record audit passed for the fresh F250k/D8/K8 HMM60 complete chain. Same six owned inputs, all thirteen outputs, CPU1 and two retained result generations. Native results are byte-identical to the actual reference; NI float tails/discrete results and ownership invariants passed.

seconds: {"actual": 12.828174833004596, "candidate": 12.720994417002657, "njit": 31.118971041985787}.
tracked_heap_bytes: {"actual": 150815242, "candidate": 118816158, "njit": 136261480}.
rss_total_bytes: {"actual": 262225920, "candidate": 228933632, "njit": 326664192}.
rss_baseline_bytes: {"actual": 122208256, "candidate": 122994688, "njit": 158941184}.
rss_incremental_bytes: {"actual": 140017664, "candidate": 105938944, "njit": 167723008}.

Compared with actual C++: -0.107s (effectively same), tracked heap -31,999,084 bytes and total RSS -33,292,288 bytes. Compared with warmed NI: 59.12% less complete time, 12.80% less tracked heap and 29.92% less total RSS. Copy counters are cumulative, not peak memory. This third repeat does not yet authorize adoption: the wide C repeat remains live, and the wide F +0.685s versus actual tradeoff remains explicit.
