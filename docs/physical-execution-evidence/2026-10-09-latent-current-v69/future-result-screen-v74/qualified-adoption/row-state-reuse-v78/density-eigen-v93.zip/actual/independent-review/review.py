"""Read-only audit of terminal actual-worktree V93 complete request evidence.

Standard library only: no numerical import, compilation, pytest, or benchmarks.
Writes this independent review directory only. Run after the owner confirms the
single heavy pipeline is terminal; --prepare records static driver provenance.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import statistics
import time
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
D = Path('/private/tmp/calmetrics-f-density-eigen-v93-20261010')
A = D / 'adoption'
R = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
DRIVER = Path('/private/tmp/calmetrics-gaussian-filter-stream-v85-20261009/r2/benchmark.py')
PROBE = Path('/private/tmp/calmetrics-f-coeff-v68-20261008/r5/heap_probe.dylib')
IDS = {'before': '723c06b38e087d4ec82a6830c39420a56177125de79c3908cf04f130ffeb5bc6',
       'actual': '79b494c5014e66ff1ded4c17ce46d0563018a5ffb551c0c40875bcda92045663'}
NAMES = ['state', 'score', 'confidence', 'probabilities', 'initial_means',
         'component_order', 'iterations', 'pretrain_iterations', 'standardized',
         'model_weights', 'model_means', 'model_variances', 'model_transition']
INPUT_NAMES = {'raw', 'positions', 'valid', 'uniform', 'reverse_order', 'transition_template'}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def preparation():
    assert sha(DRIVER) == '4e5d940ff55ab2028a64033b0221d68f9974b0a627edd855706ee64e14ce4f75'
    assert sha(PROBE) == '6f6722a0d98e501bc935fb5178facf251c9292a76b3cd8f7c397ef59a5899bb5'
    plan = read(A / 'plan.json')
    assert sha(R / 'tests/latent_chain.py') == plan['tests_after']['tests/latent_chain.py']
    assert sha(R / 'tests/latent_reference.py') == plan['tests_after']['tests/latent_reference.py']
    return {
        'driver_sha256': sha(DRIVER), 'probe_sha256': sha(PROBE),
        'current_chain_sha256': sha(R / 'tests/latent_chain.py'),
        'current_reference_sha256': sha(R / 'tests/latent_reference.py'),
        'orchestrator_sha256': sha(A / 'complete_actual.py'),
        'scope': 'N=100000,D=32,K=12,F,60 iteration budget, CPU1, complete ordinary GMM/HMM deterministic algorithms; not a live deployed platform request.',
        'fairness': {
            'input_preparation': 'call() allocates and copies the same six payloads in the requested layout; copying and readonly flags occur inside all measured calls.',
            'execution': 'C++ uses ordinary AdaptiveScheduler.execute, not Prepared.run. NJIT whole-chain signature is warmed using the same dtype/layout/readonly signature before intervals. Graph definitions and machine-code compilation are excluded for both.',
            'outputs': 'The same thirteen fields, shape/dtype, initialization/EM budgets and inference/rank/scatter semantics are required. Reference floating fields allow absolute tail error 4.9e-5; discrete states/order/iteration fields remain exact.',
            'retention': 'previous retains the prior thirteen-output generation throughout the next call; no result input or prior-generation alias is allowed.',
            'cpu': 'Both children force the five native/JIT thread environment limits to one; C++ cpu_budget/tokens/lane, no Python numerical fallback, and time CPU/wall ratios are checked from records.',
            'memory': 'Heap and RSS use separate fresh children and include three calls with two result generations live in the third call. Measurement starts after import/definitions and excludes verification copies.',
        },
        'limitations': [
            'Input fixture creation and graph definition construction are excluded; ownership preparation per request is included.',
            'Six payloads are intentionally identical at the boundary; NJIT derives fixed valid/uniform/reverse/transition values in its frozen algorithm rather than reading every auxiliary payload.',
            'malloc interception does not prove stack/mmap/unintercepted allocator coverage; per-call RSS is sampled every 0.5 ms and is not ru_maxrss. Heap and RSS must not be summed.',
            'Large single-core deterministic GMM/HMM examples do not establish all model/portfolio/simulation workloads, multi-core scaling, arbitrary ill-conditioned data or live platform integration.',
            'The performance fixture is valid finite data; malformed/nonfinite/error-path claims need the separate affected regression evidence.',
            'This fresh replay has three timed rounds per backend/model, not a long-term stability study. Frozen R4/R6 paired repeats are separate supporting evidence and must remain separately identified.',
        ],
    }


def package_identity(path, label):
    ident = read(path)
    assert ident['build_id'] == IDS[label]
    assert sha(ident['wheel']) == ident['wheel_sha256']
    with zipfile.ZipFile(ident['wheel']) as wheel:
        members = [n for n in wheel.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
        assert len(members) == 25
        for member in members:
            assert Path(ident['installed'], member).read_bytes() == wheel.read(member), member
    for name, expected in ident['installed_binaries'].items():
        assert sha(Path(ident['installed'], name)) == expected
    return {'identity_sha256': sha(path), 'wheel_sha256': ident['wheel_sha256'],
            'build_id': ident['build_id'], 'installed_members_verified': 25}


def xml_cases(job):
    assert job['returncode'] == 0
    assert sha(job['log']) == job['log_sha256']
    assert sha(job['xml']) == job['xml_sha256']
    root = ET.parse(job['xml']).getroot()
    assert not any(root.findall('.//' + kind) for kind in ('failure', 'error', 'skipped'))
    cases = root.findall('.//testcase')
    ids = {(c.get('classname'), c.get('name')) for c in cases}
    assert len(ids) == len(cases) == job['counts']['tests']
    return ids


def expected_outputs(model):
    shapes = [[100000], [100000], [100000], [100000, 12], [12, 32], [12], [], [],
              [100000, 32], [12], [12, 32], [12, 32], [12, 12] if model == 'hmm' else [0, 0]]
    discrete = {'state', 'component_order', 'iterations', 'pretrain_iterations'}
    return [(name, shape, 'int64' if name in discrete else 'float64') for name, shape in zip(NAMES, shapes)]


def check_raw(raw, model, metric, label, hashes):
    assert raw['metric'] == metric and raw['model'] == model
    assert raw['shape'] == [100000, 32, 12] and raw['layout'] == 'F' and raw['iterations'] == 60
    assert raw['backend'] == ('njit' if label == 'njit' else 'cpp')
    if label == 'njit':
        assert raw['build_id'] is None and raw['audit'] is None
    else:
        assert raw['build_id'] == IDS[label]
        audit = raw['audit']
        assert audit['engine_build_id'] == IDS[label]
        assert audit['cpu_budget'] == audit['cpu_tokens'] == audit['thread_count'] == 1
        assert audit['lane'] == 'single' and audit['result_lifetime'] == 'independent'
        assert audit['native_aot'] is True and audit['prepared'] is False
        assert audit['python_native_transitions'] == 1
        for key in ['python_fallback', 'python_operator_calls', 'request_time_compilation',
                    'python_worker_callbacks', 'boundary_copy_bytes', 'output_copy_bytes']:
            assert audit[key] == 0, key
        density_calls = sum(chunk['eigen_density_calls'] for chunk in audit['native_chunks'])
        assert density_calls > 0 if label == 'actual' else density_calls == 0
        assert all(chunk['input_copy_bytes'] == 0 for chunk in audit['native_chunks'])
    v = raw['verification']
    assert v['status'] == 'passed' and v['input_hashes'] == hashes
    assert set(hashes) == INPUT_NAMES and all(len(h) == 64 for h in hashes.values())
    assert len(v['all_thirteen_outputs']) == len(v['old_result_hashes']) == 13
    assert all(len(h) == 64 for h in v['old_result_hashes'])
    assert all(v[key] is True for key in ('input_unchanged', 'old_outputs_unchanged', 'two_generation_and_input_nonalias'))
    parity = raw['post_measurement_parity']
    assert parity['status'] == 'passed' and len(parity['outputs']) == 13
    for index, ((name, shape, dtype), item, p) in enumerate(zip(expected_outputs(model), v['all_thirteen_outputs'], parity['outputs'])):
        assert (item['name'], item['shape'], item['dtype']) == (name, shape, dtype)
        error = item['max_absolute_error']
        assert math.isfinite(error) and 0 <= error <= 4.9e-5
        if dtype == 'int64': assert error == 0
        assert (p['output'], p['shape'], p['dtype']) == (index, shape, dtype)
        assert p['sha256'] == v['old_result_hashes'][index]
        assert p['exact_required'] == (label != 'njit' or dtype == 'int64')
        if p['exact_required']: assert p['max_abs_difference'] == 0
    if metric == 'time':
        assert len(raw['seconds']) == len(raw['cpu_seconds']) == 3
        assert all(x > 0 for x in raw['seconds'] + raw['cpu_seconds'])
        assert raw['median_seconds'] == statistics.median(raw['seconds'])
        assert abs(raw['cpu_utilization_percent'] - 100 * sum(raw['cpu_seconds']) / sum(raw['seconds'])) < 1e-9
        assert 50 < raw['cpu_utilization_percent'] < 115
    elif metric == 'heap':
        assert set(raw['stages']) == {'0', '1', '2'}
        assert all(s['table_overflows'] == 0 for s in raw['stages'].values())
        assert raw['warm_peak_bytes'] == raw['stages']['2']['peak_bytes']
    else:
        assert set(raw['stages']) == {'0', '1', '2'}
        assert raw['baseline_bytes'] == raw['stages']['0']['baseline']
        assert raw['warm_peak_bytes'] == raw['stages']['2']['peak']
        assert raw['warm_incremental_rss_bytes'] == raw['warm_peak_bytes'] - raw['baseline_bytes']
        assert all(s['peak'] >= max(s['baseline'], s['retained']) for s in raw['stages'].values())


def review():
    static = preparation()
    pipeline_path = A / 'complete-replay/pipeline.json'
    pipeline = read(pipeline_path)
    assert pipeline['status'] == 'passed_actual_complete_chain_replay_independent_audit_pending'
    assert len(pipeline['jobs']) == 18 and 'current' not in pipeline
    assert pipeline['source_adopted'] is True and pipeline['goal_complete'] is False
    assert pipeline['driver_sha256'] == static['driver_sha256']
    assert pipeline['probe_sha256'] == static['probe_sha256']
    plan = read(A / 'plan.json')
    assert len(plan['source_after']) == 93 and len(plan['tests_after']) == 203
    assert all(sha(R / name) == h for name, h in plan['source_after'].items())
    assert all(sha(R / name) == h for name, h in plan['tests_after'].items())
    packages = {label: package_identity(path, label) for label, path in [
        ('actual', A / 'actual-package/identity.json'),
        ('before', Path('/private/tmp/calmetrics-hmm-f-root-view-v91-20261010/adoption/actual-package/identity.json'))]}
    assert read(A / 'actual-package/identity.json')['source'] == plan['source_after']
    qualification_path = A / 'r2/normal-qualification.json'
    q = read(qualification_path)
    assert q['status'] == 'passed_actual_affected_qualification' and q['build_id'] == IDS['actual']
    sets = {j['label']: xml_cases(j) for j in q['jobs']}
    assert len(sets['related']) == 2628 and len(sets['native']) == 9 and len(sets['focused_reused']) == 243
    assert sets['focused_reused'] <= sets['related']
    buckets = {}; records = []; end = None; results = {}
    for job in pipeline['jobs']:
        model, metric, label = job['model'], job['metric'], job['backend']
        key = (model, metric, label)
        assert key not in buckets and job['name'] == '_'.join(key) and job['returncode'] == 0
        assert sha(job['log']) == job['log_sha256']
        raw = json.loads(Path(job['log']).read_text().splitlines()[-1])
        assert raw == job['raw']
        assert job['finished_epoch'] >= job['started_epoch']
        if end is not None: assert job['started_epoch'] >= end
        end = job['finished_epoch']
        ref = read(D / f'r4/performance/r2/{model}100k_d32_k12_F/state.json')
        assert sha(ref['reference_file']) == ref['reference_sha256']
        assert raw['post_measurement_parity']['reference'] == ref['reference_file']
        check_raw(raw, model, metric, label, ref['records'][0]['raw']['verification']['input_hashes'])
        field = {'time': 'median_seconds', 'heap': 'warm_peak_bytes', 'rss': 'warm_incremental_rss_bytes'}[metric]
        assert job['field'] == field and job['value'] == raw[field]
        buckets[key] = raw
        records.append({key: job[key] for key in ('name', 'log', 'log_sha256', 'started_epoch', 'finished_epoch', 'value', 'field')})
    assert set(buckets) == {(m, x, b) for m in ('gmm', 'hmm') for x in ('time', 'heap', 'rss') for b in ('before', 'actual', 'njit')}
    for model in ('gmm', 'hmm'):
        assert buckets[model, 'heap', 'before']['stages'] == buckets[model, 'heap', 'actual']['stages']
        for label in ('before', 'actual', 'njit'):
            hs = [buckets[model, metric, label]['verification']['old_result_hashes'] for metric in ('time', 'heap', 'rss')]
            assert hs[0] == hs[1] == hs[2]
        seconds = {b: buckets[model, 'time', b]['median_seconds'] for b in ('before', 'actual', 'njit')}
        heap = {b: buckets[model, 'heap', b]['warm_peak_bytes'] for b in seconds}
        rss = {b: buckets[model, 'rss', b]['warm_incremental_rss_bytes'] for b in seconds}
        total_rss = {b: buckets[model, 'rss', b]['warm_peak_bytes'] for b in seconds}
        results[model] = {'seconds': seconds, 'tracked_heap_peak_bytes': heap,
            'sampled_incremental_rss_bytes': rss, 'sampled_total_rss_bytes': total_rss,
            'actual_time_reduction_percent_vs_before': 100 * (1 - seconds['actual'] / seconds['before']),
            'actual_speedup_vs_njit': seconds['njit'] / seconds['actual'],
            'actual_heap_reduction_percent_vs_njit': 100 * (1 - heap['actual'] / heap['njit']),
            'actual_incremental_rss_reduction_percent_vs_njit': 100 * (1 - rss['actual'] / rss['njit']),
            'actual_incremental_rss_delta_vs_before_bytes': rss['actual'] - rss['before'],
            'density_calls_actual': sum(c['eigen_density_calls'] for c in buckets[model, 'time', 'actual']['audit']['native_chunks'])}
    report = {'status': 'passed_independent_actual_v93_complete_chain_evidence_review',
        'reviewed_epoch': time.time(), 'reviewer_sha256': sha(__file__),
        'pipeline_sha256': sha(pipeline_path), 'raw_children_verified': 18,
        'static_driver_review': static, 'packages': packages, 'cases': results,
        'affected_regressions': {'qualification_sha256': sha(qualification_path),
            'unique_python_related': 2628, 'focused_subset': 243, 'native': 9,
            'not_a_new_full_or_sanitizer_run': True},
        'supporting_repeats': {
            'path': str(D / 'r6/repeat-independent-reviewed.json'),
            'sha256': sha(D / 'r6/repeat-independent-reviewed.json'),
            'scope': 'Previously frozen qualified candidate repeats, not additional actual-worktree replay children or long-term repeated production deployments.'},
        'records': records, 'source_adopted': True, 'goal_complete': False,
        'decision_boundary': 'This review verifies the actual rebuilt V93 CPU1 complete GMM/HMM chain records. It does not declare the broad performance goal complete; major slow matrix/simulation/solver workloads remain separate.'}
    path = HERE / 'reviewed.json'
    assert not path.exists(), 'Preserve earlier independent review; use another directory for another attempt.'
    path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'report': str(path), 'cases': results}, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--prepare', action='store_true'); args = p.parse_args()
    if args.prepare:
        report = preparation(); report['status'] = 'static_fairness_review_prepared_actual_replay_pending'
        (HERE / 'prepared.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'status': report['status'], 'reviewer': str(Path(__file__))}))
    else: review()
