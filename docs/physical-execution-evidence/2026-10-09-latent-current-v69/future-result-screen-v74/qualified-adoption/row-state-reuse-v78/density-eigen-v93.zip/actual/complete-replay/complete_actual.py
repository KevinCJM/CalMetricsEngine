"""Fresh complete GMM/HMM comparisons through the rebuilt actual worktree package."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
from actual_guards import guard

A=Path(__file__).resolve().parent
D=A.parent
driver=Path('/private/tmp/calmetrics-gaussian-filter-stream-v85-20261009/r2/benchmark.py')
probe=Path('/private/tmp/calmetrics-f-coeff-v68-20261008/r5/heap_probe.dylib')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(driver)=='4e5d940ff55ab2028a64033b0221d68f9974b0a627edd855706ee64e14ce4f75'
assert sha(probe)=='6f6722a0d98e501bc935fb5178facf251c9292a76b3cd8f7c397ef59a5899bb5'
assert json.loads((A/'r2/normal-qualification.json').read_text())['status']=='passed_actual_affected_qualification'
assert sys.version_info[:2]==(3,12) and sys.prefix=='/Users/chenjunming/Desktop/myenv_312'
identities={'before':json.loads(Path('/private/tmp/calmetrics-hmm-f-root-view-v91-20261010/adoption/actual-package/identity.json').read_text()),
            'actual':json.loads((A/'actual-package/identity.json').read_text())}
assert identities['before']['build_id']=='723c06b38e087d4ec82a6830c39420a56177125de79c3908cf04f130ffeb5bc6'
assert identities['actual']['build_id']=='79b494c5014e66ff1ded4c17ce46d0563018a5ffb551c0c40875bcda92045663'
guard()
out=A/'complete-replay';out.mkdir(exist_ok=False)
state={'status':'running','jobs':[],'source_adopted':True,'actual_package_identity_verified':True,
       'scope':'CPU1 complete ordinary training/standardization/initialization/pretrain/EM/inference/rank/scatter, six identical owned readonly inputs, thirteen outputs, two generations retained; compilation/definitions excluded. Deterministic platform algorithm, not a live deployed service.',
       'driver_sha256':sha(driver),'probe_sha256':sha(probe),'goal_complete':False}
dest=out/'pipeline.json'
try:
    for model_index,model in enumerate(['gmm','hmm']):
        reference=json.loads((D/f'r4/performance/r2/{model}100k_d32_k12_F/state.json').read_text())
        assert sha(reference['reference_file'])==reference['reference_sha256']
        expected_hashes=reference['records'][0]['raw']['verification']['input_hashes']
        for metric_index,metric in enumerate(['time','heap','rss']):
            labels=['before','actual','njit'];shift=(model_index+metric_index)%3
            labels=labels[shift:]+labels[:shift]
            for label in labels:
                guard()
                name=model+'_'+metric+'_'+label;log=out/(name+'.log')
                identity=identities['before' if label=='njit' else label]
                cmd=[sys.executable,str(driver),'--backend','njit' if label=='njit' else 'cpp',
                     '--model',model,'--n','100000','--d','32','--k','12','--iterations','60','--layout','F',
                     '--rounds','3','--metric',metric,'--install',identity['installed'],
                     '--parity-reference',reference['reference_file']]
                env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMBA_NUM_THREADS='1',
                         VECLIB_MAXIMUM_THREADS='1',MKL_NUM_THREADS='1')
                env.pop('DYLD_INSERT_LIBRARIES',None)
                if metric=='heap':env['DYLD_INSERT_LIBRARIES']=str(probe)
                with log.open('x') as stream:
                    child=subprocess.Popen(cmd,env=env,cwd=A,stdout=stream,stderr=subprocess.STDOUT)
                    started=time.time();state['current']={'name':name,'pid':child.pid,'started_epoch':started,'command':cmd}
                    dest.write_text(json.dumps(state,indent=2)+'\n');print('START',name,child.pid,flush=True)
                    rc=child.wait()
                if rc:print(log.read_text()[-4000:],flush=True)
                assert rc==0,(name,rc)
                raw=json.loads(log.read_text().splitlines()[-1])
                assert raw['verification']['status']=='passed' and raw['verification']['input_hashes']==expected_hashes
                assert len(raw['verification']['all_thirteen_outputs'])==13
                assert raw['post_measurement_parity']['status']=='passed'
                if label!='njit':
                    assert raw['build_id']==identity['build_id']
                    assert raw['audit']['cpu_budget']==raw['audit']['cpu_tokens']==1
                    assert raw['audit']['result_lifetime']=='independent'
                    if label=='actual':assert sum(c['eigen_density_calls'] for c in raw['audit']['native_chunks'])>0
                field={'time':'median_seconds','heap':'warm_peak_bytes','rss':'warm_incremental_rss_bytes'}[metric]
                state['jobs'].append({'name':name,'model':model,'metric':metric,'backend':label,
                    'returncode':rc,'log':str(log),'log_sha256':sha(log),'started_epoch':started,
                    'finished_epoch':time.time(),'value':raw[field],'field':field,'raw':raw})
                state.pop('current',None);dest.write_text(json.dumps(state,indent=2)+'\n')
                print('PASS',name,raw[field],flush=True)
    assert len(state['jobs'])==18
    guard();state.update(status='passed_actual_complete_chain_replay_independent_audit_pending',finished_epoch=time.time())
except BaseException as error:
    state.update(status='failed',error=repr(error));raise
finally:dest.write_text(json.dumps(state,indent=2)+'\n')
