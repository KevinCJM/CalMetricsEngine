# Nested physical replay cost repair

Qualified R3 numerical kernels, graph/liveness/fusion, worker protocol and
ownership are unchanged. Original R3 native9, SAN6509, OFF6508+one named skip,
normalfull16961 and54 complete measurement records remain immutable evidence
for their original source/package identities. They are not relabeled as R4.

Runtime probes show R3 and actual75d give identical nested iterate work units
although R3 performs additional Gaussian replay. The same graph with observed
density does only a small sum but is estimated as more expensive. This is a
Planner estimate omission, not a demonstrated numeric or memory-safety defect.

Use existing typed_array_extra_work recursion and its existing capture shapes,
scope bounds and repeat multipliers. At full_work child calls only, add direct
Gaussian replay cost through the existing helper. Top-level replay remains
separately counted and must not be doubled. A healthy child of an isolated
parent uses its own existing error/fusion policy. No new op, cost coefficient,
threshold, arithmetic, termination or memory/ownership contract is introduced.

Regression checks a realistic eligible nested body against the equivalent
observed-density control. Recompute must cost more while all results remain
byte-identical, in nested/non-nested and isolated/non-isolated parent cases.
Normal/native and affected Planner/scope/numerical/transport regressions must
use fresh R4 runtime identities. Preserve R3 broad numerical evidence with
explicit unchanged-kernel scope; do not claim R4 has rerun the broad full suite.
Run representative complete-chain replay/performance before actual adoption.
Excel logical DAG and formulas are unaffected; actual guides remain75d until
qualified adoption. Whole optimization goal remains incomplete.

## Fresh R4 normal facts

Normal R4 source/config93 and test sources200 match the new package0ebc5921.
All25 installed runtime payloads match the wheel, including extension/worker.
Native9,25 related Python modules1353 and the separate4 regressions pass with
zero skip/failure/error. The four regressions are also in the1353 total,
not1357 unique Python tests. Regressions were red on frozen R3 before the
Planner fix; numeric assertions are unchanged.

Fresh runtime probes show single-level replay work37,749,092 ->58,720,772,
nested replay162,181,240 ->246,067,960. Observed-density controls stay exactly
46,836,866.4/198,532,337.6. Outer isolation does not suppress healthy child
work. These are estimated routing units, not FLOPs or measured speedups.

Ninety-two R3 production/config files are byte-identical; Planner alone
changes. R3 full numerical evidence remains scoped to its original IDs.
Actual engine75d source93/tests199/protected338 is unchanged as freshly
checked. SAN native9 and4 regressions have passed; SAN1353 related and OFF
qualification are still running/pending. Full-chain replay/performance and
guarded actual adoption remain required.
