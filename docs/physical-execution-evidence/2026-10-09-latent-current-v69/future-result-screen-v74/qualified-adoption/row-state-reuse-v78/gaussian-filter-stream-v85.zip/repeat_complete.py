"""Fresh complete HMM screens; original full driver and all thirteen outputs."""
from pathlib import Path
import hashlib,json,subprocess,sys,os,time,shutil
D=Path(__file__).resolve().parent
group=int(sys.argv[1]);assert group in (1,2,3)
candidate=json.loads((D/'candidate/identity.json').read_text())
assert json.loads((D/'remaining-qualification.json').read_text())['status']=='passed'
assert json.loads((D/'worker-generations.json').read_text())['status']=='passed_both_native_generations_inline_and_shared'
actual=json.loads(Path('/private/tmp/calmetrics-latent-unwritten-result-v78-20261009/r2/actual/package/identity.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
driver=D.parent/'r2/benchmark.py'
assert sha(driver)=='4e5d940ff55ab2028a64033b0221d68f9974b0a627edd855706ee64e14ce4f75'
assert actual['build_id']=='75d26e3cfd6dec74d48cba47138560d6b8f385ba53a8bd865d0343ddd3784640'
for ident in (candidate,actual):
 assert all(sha(Path(ident['installed'])/n)==h for n,h in ident['installed_binaries'].items())
assert all(sha(D/'source'/n)==h for n,h in candidate['source'].items())
q=json.loads((D/'normal-qualification.json').read_text());assert q['status']=='passed' and q['build_id']==candidate['build_id']
probe=Path('/private/tmp/calmetrics-f-coeff-v68-20261008/r5/heap_probe.dylib')
assert sha(probe)=='6f6722a0d98e501bc935fb5178facf251c9292a76b3cd8f7c397ef59a5899bb5'
old=Path('/private/tmp/calmetrics-hmm-medium-filter-tail-v79-20261009')
medium=json.loads((old/'screen-r1.json').read_text());large=json.loads((old/'controls.json').read_text())
cases=[('hmm250k',250000,old/'screen-r1/actual-reference.npz','d6da5a27367f36adec6c221e8f1c87ffd52a5d1f71fea72a35084e7cb718b60a',medium['input_hashes']),
('hmm750k',750000,Path(large['references']['hmm750k']['path']),large['references']['hmm750k']['sha256'],next(r['raw']['verification']['input_hashes'] for r in large['records'] if r['case']=='hmm750k'))]
dest=D/('repeat-r'+str(group)+'.json');assert not dest.exists();logs=D/('repeat-r'+str(group));logs.mkdir()
state={'status':'running','candidate_build_id':candidate['build_id'],'actual_build_id':actual['build_id'],
 'driver_sha256':sha(driver),'heap_probe_sha256':sha(probe),'production_adopted':False,'goal_complete':False,'records':[],
 'references':{name:{'path':str(ref),'sha256':h} for name,n,ref,h,inputs in cases}}
try:
 # No test/build process may overlap formal measurement. Ignore this
 # coordinator and its shell ancestors; do not treat a stale state file as idle.
 def assert_idle():
  listing=subprocess.check_output(['/bin/ps','-ww','-axo','pid=,ppid=,command=']).decode('utf-8','replace')
  rows={};parents={}
  for line in listing.splitlines():
   parts=line.split(None,2)
   if len(parts)==3:rows[int(parts[0])]=parts[2];parents[int(parts[0])]=int(parts[1])
  me=os.getpid();ignored={me}
  while parents.get(me,0)>0:me=parents[me];ignored.add(me)
  busy=[]
  for pid,command in rows.items():
   if pid in ignored:continue
   first=Path(command.split(None,1)[0]).name
   if first in {'clang','clang++','cc1','cmake','ninja','make','ctest','pytest','calmetrics_worker'} or (first in {'Python','python','python3','python3.12'} and ('/private/tmp/calmetrics-' in command or '-m pytest' in command)):
    busy.append({'pid':pid,'command':command})
  assert not busy,('concurrent_build_test_or_benchmark',busy)
 for name,n,ref,refsha,inputs in cases:
  for metric,order in ([('time',['candidate','njit','actual']),('heap',['njit','actual','candidate']),('rss',['actual','candidate','njit'])] if group!=3 else [('time',['njit','actual','candidate']),('heap',['actual','candidate','njit']),('rss',['candidate','njit','actual'])]):
   for backend in order:
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMBA_NUM_THREADS='1',MKL_NUM_THREADS='1')
    if metric=='heap':env['DYLD_INSERT_LIBRARIES']=str(probe)
    else:env.pop('DYLD_INSERT_LIBRARIES',None)
    command=[sys.executable,str(driver),'--backend','njit' if backend=='njit' else 'cpp','--model','hmm',
      '--n',str(n),'--d','4','--k','3','--iterations','60','--layout','C','--rounds','3','--metric',metric,
      '--install',candidate['installed'] if backend=='candidate' else actual['installed'],'--parity-reference',str(ref)]
    assert_idle()
    base=json.loads((D/'base-actual-preparation.json').read_text())
    actual_root=Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
    for field in ['base_source','base_tests','protected_sha256']:
     assert all(sha(actual_root/name)==digest for name,digest in base[field].items()),field
    assert all(sha(D/'source'/name)==digest for name,digest in candidate['source'].items())
    assert sha(ref)==refsha
    log=logs/(name+'-'+metric+'-'+backend+'.log')
    with log.open('x') as stream:
     child=subprocess.Popen(command,cwd=D,env=env,stdout=stream,stderr=subprocess.STDOUT)
     state['current']={'case':name,'metric':metric,'backend':backend,'pid':child.pid,'command':command}
     dest.write_text(json.dumps(state,indent=2)+'\n');print('START',name,metric,backend,child.pid,flush=True);rc=child.wait()
    if rc:print(log.read_text()[-9000:],flush=True)
    assert rc==0,(name,metric,backend,rc)
    assert sha(ref)==refsha
    raw=json.loads(log.read_text().splitlines()[-1]);v=raw['verification']
    assert v['status']=='passed' and len(v['all_thirteen_outputs'])==13
    assert v['input_unchanged'] and v['old_outputs_unchanged'] and v['two_generation_and_input_nonalias']
    assert v['input_hashes']==inputs and len(inputs)==6
    if backend!='njit':
     assert raw['build_id']==(candidate if backend=='candidate' else actual)['build_id']
     count=sum(c.get('gaussian_filter_streams',0) for c in raw['audit']['native_chunks'])
     assert count==(1 if backend=='candidate' else 0),('stream_path_not_used',name,count)
    state['records'].append({'case':name,'metric':metric,'backend':backend,'returncode':rc,'log':str(log),'log_sha256':sha(log),'raw':raw})
    state.pop('current',None);dest.write_text(json.dumps(state,indent=2)+'\n')
    value=raw.get('median_seconds',raw.get('warm_incremental_rss_bytes',raw.get('warm_peak_bytes')))
    print('PASS',name,metric,backend,value,flush=True)
 assert all(sha(D/'source'/n)==h for n,h in candidate['source'].items())
 state.update(status='passed_single_group_full_chain_screen',finished=time.time())
except BaseException as e:
 state.update(status='failed',error=repr(e));raise
finally:dest.write_text(json.dumps(state,indent=2)+'\n')
