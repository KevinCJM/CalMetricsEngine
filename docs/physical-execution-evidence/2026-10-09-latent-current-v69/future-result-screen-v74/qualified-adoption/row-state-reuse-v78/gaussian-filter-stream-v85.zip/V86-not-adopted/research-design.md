# V86: deterministic dot-product bound for existing partitioned DGEMM

Scope: isolated candidate based on actual build 75d. No operator, public
interface, financial meaning, precision budget, wire version, or actual
worktree change. V85 qualification remains live and untouched. The candidates
must be integrated with a new source identity and requalified before adoption.

## Problem and mathematics

The current partitioned strategy charges gamma(2b+2+d) for each b-term
DGEMM and merge depth d. Counting both the multiplication and every addition
for every term overstates the maximum number of rounding factors attached to
one product coefficient. A conventional b-term dot product has the standard
componentwise bound gamma(b) times sum(abs(a_i*b_i)): its deepest product
coefficient sees one rounded product and at most b-1 additions. An FMA or
ordinary blocked/reordered binary reduction does not increase this depth.
The b-term bound does not assume random rounding errors or cancellation.

An independent beta=0 DGEMM supplies each partial. Sequential q-1 explicit
merges, or a balanced tree of depth ceil(log2(q)), add rounding factors to
each partial coefficient. gamma(b+2+q) / gamma(b+2+depth) conservatively
retain two extra factors and outward-rounded magnitude bounds. All floating
math stays binary64. The 0.000049 absolute mathematical budget is unchanged.

Primary reference: Higham and Mary, A survey of mixed precision algorithms
in numerical linear algebra, section 4 equation (4.1), and section 4.2
blocked summation. https://eprints.maths.manchester.ac.uk/2841/1/paper_eprint.pdf
This candidate uses the deterministic model, not the paper's probabilistic
bounds. Candidate eligibility still requires actual library numerical tests.

The existing guards restrict nonzero inputs to [2^-128, 2^128] and K<=8192.
Products and intermediate sums cannot overflow. Even exact-product dyadic
grids are at least 2^-360, far above binary64 subnormal spacing. Unchanged
finite/sign/rounding-mode/layout guards precede every production write.
The norm computation retains its original gamma(2K+2) inflation. Canonical
zero/sign ambiguity, exact replay, late full-root replay, cancellation and
BLAS threading restoration remain unchanged.

## Implementation

Only cpp/operators/matmul_partitioned.hpp changes: three block error-count
expressions and their explanatory comments. Shape admission, block search,
tree slots, arena upper bound, C/F layout, data preparation and scheduling
remain the same. The expected benefit is fewer, larger mature Accelerate
DGEMM calls at long K; performance and peak memory remain unproven until
full-request measurement. No KB/ms improvement is an adoption argument.

## Validation and adoption requirements

1. Compile a standalone AOT mathematical driver against both actual and
   candidate headers. Test non-power-of-two K, C/F inputs/results, exact
   binary fixtures, cancellation, and rejection under non-nearest rounding.
   Independently check returned cells with Decimal at 80 digits. This driver
   proves only the private strategy and cannot qualify the engine.
2. Build a private wheel with source/native/worker identity checks. Compilation
   and functional regression may run at CPU1 alongside qualification; all
   formal measurements must wait for compilation/qualification to be terminal.
   Execute the existing complete
   long-K/partitioned/root precision/input/layout/budget/lifetime/native tests.
3. Fair complete workload: owned readonly input preparation, ordinary
   Scheduler execution and both retained independent result generations;
   identical data, all outputs, one core, warmed NJIT. Rotate fresh process
   order for time, tracked heap and incremental RSS. Include high-amplitude
   4096x8192 by 8192x4096, long rectangle and already-admitted controls.
   No timing under concurrent qualification or sanitizer builds.
4. Only reproducible material whole-task benefit qualifies the change.
   Rebase only this header onto then-current actual source, rebuild, regress,
   replay and synchronize current physical-execution documentation. V85 and
   V86 experiment identities are not evidence for a combined actual build.

Mature-library research: GEMMul8 targets CUDA/ROCm matrix engines; Ozaki CPU
schemes require multiple GEMMs and hardware-specific INT8/i8mm/AMX support.
LIBXS supplies interception/adaptive schemes and additional preprocessing.
These are research alternatives, not measured substitutes for the current
Apple binary64 path. No backend or global dependency has been installed.

Actual engine/Excel logical contracts are unchanged in this experiment.
Current user docs remain actual75d until a qualified adoption. Whole-engine
goal remains open, including medium HMM heap and complete constrained
solver/frontier/exploration chains.

## Post-screen library research

The first36-record complete screen rejects this unchanged candidate; native
heap is unchanged and long-K remains34-39 percent slower than warmed NJIT.
No stability/SAN spend is justified for the same source.

Read primary documentation on2026-10-09:
- https://github.com/mukunoki/ozblas : official README calls the implementation
  an experimental alpha for method demonstration and does not recommend real
  application use. CPU dependencies list G++ and MKL/OpenBLAS. This does not
  establish a supported AppleClang/Accelerate implementation or local benefit.
- https://libxs.readthedocs.io/en/stable/samples/libxs_ozaki/ : sample supports
  low-precision slicing/CRT; documented interception uses GNU ld wrap/ELF
  preload. CPU preprocessing uses OpenMP threads. An adapter would need
  explicit entry points and the same Scheduler budget; documented throughput
  is not a local M1Max FP64/end-to-end result.
- https://www.tuhh.de/ti3/paper/rump/OzOgOiRu11.pdf : author paper supplies
  error-free matrix splitting using BLAS. Its abstract explicitly notes
  significant workspace and predominantly multiple matrix multiplications.
  This gives a method to investigate, not evidence of lower complete peak
  memory or faster execution on this host.

No dependency installation, global preload, precision reduction, vendor
accumulation assumption or numerical contract change follows from this
research. OzBLAS is not adopted as a mature production backend. Any future
method must separately qualify deterministic accuracy and rounding/replay,
CPU admission, layout/ownership and fair complete-chain time plus memory.
