from pathlib import Path
import argparse, hashlib, json, subprocess, xml.etree.ElementTree as E, zipfile
D = Path(__file__).resolve().parent
S = D / 'source'
R = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
p = argparse.ArgumentParser()
p.add_argument('--normal-only', action='store_true')
a = p.parse_args()
pre = json.loads((D / 'preparation.json').read_text())
assert pre['changed_source'] == ['cpp/planner.cpp']
assert len(pre['changed_tests']) == 1
assert all(sha(S / n) == h for n, h in pre['source'].items())
assert all(sha(S / n) == h for n, h in pre['tests'].items())
report = {'status':'passed', 'scope':'fresh R4 qualification; no actual adoption',
          'source_files':len(pre['source']), 'test_source_files':len(pre['tests']),
          'unchanged_R3_source_files':sum(pre['source'][n] == h for n, h in pre['base_source'].items()),
          'modes':{}, 'production_adopted':False, 'goal_complete':False}
for mode in (['normal'] if a.normal_only else ['normal','asan','off']):
    identity_file = D / ('candidate' if mode == 'normal' else mode) / 'identity.json'
    i = json.loads(identity_file.read_text())
    assert i['source'] == pre['source']
    encoded = ';'.join(i['compiler']) + ''.join(';' + n + ':' + h for n, h in sorted(i['source'].items()))
    assert hashlib.sha256(encoded.encode()).hexdigest() == i['build_id']
    assert sha(i['wheel']) == i['wheel_sha256']
    with zipfile.ZipFile(i['wheel']) as archive:
        names = [n for n in archive.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
        assert len(names) == 25
        for n in names:
            assert sha(Path(i['installed']) / n) == hashlib.sha256(archive.read(n)).hexdigest(), n
    for n, h in i['installed_binaries'].items():
        assert sha(Path(i['installed']) / n) == h
    q = json.loads((D / (mode + '-qualification.json')).read_text())
    assert q['status'] == 'passed' and q['build_id'] == i['build_id']
    jobs = []
    for job in q['jobs']:
        label = job['label']
        xml = D / (mode + '-' + label + '.xml')
        log = D / (mode + '-' + label + '.log')
        assert sha(xml) == job['xml_sha256'] and sha(log) == job['log_sha256']
        cases = list(E.parse(xml).getroot().iter('testcase'))
        counts = {'tests':len(cases), 'failures':sum(c.find('failure') is not None for c in cases),
                  'errors':sum(c.find('error') is not None for c in cases),
                  'skipped':sum(c.find('skipped') is not None for c in cases)}
        assert counts == job['counts']
        assert counts['tests'] == {'regression':4,'native':9,'related':1353}[label]
        assert not any(counts[n] for n in ['failures','errors','skipped'])
        jobs.append(dict(label=label, counts=counts, log_sha256=sha(log), xml_sha256=sha(xml)))
    report['modes'][mode] = {'build_id':i['build_id'], 'runtime_payload_files':len(names), 'jobs':jobs}
base = json.loads((D / 'base-actual-preparation.json').read_text())
for field in ['base_source','base_tests','protected_sha256']:
    assert all(sha(R / n) == h for n, h in base[field].items()), field
report['actual_preserved'] = {k:len(base[k]) for k in ['base_source','base_tests','protected_sha256']}
report['repo_status_sha256'] = {str(r):hashlib.sha256(subprocess.check_output(
    ['git','--no-optional-locks','status','--short'],cwd=r)).hexdigest() for r in [R, R.parent / 'FundInvestmentResearchPlatform']}
(D / ('normal-verified.json' if a.normal_only else 'qualification-verified.json')).write_text(json.dumps(report,indent=2) + '\n')
print(json.dumps(report,indent=2))
