"""Fair CPU1 full ordinary GMM/HMM request; no compilation inside measurement."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMBA_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name]='1'
import argparse, ctypes, gc, json, sys, time, statistics, hashlib
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('--install', default='/private/tmp/calmetrics-f-coeff-v68-20261008/r5/actual/package/install')
p.add_argument('--model', choices=('hmm','gmm'), required=True)
p.add_argument('--backend', choices=('cpp','njit'), required=True)
p.add_argument('--n',type=int,default=250000)
p.add_argument('--d',type=int,default=4)
p.add_argument('--k',type=int,default=12)
p.add_argument('--iterations',type=int,default=4)
p.add_argument('--layout',choices=('C','F'),default='C')
p.add_argument('--rounds',type=int,default=3)
p.add_argument('--metric',choices=('time','heap','rss'),default='time')
p.add_argument('--save-outputs')
p.add_argument('--parity-reference')
args=p.parse_args()
root=Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
sys.path.insert(0,str(root));sys.path.insert(0,args.install)

from tests import latent_chain as chain
rng=np.random.default_rng(7391)
n,d,k=args.n,args.d,args.k
nt=n*3//4
raw=rng.normal(size=(n,d)) + ((np.arange(n)//50)%k)[:,None]*1.7
raw=np.array(raw,order=args.layout)
valid=np.zeros(n,np.bool_);valid[nt:]=True
transition=np.full((k,k),.1/max(1,k-1));np.fill_diagonal(transition,.9)
fixture={'raw':raw,'positions':np.arange(n,dtype=np.int64),'training_positions':np.arange(nt,dtype=np.int64),
         'classify_positions':np.arange(nt,n,dtype=np.int64),'valid':valid,'uniform':np.full(k,1/k),
         'reverse_order':np.arange(k-1,-1,-1,dtype=np.int64),'transition_template':transition}
for z in fixture.values():z.flags.writeable=False
engine=None; last_audit=None; build_id=None
if args.backend=='cpp':
    import calmetrics_engine as c
    graph,names=chain.graph_for(fixture,k,args.iterations,17,args.model)
    fixture={key:fixture[key] for key in graph.input_names}
    engine=c.AdaptiveScheduler(cpu_budget=1)
    build_id=json.loads((Path(args.install).parent/'identity.json').read_text())['build_id']
    starts=np.zeros(1,np.int64);ends=np.array([n],np.int64)
    def calculate(data):
        global last_audit
        r=engine.execute(graph,data,starts,ends)
        last_audit=r.audit
        assert r.audit['engine_build_id']==build_id
        assert r.audit['python_operator_calls']==r.audit['python_fallback']==0
        assert engine.peak_active_cpu_tokens<=1
        return tuple(slot.values[0] for slot in r.outputs)
else:
    names=['state','score','confidence','probabilities','initial_means','component_order','iterations',
           'pretrain_iterations','standardized','model_weights','model_means','model_variances','model_transition']
    def calculate(data):
        result=chain.chain_reference(data['raw'],data['positions'][:nt],data['positions'][nt:],
                                     k,args.iterations,17,args.model=='hmm')
        return tuple(np.asarray(value) for value in result)
    tiny_raw=np.array(raw[:64],order=args.layout);tiny_raw.flags.writeable=False
    tiny_train=np.arange(32,dtype=np.int64);tiny_class=np.arange(32,64,dtype=np.int64)
    tiny_train.flags.writeable=tiny_class.flags.writeable=False
    chain.chain_reference(tiny_raw,tiny_train,tiny_class,k,args.iterations,17,args.model=='hmm')
    fixture={key:fixture[key] for key in ('raw','positions','valid','uniform','reverse_order','transition_template')}

def call():
    data={name:np.array(z,order=args.layout if z.ndim==2 else 'C',copy=True) for name,z in fixture.items()}
    for z in data.values():z.flags.writeable=False
    result=calculate(data)
    for z in result:z.flags.writeable=False
    return result

def result_hashes(result):
    return [hashlib.sha256(memoryview(np.ascontiguousarray(z)).cast('B') if z.size else b'').hexdigest() for z in result]

def summaries(result):
    output=[]
    for z in result:
        head=[None if isinstance(value,float) and np.isnan(value) else value for value in z.ravel()[:16].tolist()]
        total=float(np.sum(z,dtype=np.float64))
        output.append(dict(shape=z.shape,dtype=str(z.dtype),head=head,total=None if np.isnan(total) else total))
    return output

scope='owned readonly identical input payloads, ordinary Scheduler/NJIT complete training+standardization+initialization+GMM pretrain+model EM+filtered inference+rank+scatter/state mapping, thirteen outputs; two result generations retained; definitions and JIT excluded; CPU budget 1'
try:
    if args.metric=='time':
        previous=call(); samples=[];cpu_samples=[]
        for _ in range(args.rounds):
            before=result_hashes(previous)
            start=time.perf_counter();cpu_start=time.process_time();result=call();cpu_samples.append(time.process_time()-cpu_start);samples.append(time.perf_counter()-start)
            assert result_hashes(previous)==before
            assert all(not np.shares_memory(a,b) for a,b in zip(previous,result))
            previous=result
        raw=dict(seconds=samples,cpu_seconds=cpu_samples,cpu_utilization_percent=100*sum(cpu_samples)/sum(samples),observations_per_second=args.n/statistics.median(samples),median_seconds=statistics.median(samples),outputs=summaries(previous))
    elif args.metric=='heap':
        sys.path.insert(0,str(root/'tools'))
        from benchmark_memory import HeapStats as Stats
        probe=ctypes.CDLL(None)
        gc.collect();probe.cme_heap_begin();stages={};previous=None
        try:
            for i in range(3):
                before=result_hashes(previous) if previous is not None else None
                probe.cme_heap_reset_peak();result=call();s=Stats();probe.cme_heap_snapshot(ctypes.byref(s))
                stages[str(i)]={n:getattr(s,n) for n,_ in s._fields_}
                assert s.table_overflows==0
                if previous is not None:assert result_hashes(previous)==before
                previous=result
        finally:
            s=Stats();probe.cme_heap_end(ctypes.byref(s));assert s.table_overflows==0
        raw=dict(stages=stages,warm_peak_bytes=stages['2']['peak_bytes'],outputs=summaries(previous))
    else:
        import psutil,threading
        proc=psutil.Process();measuring=threading.Event();stop=threading.Event();peak=[0]
        def monitor():
            while not stop.wait(.0005):
                if measuring.is_set():peak[0]=max(peak[0],proc.memory_info().rss)
        worker=threading.Thread(target=monitor);worker.start()
        baseline=proc.memory_info().rss;stages={};previous=None
        try:
            for i in range(3):
                base=proc.memory_info().rss;peak[0]=base;measuring.set();result=call();end=proc.memory_info().rss;measuring.clear()
                stages[str(i)]=dict(baseline=base,peak=max(peak[0],end),retained=end)
                previous=result
        finally:stop.set();worker.join()
        raw=dict(stages=stages,baseline_bytes=baseline,warm_peak_bytes=stages['2']['peak'],warm_incremental_rss_bytes=stages['2']['peak']-baseline,outputs=summaries(previous))
    if args.parity_reference:
        import hashlib
        checks=[]
        with np.load(args.parity_reference) as reference:
            for i,value in enumerate(previous):
                expected=reference[f'output{i}']
                assert value.shape==expected.shape and value.dtype==expected.dtype
                left=value.ravel();right=expected.ravel();maximum=0.
                for first in range(0,left.size,65536):
                    a=left[first:first+65536];b=right[first:first+65536]
                    if args.backend=='cpp' or value.dtype.kind!='f':
                        np.testing.assert_array_equal(a.view(np.uint8),b.view(np.uint8))
                    else:
                        np.testing.assert_allclose(a,b,rtol=4.9e-5,atol=4.9e-5,equal_nan=True)
                        finite=np.isfinite(a)&np.isfinite(b)
                        if finite.any():maximum=max(maximum,float(np.max(np.abs(a[finite]-b[finite]))))
                digest=hashlib.sha256(memoryview(np.ascontiguousarray(value)).cast('B') if value.size else b'').hexdigest()
                checks.append(dict(output=i,shape=value.shape,dtype=str(value.dtype),sha256=digest,
                                   exact_required=args.backend=='cpp' or value.dtype.kind!='f',max_abs_difference=maximum))
        raw['post_measurement_parity']=dict(reference=args.parity_reference,outputs=checks,status='passed')
    if args.save_outputs:
        np.savez(args.save_outputs,**{f'output{i}':z for i,z in enumerate(previous)})
    # Full verification is outside every time/memory measurement interval.
    expected=chain.chain_reference(fixture['raw'],fixture['positions'][:nt],fixture['positions'][nt:],
                                  k,args.iterations,17,args.model=='hmm')
    checks=[]
    for name,value,target in zip(names,previous,expected,strict=True):
        target=np.asarray(target)
        assert value.shape==target.shape and value.dtype==target.dtype,(name,value.shape,value.dtype,target.shape,target.dtype)
        maximum=0.
        left=value.ravel();right=target.ravel()
        for first in range(0,left.size,65536):
            a=left[first:first+65536];b=right[first:first+65536]
            if value.dtype.kind!='f':np.testing.assert_array_equal(a,b,err_msg=name)
            else:
                np.testing.assert_allclose(a,b,rtol=1e-11,atol=4.9e-5,equal_nan=True,err_msg=name)
                finite=np.isfinite(a)&np.isfinite(b)
                if finite.any():maximum=max(maximum,float(np.max(np.abs(a[finite]-b[finite]))))
        checks.append(dict(name=name,shape=value.shape,dtype=str(value.dtype),max_absolute_error=maximum))
    assert np.all(previous[11]>0) and np.all(previous[9]>=0)
    np.testing.assert_allclose(np.sum(previous[9]),1.,rtol=0.,atol=1e-9)
    for first in range(nt,n,65536):
        probabilities=previous[3][first:first+65536]
        assert np.all(probabilities>=0)
        np.testing.assert_allclose(probabilities.sum(axis=1),1.,rtol=0.,atol=1e-9)
    # One extra same-path call audits complete owned-input hashes and aliases.
    checked_data={name:np.array(z,order=args.layout if z.ndim==2 else 'C',copy=True) for name,z in fixture.items()}
    for z in checked_data.values():z.flags.writeable=False
    before_inputs={name:hashlib.sha256(memoryview(np.ascontiguousarray(z)).cast('B')).hexdigest() for name,z in checked_data.items()}
    before_outputs=result_hashes(previous)
    checked_result=calculate(checked_data)
    after_inputs={name:hashlib.sha256(memoryview(np.ascontiguousarray(z)).cast('B')).hexdigest() for name,z in checked_data.items()}
    assert before_inputs==after_inputs
    assert result_hashes(previous)==before_outputs
    assert all(not np.shares_memory(a,b) for a in checked_result for b in previous)
    assert all(not np.shares_memory(a,b) for a in checked_result for b in checked_data.values())
    raw['verification']={'status':'passed','all_thirteen_outputs':checks,'input_hashes':before_inputs,
                         'old_result_hashes':before_outputs,'input_unchanged':True,'old_outputs_unchanged':True,
                         'two_generation_and_input_nonalias':True,'mathematical_invariants':'positive variances; nonnegative normalized weights and posterior; exact discrete states/order/iterations'}
    print(json.dumps(dict(backend=args.backend,model=args.model,metric=args.metric,shape=[args.n,args.d,args.k],layout=args.layout,iterations=args.iterations,build_id=build_id,scope=scope,audit=last_audit,**raw)),flush=True)
finally:
    if engine is not None:engine.close()
