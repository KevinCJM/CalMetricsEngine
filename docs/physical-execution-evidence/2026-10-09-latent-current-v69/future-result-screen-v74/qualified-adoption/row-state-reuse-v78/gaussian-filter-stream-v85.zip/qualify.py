from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time
import xml.etree.ElementTree as ET

D = Path(__file__).resolve().parent
S = D / 'source'
p = argparse.ArgumentParser()
p.add_argument('mode', choices=['normal', 'asan', 'off'])
mode = p.parse_args().mode
i = json.loads((D / ('candidate' if mode == 'normal' else mode) / 'identity.json').read_text())
pre = json.loads((D / 'preparation.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert i['source'] == pre['source']
assert all(sha(S / n) == h for n, h in pre['source'].items())
assert all(sha(S / n) == h for n, h in pre['tests'].items())

related = ['test_gaussian_filter_stream.py', 'test_hmm_filter_tail.py',
 'test_latent_operators.py', 'test_latent_library_backend.py',
 'test_planner_physical_dag.py', 'test_iteration_protocol.py',
 'test_native_apply_scopes.py', 'test_scope_error_status.py',
 'test_scope_numerical_stop_structure.py', 'test_segment_error_status.py',
 'test_typed_results.py', 'test_typed_array_execution.py',
 'test_typed_cpp_runtime.py', 'test_cpp_first_runtime.py',
 'test_phase2_graph_runtime.py', 'test_tensor_protocol.py',
 'test_row_subview.py', 'test_row_subview_extra.py', 'test_row_subview_budget.py',
 'test_latent_workspace_loan.py', 'test_latent_future_result.py',
 'test_hmm_history_budget.py', 'test_hmm_history_cost.py',
 'test_dense_layout_transport.py', 'test_binding_cache_lifetime.py']
related = ['tests/' + n for n in related]
assert all((S / n).is_file() for n in related)
enabled = '0' if mode == 'off' else '1'
env = dict(os.environ, PYTHONPATH=i['installed'],
 PATH='/opt/homebrew/bin:/usr/bin:/bin', OPENBLAS_NUM_THREADS='1',
 OMP_NUM_THREADS='1', NUMBA_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
 CALMETRICS_TEST_EXPECT_ACCELERATE=enabled, CALMETRICS_TEST_EXPECT_EIGEN=enabled,
 CME_EXPECT_ACCELERATE=enabled, CME_EXPECT_EIGEN=enabled, CME_EXPECT_HIGHWAY=enabled)
python = [sys.executable, '-m', 'pytest']
if mode == 'asan':
    runtime = i['sanitizer_runtime']
    real = '/opt/homebrew/Cellar/python@3.12/3.12.11/Frameworks/Python.framework/Versions/3.12/Resources/Python.app/Contents/MacOS/Python'
    env.update(DYLD_INSERT_LIBRARIES=runtime, ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1',
               PYTHONPATH=i['installed'] + ':/Users/chenjunming/Desktop/myenv_312/lib/python3.12/site-packages')
    python = [real, str(D / 'asan_python_bootstrap.py'), runtime, real]
dest = D / (mode + '-qualification.json')
assert not dest.exists()
state = {'status':'running', 'build_id':i['build_id'], 'source_count':len(pre['source']),
         'test_source_count':len(pre['tests']), 'related_modules':related, 'jobs':[],
         'production_adopted':False, 'goal_complete':False}
jobs = [('regression', python + ['tests/test_gaussian_filter_stream.py', '-q',
         '-k', 'nested_replay_work_matches_observed_extra_computation']),
        ('native', ['/opt/homebrew/bin/ctest', '--test-dir', i['build'], '--output-on-failure']),
        ('related', python + related + ['-q', '--tb=short'])]
try:
    for label, cmd in jobs:
        xml = D / (mode + '-' + label + '.xml')
        log = D / (mode + '-' + label + '.log')
        cmd += (['--output-junit', str(xml)] if label == 'native' else ['--junitxml=' + str(xml)])
        with log.open('x') as out:
            child = subprocess.Popen(cmd, cwd=S, env=env, stdout=out, stderr=subprocess.STDOUT)
            state['current'] = {'label':label, 'pid':child.pid, 'command':cmd}
            dest.write_text(json.dumps(state, indent=2) + '\n')
            print('START', mode, label, child.pid, flush=True)
            code = child.wait()
        cases = list(ET.parse(xml).getroot().iter('testcase'))
        counts = {'tests':len(cases), 'failures':sum(c.find('failure') is not None for c in cases),
                  'errors':sum(c.find('error') is not None for c in cases),
                  'skipped':sum(c.find('skipped') is not None for c in cases)}
        state['jobs'].append({'label':label, 'returncode':code, 'counts':counts,
                             'log_sha256':sha(log), 'xml_sha256':sha(xml)})
        state.pop('current', None)
        if code:
            print(log.read_text()[-6000:], flush=True)
        assert code == 0 and counts['tests'] and not counts['failures'] and not counts['errors'], counts
        assert counts['skipped'] == 0, counts
        if label == 'regression': assert counts['tests'] == 4
        if label == 'native': assert counts['tests'] == 9
        print('PASS', mode, label, counts, flush=True)
    assert all(sha(S / n) == h for n, h in pre['source'].items())
    assert all(sha(S / n) == h for n, h in pre['tests'].items())
    state.update(status='passed', finished=time.time())
except BaseException as error:
    state.update(status='failed', error=repr(error))
    raise
finally:
    dest.write_text(json.dumps(state, indent=2) + '\n')
