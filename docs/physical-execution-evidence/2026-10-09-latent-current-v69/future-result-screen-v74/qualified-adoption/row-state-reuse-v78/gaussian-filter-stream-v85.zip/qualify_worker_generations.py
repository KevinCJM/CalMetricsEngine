"""Both directions of real stale-worker rejection, inline and shared transport."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
new = json.loads((D / "candidate/identity.json").read_text())
old = json.loads(Path("/private/tmp/calmetrics-latent-unwritten-result-v78-20261009/r2/actual/package/identity.json").read_text())
for identity in (old, new):
    assert all(sha(Path(identity["installed"]) / n) == h
               for n, h in identity["installed_binaries"].items())
probe = r'''
import hashlib, json, sys
import numpy as np
from calmetrics_engine import AdaptiveScheduler, GraphCompiler, PlannerConfig
bad_worker, expected_id, lane = sys.argv[1:]
cfg = PlannerConfig(thread_work_units=1, process_work_units=1,
                    min_rows_per_worker=1, max_processes=2,
                    shared_memory_threshold_bytes=1 if lane == 'shared' else 1 << 30)
graph = GraphCompiler({'x': 'series'}).compile('sum(x)')
values = np.linspace(1., 2., 1000); values.flags.writeable = False
starts = np.array([0, 500], np.int64); ends = np.array([500, 1000], np.int64)
before = hashlib.sha256(values.tobytes()).hexdigest()
errors = []
with AdaptiveScheduler(cpu_budget=2, config=cfg, worker_path=bad_worker) as scheduler:
    plan = scheduler.plan(graph, {'x': values}, starts, ends)
    assert plan.lane == 'process' and plan.use_shared_memory == (lane == 'shared')
    for _ in range(2):
        try:
            scheduler.execute(graph, {'x': values}, starts, ends, timeout=10)
        except RuntimeError as error:
            errors.append(str(error))
        else:
            raise AssertionError('mismatched native worker returned a result')
    assert errors == ['unsupported native worker response version'] * 2, errors
with AdaptiveScheduler(cpu_budget=2, config=cfg) as scheduler:
    first = scheduler.execute(graph, {'x': values}, starts, ends, timeout=10)
    saved = first.values.copy()
    second = scheduler.execute(graph, {'x': values}, starts, ends, timeout=10)
    assert first.audit['engine_build_id'] == expected_id
    assert first.audit['lane'] == 'process' and first.audit['native_processes'] == 2
    assert first.values.tobytes() == saved.tobytes() == second.values.tobytes()
    assert not np.shares_memory(first.values, second.values)
    np.testing.assert_allclose(first.values[:, 0], [values[:500].sum(), values[500:].sum()], rtol=1e-14)
    assert scheduler.peak_active_cpu_tokens <= 2
assert hashlib.sha256(values.tobytes()).hexdigest() == before
print(json.dumps(dict(status='passed', engine_build_id=expected_id, lane=lane,
                     errors=errors, input_unchanged=True, healthy_same_generation=True,
                     retained_output_unchanged=True, independent_output=True)))
'''
state = {"status": "running", "production_adopted": False, "records": [],
         "old_build_id": old["build_id"], "new_build_id": new["build_id"]}
dest = D / "worker-generations.json"
assert not dest.exists()
try:
    for name, parent, worker in (("new_parent_old_worker", new, old),
                                 ("old_parent_new_worker", old, new)):
        for lane in ("inline", "shared"):
            command = [sys.executable, "-c", probe,
                       str(Path(worker["installed"]) / "calmetrics_engine/calmetrics_worker"),
                       parent["build_id"], lane]
            env = dict(os.environ, PYTHONPATH=parent["installed"],
                       OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1")
            log = D / ("worker-generations-" + name + "-" + lane + ".log")
            with log.open("x") as output:
                child = subprocess.Popen(command, cwd=D, env=env, stdout=output, stderr=subprocess.STDOUT)
                state["current"] = {"direction": name, "lane": lane, "pid": child.pid}
                dest.write_text(json.dumps(state, indent=2) + "\n")
                code = child.wait()
            if code:
                print(log.read_text()[-6000:], flush=True)
            assert code == 0, (name, lane, code)
            raw = json.loads(log.read_text().splitlines()[-1])
            state["records"].append({"direction": name, "raw": raw, "log_sha256": sha(log)})
            state.pop("current", None)
            print("PASS", name, lane, flush=True)
    for identity in (old, new):
        assert all(sha(Path(identity["installed"]) / n) == h
                   for n, h in identity["installed_binaries"].items())
    state.update(status="passed_both_native_generations_inline_and_shared", finished=time.time())
except BaseException as error:
    state.update(status="failed", error=repr(error))
    raise
finally:
    dest.write_text(json.dumps(state, indent=2) + "\n")
