"""One fresh unchanged heap-driver replay; never rewrite the full evidence."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
P = D.parent / 'candidate-performance-plan-r3'
sys.path.insert(0, str(P))
import guard
import report_tools
import run_screen

registering_child = False
pending_signal = None


def save(path, obj):
    tmp = path.with_suffix('.tmp.json')
    tmp.write_text(json.dumps(obj, indent=2) + '\n')
    tmp.replace(path)


def interrupt(signum, _frame):
    global pending_signal
    if registering_child:
        pending_signal = signum
        return
    raise KeyboardInterrupt('replay interrupted: ' + str(signum))


def main():
    global registering_child
    assert sys.flags.optimize == 0 and sys.dont_write_bytecode
    assert sys.executable == '/Users/chenjunming/Desktop/myenv_312/bin/python3.12'
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupt)
    gates = guard.verify()
    m = guard.load_manifest()
    run_screen.assert_no_other_heavy()
    full = json.loads((P / 'full-r1/pipeline.json').read_text())
    assert full['status'] == 'passed_full_measurements_independent_review_pending'
    assert len(full['jobs']) == 42 and 'current' not in full
    original = next(j for j in full['jobs'] if j['name'] == 'student_large_c8_heap_candidate_njit')
    assert original['returncode'] == 0
    assert guard.sha(original['output']) == original['output_sha256']
    selected = m['packages']['candidate']
    job = dict(name='student_large_c8_heap_candidate_njit_cleanup_replay', case='large_c8',
               student=True, package='candidate', metric='heap', backend='njit', control='candidate')
    output = D / 'measurement.json'
    launch = D / 'launch.json'
    log = D / 'child.log'
    statepath = D / 'pipeline.json'
    assert not any(p.exists() for p in (output, launch, log, statepath))
    env = dict(os.environ, **m['thread_environment'])
    env.update(CME_OWNED_SOURCE_ROOT=selected['source'], CME_OWNED_INSTALL=selected['install'],
               CME_MC_SOURCE_ROOT=selected['source'], CME_MC_EXPECT_BUILD_ID=selected['build_id'],
               PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1',
               CME_PERF_PARENT_GUARD_MANIFEST_SHA=gates['manifest_sha256'])
    for key in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME', 'DYLD_INSERT_LIBRARIES'):
        env.pop(key, None)
    env['DYLD_INSERT_LIBRARIES'] = m['probe']
    command = [sys.executable, '-B', str(P / 'driver_launcher.py'), '--package', 'candidate',
               '--metric', 'heap', '--launch-evidence', str(launch), '--', '--case', 'large_c8',
               '--output', str(output), '--student', '--backend', 'njit', '--heap']
    state = dict(status='running', started_epoch=time.time(), pid=os.getpid(), command=command,
                 runner_sha256=guard.sha(__file__), original_job=original,
                 full_pipeline_sha256=guard.sha(P / 'full-r1/pipeline.json'),
                 original_numeric_driver_sha256=m['drivers']['owned']['sha256'],
                 source_adopted=False, goal_complete=False)
    child = None
    save(statepath, state)
    try:
        with log.open('x') as stream:
            registering_child = True
            try:
                child = subprocess.Popen(command, cwd=P, env=env, stdout=stream,
                                         stderr=subprocess.STDOUT, start_new_session=True)
                state['child_pid'] = child.pid
                state['child_started_epoch'] = time.time()
                save(statepath, state)
            finally:
                registering_child = False
            if pending_signal is not None:
                raise KeyboardInterrupt('replay interrupted during child registration: ' + str(pending_signal))
            print('START cleanup-overlap-heap-replay', child.pid, flush=True)
            while child.poll() is None:
                time.sleep(2)
                state['heartbeat_epoch'] = time.time()
                save(statepath, state)
        state['returncode'] = child.returncode
        state['child_finished_epoch'] = time.time()
        save(statepath, state)
        assert child.returncode == 0
        report = json.loads(output.read_text())
        report_tools.validate(report, job, json.loads(launch.read_text()), m)
        guard.verify()
        old = json.loads(Path(original['output']).read_text())
        before = old['measurement']['warm_peak_bytes']
        after = report['measurement']['warm_peak_bytes']
        state.update(status='passed_single_heap_cleanup_overlap_replay_independent_review_pending',
                     output=str(output), output_sha256=guard.sha(output),
                     launch=str(launch), launch_sha256=guard.sha(launch), log_sha256=guard.sha(log),
                     warm_peak_bytes=after, original_warm_peak_bytes=before,
                     warm_peak_difference_bytes=after-before,
                     fresh_assertions_passed=True, finished_epoch=time.time())
        print(json.dumps(dict(status=state['status'], warm_peak_bytes=after,
                              original_warm_peak_bytes=before, difference_bytes=after-before)), flush=True)
    except BaseException as error:
        run_screen.stop_child(child)
        state.update(status='failed', error=repr(error), finished_epoch=time.time(),
                     child_returncode=None if child is None else child.returncode)
        raise
    finally:
        save(statepath, state)


if __name__ == '__main__':
    main()
