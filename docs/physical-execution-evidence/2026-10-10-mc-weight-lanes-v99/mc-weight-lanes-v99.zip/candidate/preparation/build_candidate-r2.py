"""Root-controlled isolated builds, only after the current MC screen terminates."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
A = Path('/private/tmp/calmetrics-f-density-eigen-v93-20261010/adoption')
V98 = Path('/private/tmp/calmetrics-mc-owned-current-v98-20261010')
DEPS = Path('/private/tmp/calmetrics-multiroot-matmul-v65-20261008/build-deps')
parser = argparse.ArgumentParser()
parser.add_argument('--variant', choices=['normal','eigen-off','vectorization-off'], default='normal')
args = parser.parse_args()
assert sys.version_info[:2] == (3,12) and sys.prefix == '/Users/chenjunming/Desktop/myenv_312'
assert sys.flags.optimize == 0, 'source and ownership assertions must execute'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard = runpy.run_path(str(A/'actual_guards.py'))['guard']
guard()
runpy.run_path(str(D/'preflight.py'))
screen = json.loads((V98/'current-r1/pipeline.json').read_text())
assert screen['status'] == 'passed_current_owned_mc_screen_independent_review_pending'
assert len(screen['jobs']) == 30 and 'current' not in screen
# Existing CMake is supplied by Homebrew; offline build-deps contains Python tooling and Ninja.
assert Path('/opt/homebrew/bin/cmake').exists() and (DEPS/'scikit_build_core').is_dir()
root = D/'source'
stage = D/('package-candidate' if args.variant == 'normal' else 'package-'+args.variant)
build = D/('build-candidate' if args.variant == 'normal' else 'build-'+args.variant)
assert not stage.exists() and not build.exists(), 'fresh build/output directories required'
stage.mkdir()
env = dict(os.environ, PATH=str(DEPS/'bin')+':/opt/homebrew/bin:/usr/bin:/bin',
           PYTHONPATH=str(DEPS), PIP_NO_INDEX='1', CMAKE_BUILD_PARALLEL_LEVEL='1',
           MACOSX_DEPLOYMENT_TARGET='15.0', OPENBLAS_NUM_THREADS='1',
           OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', NUMBA_NUM_THREADS='1', MKL_NUM_THREADS='1')
env.pop('DYLD_INSERT_LIBRARIES',None)
env.pop('PYTHONOPTIMIZE',None)
def sources():
    names=sorted([str(p.relative_to(root)) for p in (root/'cpp').rglob('*') if p.is_file()]+['CMakeLists.txt','pyproject.toml'])
    return {n:sha(root/n) for n in names}
before=sources()
assert len(before)==93
eigen='OFF' if args.variant=='eigen-off' else 'ON'
flags='-DEIGEN_DONT_VECTORIZE' if args.variant=='vectorization-off' else ''
command=[sys.executable,'-m','pip','wheel','.', '--no-deps','--no-build-isolation',
         '-Cbuild-dir='+str(build),'-Ccmake.define.CALMETRICS_ENGINE_BUILD_TESTS=ON',
         '-Ccmake.define.CALMETRICS_ENGINE_USE_EIGEN='+eigen,
         '-Ccmake.define.CALMETRICS_ENGINE_USE_ACCELERATE=ON',
         '-Ccmake.define.CALMETRICS_ENGINE_USE_HIGHWAY=ON', '-w',str(stage/'wheels')]
if flags: command.append('-Ccmake.define.CMAKE_CXX_FLAGS='+flags)
state=dict(status='running', variant=args.variant, source=before, command=command,
           runner_sha256=sha(__file__), started_epoch=time.time(), adopted=False, goal_complete=False)
progress=stage/'progress.json'
progress.write_text(json.dumps(state,indent=2)+'\n')
print('START isolated V99',args.variant,flush=True)
try:
    with (stage/'build.log').open('x') as stream:
        child=subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
        state['pid']=child.pid
        progress.write_text(json.dumps(state,indent=2)+'\n')
        rc=child.wait()
    state['build_returncode']=rc
    if rc:
        print((stage/'build.log').read_text()[-7000:],flush=True)
        raise RuntimeError(('wheel build failed',rc))
    assert sources()==before, 'source changed during build'
    wheels=list((stage/'wheels').glob('*.whl'))
    assert len(wheels)==1
    install=stage/'install'
    with (stage/'install.log').open('x') as stream:
        subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(install),str(wheels[0])],
                       env=env,stdout=stream,stderr=subprocess.STDOUT,check=True)
    probe='''import sys,json;sys.path.insert(0,sys.argv[1])
import numpy as np
import calmetrics_engine as c
g=c.GraphCompiler({'x':'series'}).compile('sum(x)')
with c.AdaptiveScheduler(cpu_budget=1) as s:
 r=s.execute(g,{'x':np.array([1.])},np.array([0],np.int64),np.array([1],np.int64))
 print(json.dumps(dict(build_info=c.build_info(),engine_build_id=r.audit['engine_build_id'])))
'''
    actual=json.loads(subprocess.check_output([sys.executable,'-c',probe,str(install)],env=env,text=True))
    compiler=['0.3.0','AppleClang','17.0.0.17000603','arm64','Release',flags,'-O3 -DNDEBUG',
              'eigen_rotation='+eigen,'accelerate_covchol=ON','highway_order=ON']
    encoded=';'.join(compiler)+''.join(';'+n+':'+h for n,h in before.items())
    expected=hashlib.sha256(encoded.encode()).hexdigest()
    assert actual['engine_build_id']==expected
    assert expected!='79b494c5014e66ff1ded4c17ce46d0563018a5ffb551c0c40875bcda92045663'
    native=list((install/'calmetrics_engine').glob('_native*.so'))
    assert len(native)==1
    worker=install/'calmetrics_engine/calmetrics_worker'
    identity=dict(build_id=expected,source=before,compiler=compiler,build=str(build),installed=str(install),
                  wheel=str(wheels[0]),wheel_sha256=sha(wheels[0]),build_info=actual,
                  installed_binaries={str(p.relative_to(install)):sha(p) for p in (native[0],worker)})
    (stage/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    runpy.run_path(str(D/'preflight.py'))
    state.update(status='passed_isolated_build_identity_runtime_smoke_only',build_id=expected,guard=guard(),
                 finished_epoch=time.time(),identity_sha256=sha(stage/'identity.json'))
    print('PASS source/wheel/native/worker',expected,flush=True)
except BaseException as error:
    state.update(status='failed',error=repr(error),finished_epoch=time.time())
    raise
finally:
    progress.write_text(json.dumps(state,indent=2)+'\n')
