# V99: independent combination lanes for compact projection

Status: design and isolated candidate only. No build, imports, JIT, runtime,
pytest, numeric, heap/RSS, or performance execution is authorized here.

## Source and scope

The source is the actual 79b494c5014e66ff1ded4c17ce46d0563018a5ffb551c0c40875bcda92045663
snapshot recorded by V93 adoption/actual-package/identity.json. Every one of its
93 source identities must match before copying. Project R/F, V93 helpers,
V98 benchmark files, old archives, and actual installed package stay unchanged.
The only numerical source change is cpp/compact_path.cpp. No new public operator,
AST/DAG semantics, quantile selection, vForce, Student scale, RNG, result protocol,
CMake option, CPU budget, or global numerical cache is introduced.

## Problem and intended mechanism

At current compact_path.cpp:994-1008 every step/path repeats lane-major scalar
weight*asset-return, period left-fold, and contribution left-fold. C8 at
T=200/P=10000/A=32 performs 512 million independent lane/asset updates after
one shared affine/expm1 producer. This candidate uses already bundled Eigen
3.4.0 fixed-size Array<double,4,1> packets across independent combination lanes.
The 4-lane block is 32 bytes; Eigen selects actual CPU packet instructions.
This is not a claim about instruction counts or measured speed.

Packed weights use [asset,batch-lane] C layout, copied once per state batch from
read-only Value.f(asset), so C/F/strided/reversed source views retain logical
indexing. Existing contribution storage has the same number of doubles but uses
[asset,batch-lane] only in packet batches. Captured contribution scalars use an
explicit stride; post DAG, node order, result layout and owners are unchanged.

## Admission and fallback

Structural admission is determined in bind_geometry for both planning and actual
execution: affine source; batch>=4 and divisible by 4; assets>=1; every group has
exactly one contribution capture for every ascending asset; packed weights plus
period vector <=16384 doubles (128 KiB); at least 1048576 lane/asset updates in
one batch. All arithmetic extents use existing checked add/mul helpers.
Sparse or repeated per-asset captures stay on the existing scalar fold.
Duplicate public output roots that share one capture remain supported and retain
independent output slots; they do not create repeated arithmetic.

Budgeting is structural and never depends on current numeric values, thread
rounding state or library instructions. Without the existing Eigen compile
flag, with EIGEN_DONT_VECTORIZE, or without
Eigen EIGEN_VECTORIZE capability, reserve=0 and only the current scalar fold is
compiled. The current GraphCompiler/AdaptiveScheduler/execute_compact_path API
does not carry an Isa selector; simd_min_elements lists eligible plan nodes and
is not a graph execution ISA-off switch. Explicit scalar operator bindings do
not call compact_path and remain unchanged; no graph-level selector is invented.
At execution, packets
also require FE_TONEAREST and all current batch weights to be finite, not
subnormal and not negative zero. A batch whose count is not divisible by four
uses the current scalar fold. Numeric guard rejection merely leaves an admitted
small reserve unused; it does not request a different graph or numerical replay.
There is one existing scalar fold, not a retained obsolete implementation.

## Ordered arithmetic and errors

For each step, then each path, visit independent four-lane blocks. Within each
block, iterate assets in their original ascending order. Each four-lane Eigen
product is materialized before separate period and contribution additions. No
Eigen horizontal sum, matrix multiplication,
subtotal, tree reduction, FMA, fast-math, or parallel library execution is used.
Each period starts at +0 and has the identical asset left-fold. Each asset/lane
contribution starts at +0 and accumulates in the identical step->path order.
This candidate does not spend the user four-decimal tail-difference allowance:
existing exact discrete/IEEE/error and numerical contracts are retained.

After all asset updates, the original lane-ordered NAV/peak/max-DD code runs.
Products involving nonfinite asset returns or signed zero still use strict IEEE
multiply/add in each independent lane; there is no new eager rejection or
value-dependent numerical fallback. Weight special values reject packet use.
No exceptions are thrown by the private product loop; existing deferred errors,
canonical post execution, probability errors, zero denominators and original
node-order replay remain authoritative. Cancellation/checkpoint boundaries are
unchanged. Changing order between independent lanes cannot affect an input,
owner, numerical dependency or deferred error record.

## Workspace, cost and ownership

Additional workspace is exactly batch*assets + batch doubles for admitted
geometry, at most 131072 bytes. C8/A32 adds 2112 bytes, C4/A32 adds 1056 bytes.
Existing batch*assets contribution memory is reused, not duplicated. The new
period vector is batch doubles, written once per block/step/path. A fixed local
Packet period starts at +0 and stays local during the complete asset fold,
avoiding workspace read/write traffic at every asset. It is included in
Geometry.doubles and therefore compact budget, planner worker capacity and
Workspace.ensure. It is not heap-allocated inside the loop. Eigen Array product and period
are two fixed 32-byte locals (64 bytes total before compiler register allocation);
maps are small non-owning descriptors. Final stack size must be inspected in the
compiled candidate; this static count is not a stack/allocator audit. Expressions
use fixed-size arrays only; no dynamic Eigen storage. No BLAS/OpenMP threads.

Weights are copied per batch per interval, respecting ordinary input binding and
prepared snapshot lifetimes. No packed data survives request ownership or is
cached by pointer. Result writes remain in independently owned root slots. The
single-batch weight pack volume is budgeted and added to algorithm_copy_bytes.
For C8/A32 it copies exactly 2048 weight bytes; the extra 64 period bytes make
2112 bytes of algorithm scratch. Boundary input/result zero-copy counters are
unchanged and must not hide this necessary private algorithm copy.
Existing physical_work retains the same mathematical lane updates and gains the
actual pack/read work estimate. Existing vector_elements counts actual packet
product lanes, not presumed SIMD instructions; no public audit field is added.
Library absence or runtime rejection keeps the one scalar path and zero packet
counts. Memory and time benefits must be measured together with two retained
result generations; kilobyte reserves are disclosed, not used as a veto.

## Static and later runtime acceptance

Static phase: source identity guard; file hash manifest; patch review; Python
ast.parse for regression tests; verify exact unchanged files and archives. C++
compilation is explicitly deferred, so syntax and instantiation are unproved.

Regression tests compare all original selected roots bitwise with the same
native canonical DAG made public by an existing intermediate root. Cases cover
C1/C4/C5/C6/C8/C9 (including packet main batches and scalar tails),
dense/sparse/duplicate output captures, C/F/strided/reversed inputs,
C/F outputs, positive and negative zero, nonfinite weights and producer values,
invalid q5/qreturn versus zero initial NAV error priority, NaN inputs plus
independent weight/q input-binding shape faults, prepared/ordinary,
two independent output generations, exact memory-budget admission, and prepared
repacking after original-address weight mutation. Packet accounting is independently
checked by comparison with a sparse scalar-admitted compact graph. The two NaN-plus-shape cases fail at input binding before any NaN arithmetic;
they do not prove downstream multi-hop/scope validation. Existing upstream
structure validation is unchanged byte-for-byte; full regressions remain required.
Public mathematical oracle/tolerances are not weakened. Existing compact/raw-prefix/
state-batching, typed results, transport, native and sanitizer checks remain
required; their prior results do not prove this candidate.

Main-thread-only later builds: Release wheel and native tests with existing
Eigen ON. Also build Eigen OFF and Eigen EIGEN_DONT_VECTORIZE into separate directories
to confirm fallback compiles and regression outputs (set
CME_EXPECT_WEIGHT_LANES=0 for these builds). Candidate build identity must differ from
79; all source/native/worker/wheel/package identities must match. Do not rename
79 results as candidate results. Run serial, same CPU1 and same process sampling.

Performance: reuse V98 fair_owned_chain and fair_rss_modes unchanged. Select
candidate source/install with existing environment parameters and preserve the
actual79 baseline. First large_c8 normal/Student, then large_c1 and short_many;
full-chain warmed alternating time, continuous owned heap, and fresh sampled
RSS all return fan/14 stats/12 samples/all contributions and retain two owners.
A local kernel win is insufficient. Covariance root, coverage/limits/JSON and
stage-ordered upstream first-fault remain outside this successful owned chain.

Reject adoption if correctness/error/ownership/budget fails, or medium/large
full-chain runtime/memory tradeoffs are not worthwhile. This mechanism removes
many repeated scalar lane updates but adds packing and scalar-to-packet control;
compiler auto-vectorization may already be effective. No seconds-level speedup
or memory reduction is guaranteed before paired measurement.
