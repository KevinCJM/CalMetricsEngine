"""Serial isolated numerical qualification; all outputs are fresh and hashed."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import runpy
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

D=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--variant',choices=['normal','eigen-off','vectorization-off'],default='normal')
parser.add_argument('--full',action='store_true')
args=parser.parse_args()
assert sys.flags.optimize == 0, 'source and ownership assertions must execute'
stage=D/('package-candidate-r3' if args.variant=='normal' else 'package-'+args.variant)
root=D/'source'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
guard=runpy.run_path('/private/tmp/calmetrics-f-density-eigen-v93-20261010/adoption/actual_guards.py')['guard']
def verify():
    runpy.run_path(str(D/'preflight.py'))
    guard()
    identity=json.loads((stage/'identity.json').read_text())
    assert all(sha(root/n)==h for n,h in identity['source'].items())
    assert sha(identity['wheel'])==identity['wheel_sha256']
    assert all(sha(Path(identity['installed'])/n)==h for n,h in identity['installed_binaries'].items())
    with zipfile.ZipFile(identity['wheel']) as z:
        names=[n for n in z.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
        assert len(names)==25
        assert all((Path(identity['installed'])/n).read_bytes()==z.read(n) for n in names)
    return identity
identity=verify()
out=D/('qualification-'+args.variant+('-full-r4' if args.full else '-focused-r4'))
out.mkdir(exist_ok=False)
expect_eigen='0' if args.variant=='eigen-off' else '1'
expect_packets='1' if args.variant=='normal' else '0'
env=dict(os.environ,PYTHONPATH=identity['installed'],PATH='/opt/homebrew/bin:/usr/bin:/bin',
         OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',NUMBA_NUM_THREADS='1',MKL_NUM_THREADS='1',
         CALMETRICS_TEST_EXPECT_ACCELERATE='1',CALMETRICS_TEST_EXPECT_EIGEN=expect_eigen,
         CME_EXPECT_ACCELERATE='1',CME_EXPECT_EIGEN=expect_eigen,CME_EXPECT_HIGHWAY='1',CME_EXPECT_WEIGHT_LANES=expect_packets)
env.pop('DYLD_INSERT_LIBRARIES',None)
env.pop('PYTHONOPTIMIZE',None)
jobs=[('focused',[sys.executable,'-m','pytest','tests/test_compact_weight_lanes.py','-q','--tb=short'],49),
      ('native',['/opt/homebrew/bin/ctest','--test-dir',identity['build'],'--output-on-failure'],9)]
if args.full:
    assert args.variant=='normal', 'full suite is the normal selected package qualification'
    jobs.append(('full',[sys.executable,'-m','pytest','tests','-q','--tb=short'],17175))
else:
    related=['test_mc_compact_graph.py','test_compact_path_execution.py','test_raw_state_batching.py',
             'test_raw_factor_prefix.py','test_compact_parent_storage.py','test_axis_path_primitives.py',
             'test_mc_projection_primitives.py','test_affine_projection_library.py','test_typed_results.py',
             'test_dense_layout_transport.py','test_affine_projection_transport.py']
    jobs.append(('related',[sys.executable,'-m','pytest',*['tests/'+n for n in related],'-q','--tb=short'],None))
state=dict(status='running',variant=args.variant,build_id=identity['build_id'],jobs=[],goal_complete=False,
           source_adopted=False,runner_sha256=sha(__file__),full_requested=args.full)
dest=out/'qualification.json'
try:
    for label,cmd,expected in jobs:
        verify()
        log=out/(label+'.log');xml=out/(label+'.xml')
        cmd += ['--output-junit',str(xml)] if label=='native' else ['--junitxml='+str(xml)]
        with log.open('x') as stream:
            child=subprocess.Popen(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
            state['current']=dict(label=label,pid=child.pid,started_epoch=time.time(),command=cmd)
            dest.write_text(json.dumps(state,indent=2)+'\n')
            print('START',label,child.pid,flush=True)
            rc=child.wait()
        cases=list(ET.parse(xml).getroot().iter('testcase'))
        counts=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),
                    errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
        state['jobs'].append(dict(label=label,returncode=rc,counts=counts,log=str(log),log_sha256=sha(log),
                                 xml=str(xml),xml_sha256=sha(xml)))
        state.pop('current',None)
        dest.write_text(json.dumps(state,indent=2)+'\n')
        if rc or counts['failures'] or counts['errors'] or counts['skipped']:
            print(log.read_text()[-7000:],flush=True)
            raise RuntimeError((label,rc,counts))
        assert expected is None or counts['tests']==expected,(label,counts,expected)
        assert len({(c.get('classname'),c.get('name')) for c in cases})==len(cases)
        print('PASS',label,counts,flush=True)
    verify()
    state.update(status='passed_isolated_qualification_independent_review_pending',finished_epoch=time.time())
except BaseException as error:
    state.update(status='failed',error=repr(error),finished_epoch=time.time())
    raise
finally:
    dest.write_text(json.dumps(state,indent=2)+'\n')
