"""Standard-library source guard; no runtime or numerical imports."""
from pathlib import Path
import ast
import hashlib
import json
D = Path(__file__).resolve().parent
M = json.loads((D / "manifest.json").read_text())
R = Path("/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine")
S = D / "source"
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
changes = {e["path"]: e["candidate_sha256"] for e in M["candidate_changes"]}
for e in M["source_copies"]:
    assert sha(R / e["path"]) == e["original_sha256"], e["path"]
    assert sha(S / e["path"]) == changes.get(e["path"], e["copied_sha256"]), e["path"]
for e in M["added_files"]:
    assert sha(S / e["path"]) == e["candidate_sha256"], e["path"]
for p, digest in M["protected_sha256"].items():
    assert sha(p) == digest, p
for p in S.rglob("*.py"):
    ast.parse(p.read_text(), filename=str(p))
assert sha(D / "candidate.patch") == M["candidate_patch_sha256"]
assert sha(D / "DESIGN.md") == M["design_sha256"]
assert sha(D / "README.md") == M["readme_sha256"]
assert sha(D / "static-review.json") == M["static_review_sha256"]
assert sha(D / "preflight.py") == M["preflight_sha256"]
print("PASS static only", M["baseline_build_id"], "snapshot", len(M["source_copies"]),
      "changed", len(M["candidate_changes"]), "added", len(M["added_files"]),
      "protected", len(M["protected_sha256"]), "Python AST", M["python_ast_files_checked"])
