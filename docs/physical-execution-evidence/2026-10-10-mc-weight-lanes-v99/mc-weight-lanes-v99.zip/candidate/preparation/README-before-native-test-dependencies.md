# V99 isolated compact combination-lane candidate

Prepared against actual79, not adopted into either project. Read DESIGN.md and
manifest.json. No compile/import/JIT/pytest/numeric/performance run has occurred.
The only changed numerical source is source/cpp/compact_path.cpp; the new test
file defines 45 unexecuted cases. All other 330 snapshot files remain exact.

## Main-thread-only build/verification after active replay finishes

Run `python3 preflight.py` first and after all verification. It is standard-library
only and guards actual79, projects, V98 and every candidate source. Never change
those identities merely to get a pass. Build/install/results all belong under
this fresh V99 directory; no global venv package replacement or old artifact
rename. Use the existing parent wheel/build identity workflow to create fresh
package-candidate/identity.json and package-candidate/install, including source,
compiler/options, wheel, native and worker identities. Candidate build_id must
be freshly obtained, not copied from actual79.

An equivalent Release wheel build command (not executed):

```sh
CMAKE_BUILD_PARALLEL_LEVEL=1 /Users/chenjunming/Desktop/myenv_312/bin/python3.12 -m pip wheel --no-deps --no-build-isolation ./source --wheel-dir ./package-candidate/wheels --config-settings=build-dir=/private/tmp/calmetrics-mc-weight-lanes-v99-20261010/build-candidate --config-settings=cmake.define.CALMETRICS_ENGINE_USE_EIGEN=ON
```

Install this wheel into a new --target package-candidate/install and write the
same validated identity schema as actual79. Do not run this before the current
V93 heavy pipeline ends. Parent controls dependencies, packaging, CPU and disk.

Run the isolated 45-case file first against that selected installed package,
then the existing full regressions, native and ASan/UBSan pipelines (9 tests
each in the current parent chain; neither candidate pipeline has run). Explicitly
verify source/wheel identity and loaded native/worker ownership. Normal target
new tests expect packet counters; Eigen-OFF and EIGEN_DONT_VECTORIZE builds use
CME_EXPECT_WEIGHT_LANES=0 and separate build/install paths. Existing CMake build
identity includes CMAKE_CXX_FLAGS, so the vectorization-off flags are recorded.
Do not suppress any failed case by loosening exact IEEE/discrete tests.

Focused regression invocation from source/ (not executed):

```sh
PYTHONPATH=/private/tmp/calmetrics-mc-weight-lanes-v99-20261010/package-candidate/install /Users/chenjunming/Desktop/myenv_312/bin/python3.12 -m pytest tests/test_compact_weight_lanes.py -q
```

CMake native builds should use separate native/ and sanitized/ directories,
CALMETRICS_ENGINE_BUILD_PYTHON=OFF and CALMETRICS_ENGINE_BUILD_TESTS=ON, with
CALMETRICS_ENGINE_SANITIZE=ON for the sanitized build, and main-thread serial
ctest. Additionally compile Eigen OFF and Eigen DONT_VECTORIZE paths; they are
not proven merely by the preprocessor source check. CMake and public APIs are
unchanged. The graph API has no Isa scalar selector: standalone operator scalar
bindings are unaffected and do not call compact_path.

## Fair complete-chain performance

Reuse V98 drivers/support as-is. Set CME_OWNED_SOURCE_ROOT to this source/ and
CME_OWNED_INSTALL to package-candidate/install for candidate invocations. The
existing driver reads that install's sibling identity and sets its expected
build_id/source-root guard. Leave the actual79 baseline selection as-is.

First large_c8 normal and Student, then large_c1 and short_many: warmed alternating
complete time, continuous whole-owned-chain heap with the same probe on both
backends, and fresh no-probe RSS with V98 fair_rss_modes.py default normal or
--student. All numerical data, 14 statistics, fan, sample paths, contributions,
seed preparation, CPU1 and two retained generations remain identical. Repeat
paired endpoint runs after test success; a local product-loop win is insufficient.

New hit evidence is exact vector_elements delta versus an otherwise identical
sparse compact scalar fence. Old affine packets are on both sides. Asset-major
contribution storage is private only and is read with actual batch count stride.
All fan sorting, post DAG, root shapes/order and independent owners stay intact.

C8/A32 uses 2048B necessary weight copying plus 64B period workspace: 2112B
algorithm scratch, not boundary zero-copy. The planner includes all 2112B;
algorithm_copy_bytes records only the 2048B weight copying per batch, because
the 64B period workspace is not a copy. Existing contribution memory is reused.
Two 32B fixed
Array locals (64B before compiler allocation) require later frame/instruction
inspection; no dynamic Eigen allocations or new threads are intended.

There is no measured benefit yet. Do not claim memory reduction or seconds-level
speedup. Current mature affine producer already shares work and fan sorting may
remain dominant. Covariance root, coverage/limits/JSON and upstream ordered fault
protocol stay outside this complete owned consumer benchmark.
