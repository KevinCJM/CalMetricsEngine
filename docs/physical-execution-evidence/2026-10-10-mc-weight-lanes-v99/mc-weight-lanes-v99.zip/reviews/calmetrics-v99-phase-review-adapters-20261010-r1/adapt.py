"""Only light evidence/SHA/XML/package parsing; never builds, tests or adopts."""
from pathlib import Path
import copy
import hashlib
import json
import runpy
import time

O = Path(__file__).resolve().parent
P = Path('/private/tmp/calmetrics-v99-adoption-plan-20261010/r7')
A = Path('/private/tmp/calmetrics-f-density-eigen-v93-20261010')
S79 = A/'r5/source'
D = Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010')
R = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
ROOT = Path('/private/tmp/calmetrics-v99-root-adoption-admission-20261010-r1')
LIVE = str(R/'cpp/compact_path.cpp')
OLD = '4c85e0c60811a8da447905edc8f180df92cbbae563100bf6349903ab0d408680'
NEW = 'c7115c1acdd934d19c3bad68705a1bab88a158199c095438f034e33d78a584d4'
PARENTS = {
    'all-mode': (Path('/private/tmp/calmetrics-v99-modes-independent-review-20261010-r1/reviewed.json'),
                 'fd0ee65161808dcb5ff28d03f1ee8886260f3dcbc30b74586c7a97da1a92a011'),
    'full-chain': (Path('/private/tmp/calmetrics-v99-full-review-adapter-r2-20261010/reviewed.json'),
                   '39c9bcaae3818b1169be13d7cf22d4d877b5619671220822b5e48128f01da794'),
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def save(name, value):
    path = O/name
    assert not path.exists(), path
    path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
    return path

def main():
    assert not (O/'all-mode-reviewed.json').exists() and not (O/'full-chain-reviewed.json').exists()
    guard = runpy.run_path(str(P/'guard.py'))
    m = guard['manifest']()
    old_identity_path = A/'adoption/actual-package/identity.json'
    old_identity = load(old_identity_path)
    assert old_identity['build_id']=='79b494c5014e66ff1ded4c17ce46d0563018a5ffb551c0c40875bcda92045663'
    assert len(old_identity['source'])==93 and old_identity['source']==m['native_before']
    preimages={str(S79/name):sha(S79/name) for name in old_identity['source']}
    assert all(preimages[str(S79/name)]==h for name,h in old_identity['source'].items())
    assert sha(S79/'cpp/compact_path.cpp')==OLD and sha(LIVE)==NEW
    native_delta={name:(old_identity['source'][name],h) for name,h in m['native_after'].items() if h!=old_identity['source'][name]}
    assert native_delta=={'cpp/compact_path.cpp':(OLD,NEW)}
    source_adoption_path=ROOT/'source-adoption.json'
    source_adoption=load(source_adoption_path)
    assert source_adoption['status']=='qualified_v99_two_source_files_adopted_actual_rebuild_pending'
    assert source_adoption['files']==m['adoption_changes'] and len(source_adoption['files'])==2
    assert source_adoption['source_adopted'] is True and source_adoption['production_adopted'] is False
    code_guard=guard['verify']('code')
    assert code_guard==source_adoption['code_guard'] and code_guard['project_modified_by_this_guard'] is False
    code_proof_path=save('code-guard-proof.json',{
        'status':'independently_rechecked_r7_code_guard_after_authorized_two_file_source_adoption',
        'r7_guard':str(P/'guard.py'),'r7_guard_sha256':sha(P/'guard.py'),
        'r7_manifest':str(P/'manifest.json'),'r7_manifest_sha256':sha(P/'manifest.json'),
        'source_adoption_receipt':str(source_adoption_path),'source_adoption_receipt_sha256':sha(source_adoption_path),
        'code_guard_result':code_guard,'adoption_changes':source_adoption['files'],
        'read_only':True,'build_execution':False,'qualification_execution':False,'root_decision_written':False,
        'observed_epoch':time.time(),
    })
    preimage_proof_path=save('actual79-preimage-proof.json',{
        'status':'immutable_actual79_source_preimage_93_hashes_match_identity',
        'source_root':str(S79),'identity_path':str(old_identity_path),'identity_sha256':sha(old_identity_path),
        'historical_build_id':old_identity['build_id'],'source_files':93,'source_sha256':old_identity['source'],
        'immutable_preimage_sha256':preimages,
        'compact_preimage':str(S79/'cpp/compact_path.cpp'),'compact_preimage_sha256':OLD,
        'scope':'Historical actual79 preimage; not current R source, not a fresh actual build or performance run.',
    })
    failure_path=ROOT/'post-source-gate-failure.json'
    failure=load(failure_path)
    assert failure['build_started'] is False and failure['actual_attempt_directory_created'] is False
    assert not (P/'actual-r1').exists()
    parents={}
    for kind,(path,expected) in PARENTS.items():
        assert sha(path)==expected
        parent=load(path)
        assert parent['confirmed_blockers']==[] and parent['evidence_sha256'][LIVE]==OLD
        mismatches=[(name,h,sha(name)) for name,h in parent['evidence_sha256'].items() if sha(name)!=h]
        assert mismatches==[(LIVE,OLD,NEW)],(kind,mismatches)
        assert failure['mismatches'][str(path)]==[[LIVE,OLD,NEW]]
        parents[kind]=parent
    decision_path=ROOT/'adoption-decision.json'
    decision=load(decision_path)
    assert [(n,h,sha(n)) for n,h in decision['evidence_sha256'].items() if sha(n)!=h]==[(LIVE,OLD,NEW)]
    historical={
        'mutable_live_path':LIVE,'historical_observed_sha256':OLD,
        'historical_live_reference_no_longer_current':True,
        'immutable_actual79_preimage':str(S79/'cpp/compact_path.cpp'),
        'immutable_actual79_preimage_sha256':OLD,
        'immutable_actual79_identity':str(old_identity_path),'immutable_actual79_identity_sha256':sha(old_identity_path),
        'all_93_preimage_hashes_verified':True,'preimage_proof':str(preimage_proof_path),'preimage_proof_sha256':sha(preimage_proof_path),
        'historical_fact':'Original reviews bound actual R compact to 4c85 before source adoption; this fact is retained, not retested or relabeled.',
    }
    current={
        'current_actual_path':LIVE,'current_actual_sha256':NEW,
        'source_adoption_receipt':str(source_adoption_path),'source_adoption_receipt_sha256':sha(source_adoption_path),
        'code_guard_proof':str(code_proof_path),'code_guard_proof_sha256':sha(code_proof_path),
        'scope':'Current c711 proves authorized post-source-copy state only; never historical measurement source or installed actual build.',
        'authorized_changed_files':[i['path'] for i in source_adoption['files']],
        'actual_build_started':False,'actual_attempt_directory_exists':False,
    }
    common_add={str(old_identity_path):sha(old_identity_path),str(source_adoption_path):sha(source_adoption_path),
                str(code_proof_path):sha(code_proof_path),str(preimage_proof_path):sha(preimage_proof_path),
                str(failure_path):sha(failure_path),str(P/'manifest.json'):sha(P/'manifest.json'),
                str(P/'guard.py'):sha(P/'guard.py')}
    common_add.update(preimages)
    adapted={}
    for kind,parent in parents.items():
        path,parent_sha=PARENTS[kind]
        value=copy.deepcopy(parent)
        value['evidence_sha256'][LIVE]=NEW
        value['evidence_sha256'].update(common_add)
        value['evidence_sha256'][str(path)]=parent_sha
        value['phase_adapter_schema']='v99-historical-live-path-phase-adapter-1'
        value['phase_parent_review']=str(path)
        value['phase_parent_review_sha256']=parent_sha
        value['historical_live_path_ref']=historical
        value['adopted_source_state_ref']=current
        value['phase_adapted_epoch']=time.time()
        value['phase_proof_scope']='Evidence path phase adaptation only; all old result fields, raw files, requirements, limits, cleanup and gate schema retained.'
        assert {k:v for k,v in value.items() if k in parent and k!='evidence_sha256'} == {k:v for k,v in parent.items() if k!='evidence_sha256'}
        oldmap,newmap=parent['evidence_sha256'],value['evidence_sha256']
        assert not set(oldmap)-set(newmap)
        assert {k for k in oldmap if oldmap[k]!=newmap[k]}=={LIVE}
        assert all(sha(name)==h for name,h in newmap.items())
        adapted[kind]=value
    # Reuse the independently written stdlib package/XML parser, never its main/old source guards.
    independent=runpy.run_path('/private/tmp/calmetrics-v99-modes-independent-review-20261010-r1/audit.py')
    normal=load(D/'package-candidate-r3/identity.json')
    mode_required={}
    mode_checks={}
    for mode,spec in m['qualification_mode_plans'].items():
        q=load(spec['pipeline'])
        assert q['status']=='passed_qualification_independent_review_pending' and 'current' not in q
        binding=guard['qualification_binding'](mode,spec['pipeline'],q,m)
        assert binding==adapted['all-mode']['mode_bindings'][mode]
        assert sha(spec['pipeline'])==adapted['all-mode']['pipeline_sha256'][mode]
        mode_required.update(spec['proof_sha256'])
        expected={tuple(x) for x in m['expected_ids']['full' if mode=='normal-full' else 'eigen_off_affected' if mode=='eigen-off' else 'affected']}
        jobs={j['label']:j for j in q['jobs']}
        for job in q['jobs']:
            assert job['returncode']==0
            for key in ['log','xml','collection']:
                if key in job: mode_required[job[key]]=job[key+'_sha256']
        actual,counts=independent['xml_cases'](jobs['python']['xml'])
        native,native_counts=independent['xml_cases'](jobs['native']['xml'])
        assert actual==expected and native=={tuple(x) for x in m['native_ids']}
        guard['collection_nodes'](jobs['collection']['log'],expected)
        pkg=independent['package_check'](q['identity'],mode,q['package_audit'],normal)
        mode_checks[mode]={'binding_exact':True,'python':counts,'native':native_counts,
                           'package_payloads':pkg['audit']['package_payloads'],'cpp_tus':pkg['cpp_tu_count'],
                           'build_id':q['identity']['build_id'],'private_identity_sha256':binding['private_identity_sha256']}
    guard['bound_evidence'](adapted['all-mode']['evidence_sha256'],mode_required)
    full_path=adapted['full-chain']['pipeline']
    full_required=guard['snapshot_full_chain'](full_path,adapted['full-chain'],m)
    assert len(load(full_path)['jobs'])==42 and adapted['full-chain']['verified_load_count']==6
    assert adapted['full-chain']['parent_review_sha256']==parents['full-chain']['parent_review_sha256']
    assert adapted['full-chain']['cleanup_supplement_sha256']==parents['full-chain']['cleanup_supplement_sha256']
    assert adapted['full-chain']['comparison_rows_preserved']==parents['full-chain']['comparison_rows_preserved']
    assert adapted['full-chain']['negative_results_preserved']==parents['full-chain']['negative_results_preserved']
    guard['bound_evidence'](adapted['full-chain']['evidence_sha256'],full_required)
    for path,expected in PARENTS.values(): assert sha(path)==expected
    for kind,value in adapted.items(): save(kind+'-reviewed.json',value)
    checks={
        'status':'passed_independent_review_phase_adaptation_no_gate_change',
        'parent_reviews':{k:{'path':str(v[0]),'sha256':v[1]} for k,v in PARENTS.items()},
        'only_prior_evidence_hash_delta':{LIVE:{'historical':OLD,'current':NEW}},
        'historical_preimage_source_count':93,'code_guard':code_guard,
        'four_mode_checks':mode_checks,'required_mode_raw_files':len(mode_required),
        'required_full_chain_raw_files':len(full_required),
        'all_required_maps_unchanged_and_bound':True,'old_receipts_raw_logs_and_cleanup_unchanged':True,
        'root_decision_written':False,'admission_called_with_new_decision':False,
        'guard_runner_schema_math_performance_control_gate_changed':False,
        'actual_build_test_perf_import_executed':False,'actual_attempt_directory_exists':False,
        'new_reviews':{k:{'path':str(O/(k+'-reviewed.json')),'sha256':sha(O/(k+'-reviewed.json'))} for k in adapted},
        'phase_epoch':time.time(),
    }
    save('phase-checks.json',checks)
    print(json.dumps({'status':checks['status'],'new_reviews':checks['new_reviews'],
                      'required_mode_raw_files':len(mode_required),'required_full_chain_raw_files':len(full_required)},indent=2))

if __name__=='__main__':
    main()
