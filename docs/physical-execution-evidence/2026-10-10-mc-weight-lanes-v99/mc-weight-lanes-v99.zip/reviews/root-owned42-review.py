from pathlib import Path
import datetime
import hashlib
import json
import statistics
import sys

if sys.flags.optimize or not sys.dont_write_bytecode:
    raise SystemExit('review requires -B, optimize=0')
R = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
D = Path('/private/tmp/calmetrics-v99-adoption-plan-20261010/r7')
I = Path('/private/tmp/calmetrics-v99-actual-owned42-independent-review-20261010-r1')
O = Path('/private/tmp/calmetrics-v99-actual-owned42-root-review-20261010-r1')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def load(p):
    return json.loads(Path(p).read_text())

expected = {
    I / 'reviewed.json': 'b459a99a136fb07602e962eba21808c1ccdd7ad9abbd497c52e313e7f123d693',
    I / 'manifest.json': 'db4f0c60f398be76aa3afe590991be37654ac33b14a8173015c2b9d5e2dd3d6f',
    I / 'sha256-receipt.json': '548ebdf9034487892e7f328ed32fca1980c0956660f327d48385b0e08aa29fef',
    D / 'manifest.json': '6513a4fd12b0f2c003466043bbf76c3e81b73a3ce82ff9e681a7d7f10f73a43f',
    D / 'replay-r1/manifest.json': '885742ad47010f7a12c0ad32e1ec400c14e6b4a0c551cb838df6f60d5280da84',
    D / 'replay-r1/pipeline.json': 'f6d756ca562052f8d212c724ddaf3d5721de2d4bfc7d998eb9e3838ab75b5e07',
    D / 'actual-r2/package/identity.json': 'c89bb454821ddc73784af69c30bbb0a33748eaccaa15a69787b5071111c0cf53',
    Path('/private/tmp/calmetrics-v99-actual-full-root-review-20261010-r1/reviewed.json'): '56229f119d642d3974d60d9048a48f5f3c129e3545683c7a31647aecc531123c',
    Path('/private/tmp/calmetrics-v99-actual-affected-root-review-20261010-r1/reviewed.json'): 'a103b30b526601ede1809e78ca981c86d42c1c328067cf985137b0158f65cf7c',
    R / 'cpp/compact_path.cpp': 'c7115c1acdd934d19c3bad68705a1bab88a158199c095438f034e33d78a584d4',
    R / 'tests/test_compact_weight_lanes.py': 'a90300283c4a07c82e9cc698d97b6b9938f409eb6c3e253ec3fd461486bf85a7',
    Path('/private/tmp/calmetrics-requested-compile-cache-cleanup-20261010-extra-r1/result.json'): 'f713d8fa7ef781d011d75ebd995b60563a274c4885c3e82c83864d2333b51020',
}
for p, value in expected.items():
    assert sha(p) == value, str(p)
independent = load(I / 'reviewed.json')
pipeline = load(D / 'replay-r1/pipeline.json')
identity = load(D / 'actual-r2/package/identity.json')
assert independent['confirmed_blockers'] == []
assert independent['actual_owned42_replay_verified'] and independent['normal_non_sanitizer']
assert not independent['overall_performance_accepted'] and not independent['goal_complete']
assert identity['build_id'] == 'f789954a788004453f362c5aba57f9606c3a37d3148d63875c27ae8dae853434'
assert pipeline['status'] == 'passed_actual_owned_full_chain_independent_review_pending'
assert len(pipeline['jobs']) == independent['jobs_reviewed'] == 42
labels = [j['label'] for j in pipeline['jobs']]
assert len(set(labels)) == 42 and 'current' not in pipeline and 'error' not in pipeline
for j in pipeline['jobs']:
    assert j['returncode'] == 0
    for field in ('output', 'log', 'launch'):
        assert sha(j[field]) == j[field + '_sha256']
        expected[Path(j[field])] = j[field + '_sha256']
rows = []
assert len(independent['rows']) == 6
for row in independent['rows']:
    prefix = ('student' if row['student'] else 'normal') + '_' + row['case']
    originals = {part: load(D / 'replay-r1' / (prefix + '_time_' + package + '.json'))
                 for part, package in [('before','actual79_before'), ('actual99','actual99'), ('after','actual79_after')]}
    for part, raw in originals.items():
        assert raw['cpu_budget'] == 1 and raw['two_result_generations_retained']
        assert not raw['experimental_native_rng_used_inside_measured_calls']
        assert raw['parity']['static_inputs_unchanged']
        for backend in ('cpp', 'njit'):
            assert statistics.median(raw['samples'][backend + '_ms']) == raw['medians_ms'][backend + '_ms']
    cpp = originals['actual99']['medians_ms']['cpp_ms']
    ni = min(x['medians_ms']['njit_ms'] for x in originals.values())
    old = min(originals[x]['medians_ms']['cpp_ms'] for x in ('before','after'))
    assert cpp == row['time']['actual99_ms'] and ni == row['time']['conservative_njit_ms']
    assert ni / cpp == row['time']['conservative_speedup']
    assert cpp / old == row['time']['actual99_cpp_over_stronger_actual79']
    for metric, fields in [('heap', [('cold_peak_bytes','cold_peak_bytes'),('warm_peak_bytes','warm_peak_bytes')]),
                          ('rss', [('rss_baseline','rss_baseline'),('rss_peak','rss_peak'),('rss_delta','rss_delta')])]:
        raws = {backend: load(D / 'replay-r1' / (prefix + '_' + metric + '_' + package + '.json'))
                for backend, package in [('actual99','actual99'),('njit','njit')]}
        for reviewed_field, raw_field in fields:
            values = row[metric][reviewed_field]
            for backend, raw in raws.items():
                assert raw['measurement'][raw_field] == values[backend + '_bytes']
            assert values['actual99_minus_njit_bytes'] == values['actual99_bytes'] - values['njit_bytes']
    rows.append(row)
assert {(x['student'], x['case']) for x in rows} == {(s,c) for s in (False,True) for c in ('large_c1','large_c8','short_many')}
assert len(independent['anomalies']) == 2
assert [x['heap']['warm_peak_bytes']['actual99_minus_njit_bytes'] for x in rows if x['case']=='short_many'] == [4679434,7007433]
assert len(identity['source']) == 93
for rel, value in identity['source'].items():
    assert sha(R / rel) == value
for rel, value in identity['installed_binaries'].items():
    assert sha(Path(identity['installed']) / rel) == value
assert sha(identity['wheel']) == identity['wheel_sha256']
O.mkdir(exist_ok=False)
result = dict(status='root_reviewed_actual_v99_build_affected_full_owned42_with_open_performance_items',
    reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_adopted=True,
    build_id=identity['build_id'], identity_sha256=sha(D / 'actual-r2/package/identity.json'),
    affected_qualification_passed=True, affected_python_tests=1049,
    full_qualification_passed=True, full_python_tests=17179, native_tests=9,
    owned_full42_reviewed=True, full_owned_jobs=42, confirmed_blockers=[],
    actual_normal_not_sanitizer=True, actual_sanitizer_qualification_claimed=False,
    overall_performance_accepted=False, goal_complete=False, upstream_business_migration=False,
    source_identity=independent['source_identity'], rows=rows, anomalies=independent['anomalies'],
    prepared_cache_boundary=independent['prepared_cache_boundary'],
    numerical_proof_boundary=independent['numerical_proof_boundary'],
    timing_scope=independent['timing_scope'], memory_scope=independent['memory_scope'],
    limits=independent['limits'], all_root_result_and_ownership_assertions='Executed frozen drivers, independently audited; no numerical rerun by root metadata review.',
    original_exec_session=66475, original_exec_exit_code=0, original_terminal_evidence='Prior original tool completion; independently checked absent parent/42 child PIDs.',
    evidence_sha256={str(p): value for p,value in expected.items()})
(O / 'reviewed.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'root_review':str(O/'reviewed.json'),'sha256':sha(O/'reviewed.json'),'raw_direct_references':126,'rows':6,'overall_performance_accepted':False}))
