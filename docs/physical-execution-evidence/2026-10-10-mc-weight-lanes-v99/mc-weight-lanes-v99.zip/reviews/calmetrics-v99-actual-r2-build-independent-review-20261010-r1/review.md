# V99 actual-r2 独立构建身份审核

结论：未发现构建或安装身份 blocker。此结论仅覆盖新 actual-R AOT 包的构建、安装、来源、编译配置和一次运行身份 smoke；不等于 actual affected/full 数值资格、性能 replay、生产采用或目标完成。

审核只使用标准库解析、读取、hash 和只读 Git 命令。未 import 项目或计划代码，未启动 build/test/perf/SAN，也未修改 R/F/D99 或冻结计划。父任务确认 build session 78551 终态 exit 0；本审核独立读取了 pipeline 的完整终态。

核验结果：

- pipeline 为 `passed_actual_build_identity_only`，build/install/runtime-identity 三项 exit 0，日志 SHA 与记录一致，未残留 `current`。
- 当前 R 的全部 93 个生产构建输入与 r7 `native_after`、D99/source、实际 identity、qualified normal candidate 逐项相同。重算 build ID 为 `f789954a788004453f362c5aba57f9606c3a37d3148d63875c27ae8dae853434`。
- r7 code phase 的 204 项测试 inventory、Git HEAD/branch/index/dirty 状态成立。旧 A93/actual79 的 compact source guard 预期失效；合法采用仅 compact `4c85...`→`c711...` 与新增 49-case weight-lane 测试，未视为 V104 或候选篡改。
- 20 个计划 helper、441 个 frozen 文件、1759 个唯一 decision-r2 证据文件及 10 个 F 保护文件，均独立 hash 正确。实际 baseline 27333 项映射排除已有 compact 后核验 27332 个保护文件；新 test 原本不在该映射。计划 guard 显示 27331，是总数机械减去两条 adoption 路径的计数差异，不影响内容守卫。
- 全部 25 个 wheel package payload 与 install byte exact；全部 Python wrapper 与当前 R/src byte exact。wheel RECORD 的所有带 hash 成员长度及 SHA 正确。native extension build/wheel/install SHA 一致。
- 全部 55 个生产 TU 的 flags、defines、includes 与 qualified normal 实际 Ninja 和 r7 冻结 recipes 逐项相同，只归一化 source/build 路径。实际与 candidate 的 CMake compiler/configuration 相同；每个 TU 保留 `-fno-fast-math`、`-ffp-contract=off`，normal packet 配置成立。
- build/installed worker 的 arm64 CPU header、UUID `8cabb00fd5763cc5859e7628650f430e` 和全部 14 个 mapped sections 的地址、长度、类型及 payload SHA 相同。两文件 SHA 各自正确且不同；installed 符号数下降，CMake 安装脚本记录 `/usr/bin/strip -u -r`。未把 strip 后文件 hash 差异当作源码或执行内容差异，也未宣称 reviewer 运行了 worker。
- runtime log 指向 actual-r2 install，optimize=0，build ID 正确，报告 AOT/native graph backend、runtime_jit=0。冻结 runtime_probe 含 `python_fallback==0` 和 `request_time_compilation==0` 断言；非优化 probe exit 0 支持该次 `sum([1.])` 图调用的零 fallback/请求期编译，不外推到全部图、process worker 或数值性能。

审核结束时再次核验 terminal pipeline、identity 和 R93 未变。资格测试随后由 root 串行执行；本审核不会把其运行中日志当作终态。

关键 SHA：

- r7 manifest：`6513a4fd12b0f2c003466043bbf76c3e81b73a3ce82ff9e681a7d7f10f73a43f`
- sole decision-r2：`ee7a1aebdd949e7be8f57f5dee6cc53cea63fdad72272accf9e14d57113b1e9f`
- actual-r2 pipeline：`15c3fb343105c2d0f403f417896aa66fc69ad27b676d54950930af3f555c22f8`
- actual-r2 identity：`c89bb454821ddc73784af69c30bbb0a33748eaccaa15a69787b5071111c0cf53`
- actual wheel：`a37fda1adbb27b32476b678d463aaeba6dfc78f024fca1e7da10d91776b56daa`
- worker build：`7451f9d02e120f30449973ddc1245032516aa95737082db8b8e9585269e0c058`
- worker installed：`62806fbed9f1f760c7b03a0e1bc36ae8521c796eb63c283cb977f9e3ab36cdc4`

独立明细保存在 `receipt.json`、`production-inputs.json`、`normalized-tu-recipes.json`。`audit.py` 为本审核自写的 stdlib 解析器，未执行被审核 guard 或 Mach-O checker。
