"""Seal fresh actual full read-only qualification review; stdlib only."""
from pathlib import Path
import datetime,hashlib,json
O=Path(__file__).resolve().parent
P=Path('/private/tmp/calmetrics-v99-adoption-plan-20261010/r7')
A=P/'actual-r2'
Q=P/'actual-qualification-full-r1'
D=Path('/private/tmp/calmetrics-v99-root-adoption-admission-20261010-r1/adoption-decision-r2.json')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(131072),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(Path(p).read_text())
def save(name,data):
 p=O/name
 assert not p.exists(), 'fresh output required: '+str(p)
 p.write_text(json.dumps(data,indent=2)+'\n')
 return sha(p)
m=load(P/'manifest.json');d=load(D);r=load(O/'receipt.json');q=load(Q/'pipeline.json');i=load(A/'package/identity.json')
assert r['status']=='passed_independent_actual_full_qualification_review' and not r['confirmed_blockers']
assert all(c['passed'] for c in r['checks'])
assert sha(Q/'pipeline.json')==r['full_pipeline_sha256']=='ca45a9b2d3ea0c40460cdff3aedbed48efc5a5981fa7e0ed133a7df3de0822d9'
assert sha(A/'package/identity.json')==r['identity_sha256']=='c89bb454821ddc73784af69c30bbb0a33748eaccaa15a69787b5071111c0cf53'
assert sha(P/'manifest.json')==r['plan_manifest_sha256']=='6513a4fd12b0f2c003466043bbf76c3e81b73a3ce82ff9e681a7d7f10f73a43f'
assert sha(D)==r['decision_sha256']=='ee7a1aebdd949e7be8f57f5dee6cc53cea63fdad72272accf9e14d57113b1e9f'
R=Path(m['project']);F=Path(m['platform']);C=Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010/source')
evidence={};groups={}
def add_group(label,mapping,root=None):
 records={str(Path(n) if root is None else root/n):h for n,h in mapping.items()}
 for n,h in records.items():
  if n in evidence:assert evidence[n]==h, 'conflicting evidence SHA: '+n
  assert sha(n)==h, 'evidence changed: '+n
  evidence[n]=h
 groups[label]={'count':len(records),'paths':list(records)}
add_group('r7_helpers',m['helper_sha256'],P)
add_group('r7_frozen',m['frozen_sha256'])
add_group('phase_adapted_decision',d['evidence_sha256'])
adopted={x['path'] for x in m['adoption_changes']}
add_group('actual_protected_code_phase',{n:h for n,h in m['project_sha256'].items() if n not in adopted},R)
add_group('actual_production_sources',m['native_after'],R)
add_group('qualified_candidate_sources',m['native_after'],C)
add_group('actual_tests',m['tests_after'],R)
add_group('platform_protected',m['platform_sha256'],F)
assert groups['actual_protected_code_phase']['count']==27332
prior=Path('/private/tmp/calmetrics-v99-actual-affected-root-review-20261010-r1/reviewed.json')
add_group('prior_affected_root_bound_evidence',load(prior)['required_evidence_sha256'])
build=Path(i['build']);install=Path(i['installed'])
configs=[build/n for n in ['build.ninja','CMakeCache.txt','cmake_install.cmake','CTestTestfile.cmake']]
configs+=list((build/'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'))
assert len(configs)==5
other=[P/'manifest.json',P/'manifest.sha256',D,prior,A/'pipeline.json',A/'package/identity.json',Path(i['wheel'])]
other+=list(Q.iterdir())+configs
other+=[Path(j['log']) for j in load(A/'pipeline.json')['jobs']]
other+=[Path(v['path']) for v in r['actual_native_binaries'].values()]
other+=[install/n for n in r['payloads']]
other+=[build/'calmetrics_worker',build/Path(next(n for n in r['payloads'] if n.startswith('calmetrics_engine/_native.'))).name]
add_group('actual_raw_package_build_metadata',{str(p):sha(p) for p in other})
# Optional subordinate review is itself stdlib-only and reports static binding limits.
package_files=[p for p in (O/'package-build').rglob('*') if p.is_file()]
add_group('subordinate_static_build_package_review',{str(p):sha(p) for p in package_files})
subordinate_path=O/'package-build/review-r2/receipt.json'
subordinate=load(subordinate_path)
assert subordinate['status']=='passed_static_actual_r2_package_build_review'
assert len(subordinate['checks'])==117 and all(c['passed'] for c in subordinate['checks'])
assert sha(subordinate_path)=='7aa1bdde635f391ab75530d3f39604a39e4863df81bf8cb356dee628fe043595'
add_group('subordinate_bound_static_evidence',subordinate['evidence_sha256'])
intermediate_refs=[n for n in evidence if Path(n).suffix in ('.o','.obj') or 'CompilerId' in n or 'TryCompile' in n or 'CMakeScratch' in n or 'cmTC_' in n]
assert not intermediate_refs
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest={'schema':'actual-v99-full-independent-review-1','status':'sealed_actual_normal_full_qualification_review',
 'created_utc':now,'project':str(R),'platform':str(F),'readonly_project_review':True,
 'source_identity':{'build_id':r['source_build_id'],'production_files':93,'test_files':204,'exact_protected_files':27332},
 'inputs':{'r7_manifest':str(P/'manifest.json'),'r7_manifest_sha256':r['plan_manifest_sha256'],
           'decision':str(D),'decision_sha256':r['decision_sha256'],'actual_identity':str(A/'package/identity.json'),
           'actual_identity_sha256':r['identity_sha256'],'actual_full_pipeline':str(Q/'pipeline.json'),
           'actual_full_pipeline_sha256':r['full_pipeline_sha256']},
 'review_result':str(O/'reviewed.json'),'complete_sha256_receipt':str(O/'sha256-receipt.json'),
 'direct_review_artifacts_sha256':{str(p):sha(p) for p in O.iterdir() if p.is_file()},
 'evidence_group_counts':{k:v['count'] for k,v in groups.items()},
 'intermediate_build_artifact_dependencies':{'object_files':[],'CompilerId_files':[],'try_compile_files':[],
  'CMakeCXXCompiler_cmake_configuration_record':[str(p) for p in configs if p.name=='CMakeCXXCompiler.cmake'],
  'ninja_object_path_text_is_not_object_file_hash_dependency':True},
 'limits':r['limitations'],'next_phase_executed_by_reviewer':False,'source_adopted':True,'goal_complete':False}
manifest_sha=save('manifest.json',manifest)
(O/'manifest.sha256').write_text(manifest_sha+'\n')
reviewed={'status':'passed_independent_actual_full_qualification_review','reviewed_utc':now,'confirmed_blockers':[],
 'manifest':str(O/'manifest.json'),'manifest_sha256':manifest_sha,'detail_receipt':str(O/'receipt.json'),
 'detail_receipt_sha256':sha(O/'receipt.json'),'checks_passed':len(r['checks']),
 'additional_package_build_checks_passed':117,'additional_package_build_review':str(subordinate_path),
 'additional_package_build_review_sha256':sha(subordinate_path),
 'full_qualification_passed':True,'actual_full_numeric_qualification_proved':True,'normal_non_sanitizer':True,
 'exact_ids_independently_verified':True,'python_tests':17179,'native_tests':9,
 'python_raw_summary':'17179 passed in 1506.85s (0:25:06)',
 'python_ids_sha256':r['actual_python_xml']['ids_sha256'],'native_ids_sha256':r['actual_native_xml']['ids_sha256'],
 'failures':0,'errors':0,'skips':0,'duplicate_ids':0,
 'original_frozen_full_expected_ids_matched':True,'full_pipeline_sha256':r['full_pipeline_sha256'],
 'identity_sha256':r['identity_sha256'],'build_id':r['source_build_id'],'source_count':93,'test_inventory_count':204,
 'installed_wheel_payloads':25,'native_translation_units':55,'worker_mapped_sections':14,
 'exact_protected_code_phase_count':27332,'frozen_helper_mechanical_protected_count':27331,
 'r7_code_guard':str(O/'code-guard.json'),'r7_code_guard_exit_code':0,'source_adopted':True,
 'raw_sha256':{str(p):sha(p) for p in Q.iterdir()},
 'process_terminal':str(O/'process-terminal.json'),'original_full_parent_pid':31874,'original_full_pytest_pid':33311,
 'original_pids_absent':True,'original_exec_exit_code_root_attested':0,
 'python_runtime_package_boundary':'Frozen runner PYTHONPATH actual-r2 install, cwd actual R, src layout/importlib, no conftest override; build-time identity probe reports actual install. Full log does not provide every test __file__ trace.',
 'build_runtime_zero_fallback_smoke_scope':'One sum graph only; no global zero-fallback claim for every graph/test.',
 'sanitizer_qualification_claimed':False,'owned_full42_reviewed':False,'actual_owned_full42_replay_passed':False,
 'performance_proved_by_this_review':False,'production_adopted':False,'goal_complete':False,
 'no_object_compilerid_try_compile_hash_dependency':True,'intermediate_build_artifact_dependencies':manifest['intermediate_build_artifact_dependencies'],
 'project_files_modified_by_reviewer':False,'heavy_execution_started_by_reviewer':False,'limits':r['limitations']}
reviewed_sha=save('reviewed.json',reviewed)
newfiles=[p for p in O.rglob('*') if p.is_file()]
add_group('fresh_independent_review_artifacts',{str(p):sha(p) for p in newfiles})
receipt={'schema':'actual-v99-full-complete-sha256-receipt-1','status':'all_bound_files_sha256_verified',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unique_files':len(evidence),
 'groups':groups,'evidence_sha256':dict(sorted(evidence.items())),
 'excluded_self_sha256_file':str(O/'sha256-receipt.json'),'intermediate_build_artifact_references':intermediate_refs,
 'no_project_writes':True,'no_build_pytest_numerical_import_jit_performance_execution':True}
sha_receipt=save('sha256-receipt.json',receipt)
(O/'sha256-receipt.sha256').write_text(sha_receipt+'\n')
print(json.dumps({'status':reviewed['status'],'reviewed':str(O/'reviewed.json'),'reviewed_sha256':reviewed_sha,
 'manifest_sha256':manifest_sha,'sha256_receipt_sha256':sha_receipt,'unique_evidence_files':len(evidence),
 'intermediate_object_compilerid_try_compile_file_references':len(intermediate_refs)}))
