"""Independent static package/build audit. Stdlib only; never execute frozen code."""
from pathlib import Path
import ast
import base64
import csv
import datetime
import hashlib
import io
import json
import re
import struct
import zipfile
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
R = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
PLAN = Path('/private/tmp/calmetrics-v99-adoption-plan-20261010/r7')
ACT = PLAN / 'actual-r2'
FULL = PLAN / 'actual-qualification-full-r1'
PRIOR = Path('/private/tmp/calmetrics-v99-actual-r2-build-independent-review-20261010-r1')
IDENTITY_SHA = 'c89bb454821ddc73784af69c30bbb0a33748eaccaa15a69787b5071111c0cf53'
BUILD_ID = 'f789954a788004453f362c5aba57f9606c3a37d3148d63875c27ae8dae853434'
checks = []
observed = {}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def sha(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as f:
        for raw in iter(lambda: f.read(1024 * 1024), b''):
            h.update(raw)
    value = h.hexdigest()
    observed[str(path)] = value
    return value

def load(path):
    sha(path)
    return json.loads(Path(path).read_text())

def check(name, passed, detail=None):
    checks.append(dict(name=name, passed=bool(passed), detail=detail))

def recipes(build, source):
    content = (build / 'build.ninja').read_text()
    result, repeated = {}, []
    for m in re.finditer(r'^build ([^\n]+): CXX_COMPILER_[^\n]+\n((?:  [^\n]*\n)*)', content, re.M):
        header, block = m.group(0).split('\n', 1)
        hit = re.search(re.escape(str(source) + '/') + r'(cpp/[^ ]+)(?: |$)', header)
        if not hit:
            continue
        fields = {}
        for key in ('DEFINES', 'FLAGS', 'INCLUDES'):
            field = re.search(r'^  ' + key + r' = (.*)$', block, re.M)
            fields[key] = (field.group(1) if field else '').replace(str(build), '<BUILD>').replace(str(source), '<SOURCE>')
        if hit[1] in result:
            repeated.append(hit[1])
            check('repeated recipe consistent ' + hit[1], result[hit[1]] == fields)
        result[hit[1]] = fields
    return result, repeated

def macho(path):
    raw = path.read_bytes()
    hdr = struct.unpack_from('<IiiIIIII', raw)
    assert hdr[0] == 0xfeedfacf
    cursor, sections, uuid, symtab, libraries = 32, {}, [], None, []
    for _ in range(hdr[4]):
        cmd, size = struct.unpack_from('<II', raw, cursor)
        assert size >= 8 and cursor + size <= 32 + hdr[5]
        if cmd == 0x1b:
            uuid.append(raw[cursor + 8:cursor + 24].hex())
        elif cmd == 2:
            values = struct.unpack_from('<IIIIII', raw, cursor)
            symtab = dict(nsyms=values[3], strsize=values[5])
        elif cmd in (0xc, 0x80000018, 0x8000001f, 0x80000023):
            offset = struct.unpack_from('<I', raw, cursor + 8)[0]
            libraries.append(raw[cursor + offset:cursor + size].split(b'\0')[0].decode())
        elif cmd == 0x19:
            segment = struct.unpack_from('<II16sQQQQiiII', raw, cursor)
            assert 72 + 80 * segment[9] <= size
            for idx in range(segment[9]):
                item = struct.unpack_from('<16s16sQQIIIIIIII', raw, cursor + 72 + 80 * idx)
                key = ':'.join(x.split(b'\0')[0].decode() for x in item[:2])
                assert key not in sections
                typ = item[8] & 255
                if typ in (1, 12, 18):
                    value = None
                else:
                    assert item[4] + item[3] <= len(raw)
                    value = digest(raw[item[4]:item[4] + item[3]])
                sections[key] = dict(address=item[2], size=item[3], type=typ, sha256=value)
        cursor += size
    assert len(uuid) == 1 and cursor == 32 + hdr[5]
    return dict(header_cpu=list(hdr[1:4]), uuid=uuid[0], sections=sections,
                symbol_table=symtab, linked_libraries=libraries, bytes=len(raw), sha256=sha(path))

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
i = load(ACT / 'package/identity.json')
m = load(PLAN / 'manifest.json')
full = load(FULL / 'pipeline.json')
buildpipe = load(ACT / 'pipeline.json')
prior_manifest = load(PRIOR / 'manifest.json')
check('specified identity SHA', sha(ACT / 'package/identity.json') == IDENTITY_SHA)
check('prior independent review preserved', all(sha(PRIOR / n) == h for n, h in prior_manifest['files'].items()))
check('prior manifest sidecar', sha(PRIOR / 'manifest.json') == (PRIOR / 'manifest.sha256').read_text().strip())
source = {str(p.relative_to(R)): sha(p) for p in sorted((R / 'cpp').rglob('*')) if p.is_file()}
source.update({n: sha(R / n) for n in ('CMakeLists.txt', 'pyproject.toml')})
source = dict(sorted(source.items()))
computed_id = digest((';'.join(i['compiler']) + ''.join(';' + n + ':' + h for n, h in source.items())).encode())
check('93 current source/identity/r7 mappings and BuildID', len(source) == 93 and source == i['source'] == m['native_after'] and computed_id == BUILD_ID == i['build_id'])
build, install, wheel = (Path(i[k]) for k in ('build', 'installed', 'wheel'))
check('actual paths', build == ACT / 'build' and install == ACT / 'package/install' and i['actual_source_root'] == str(R))
check('wheel SHA', sha(wheel) == i['wheel_sha256'] == 'a37fda1adbb27b32476b678d463aaeba6dfc78f024fca1e7da10d91776b56daa')
payload = {}
with zipfile.ZipFile(wheel) as z:
    names = [n for n in z.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
    check('25 package payloads unique', len(names) == len(set(names)) == 25)
    disk_names = {str(p.relative_to(install)) for p in (install / 'calmetrics_engine').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    check('no additional non-cache installed package payloads', disk_names == set(names))
    for name in names:
        data = z.read(name)
        value = digest(data)
        check('wheel/install payload ' + name, sha(install / name) == value)
        if name.endswith('.py'):
            check('wrapper/source bytes ' + name, sha(R / 'src' / name) == value)
        payload[name] = dict(bytes=len(data), sha256=value)
    record = [n for n in z.namelist() if n.endswith('.dist-info/RECORD')]
    assert len(record) == 1
    record_entries = list(csv.reader(io.StringIO(z.read(record[0]).decode())))
    check('RECORD covers every wheel member once', len(record_entries) == len(z.namelist()) == 28 and len({r[0] for r in record_entries}) == 28)
    for name, hashed, length in record_entries:
        if not hashed:
            check('only RECORD omits own hash', name == record[0] and length == '')
        else:
            data = z.read(name)
            encoded = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode()
            check('RECORD hash/length ' + name, hashed == 'sha256=' + encoded and int(length) == len(data))
    wheel_metadata = {n: z.read(n).decode() for n in z.namelist() if n.endswith(('.dist-info/WHEEL', '.dist-info/METADATA'))}
extension = [n for n in names if n.startswith('calmetrics_engine/_native.') and n.endswith('.so')]
check('single native extension', len(extension) == 1)
check('native built/wheel/install exact', sha(build / Path(extension[0]).name) == payload[extension[0]]['sha256'] == i['installed_binaries'][extension[0]])
tu, repeated = recipes(build, R)
candidate_i = load(Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010/package-candidate-r3/identity.json'))
candidate_tu, candidate_repeated = recipes(Path(candidate_i['build']), Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010/source'))
check('55 normalized TU equal qualified normal candidate', len(tu) == 55 and tu == candidate_tu == m['candidate_cpp_recipes'])
check('no repeated TU blocks', not repeated and not candidate_repeated)
recipe_hash = digest(json.dumps(sorted(tu.items()), separators=(',', ':')).encode())
check('TU digest and Ninja hash', recipe_hash == i['normalized_cpp_recipes_sha256'] == 'cb772c770545394caf6e8844f5b65056cd11701b9ba0df656416b110616c258a' and sha(build / 'build.ninja') == i['ninja_sha256'])
check('precise FP on every TU', all('-fno-fast-math' in x['FLAGS'] and '-ffp-contract=off' in x['FLAGS'] and '-ffast-math' not in x['FLAGS'] for x in tu.values()))
cache = dict(re.findall(r'^([^#/:][^:]*):[^=]+=(.*)$', (build / 'CMakeCache.txt').read_text(), re.M))
sha(build / 'CMakeCache.txt')
normal_config = {n: cache.get(n) for n in ('CMAKE_BUILD_TYPE', 'CALMETRICS_ENGINE_SANITIZE', 'CALMETRICS_ENGINE_USE_EIGEN', 'CALMETRICS_ENGINE_USE_ACCELERATE', 'CALMETRICS_ENGINE_USE_HIGHWAY')}
check('actual normal non-SAN with all optional libraries enabled', normal_config == dict(CMAKE_BUILD_TYPE='Release', CALMETRICS_ENGINE_SANITIZE='OFF', CALMETRICS_ENGINE_USE_EIGEN='ON', CALMETRICS_ENGINE_USE_ACCELERATE='ON', CALMETRICS_ENGINE_USE_HIGHWAY='ON') and all('-fsanitize' not in x['FLAGS'] for x in tu.values()))
worker_built = macho(build / 'calmetrics_worker')
worker_installed = macho(install / 'calmetrics_engine/calmetrics_worker')
check('worker arm64 UUID/14 mapped sections match', worker_built['header_cpu'] == worker_installed['header_cpu'] == [16777228, 0, 2] and worker_built['uuid'] == worker_installed['uuid'] == i['worker_uuid'] and worker_built['sections'] == worker_installed['sections'] and len(worker_built['sections']) == 14)
check('worker hashes and reduced symbols', worker_built['sha256'] == i['worker_build_sha256'] and worker_installed['sha256'] == i['installed_binaries']['calmetrics_engine/calmetrics_worker'] and worker_installed['symbol_table']['nsyms'] < worker_built['symbol_table']['nsyms'])
check('worker has no linked Python library', all('python' not in n.lower() for n in worker_built['linked_libraries']))
install_source = (build / 'cmake_install.cmake').read_text()
check('generated installed worker strip command', i['worker_strip_transform'] == 'strip -u -r' and 'execute_process(COMMAND "/usr/bin/strip" -u -r ' in install_source)
sha(build / 'cmake_install.cmake')
ctest_path = build / 'CTestTestfile.cmake'
ctest_text = ctest_path.read_text()
sha(ctest_path)
ctest_commands = {}
for line in ctest_text.splitlines():
    match = re.match(r'add_test\(\[=\[(.+?)\]=\] (.+)\)$', line)
    if match:
        ctest_commands[match[1]] = re.findall(r'"([^"]*)"', match[2])
check('generated CTest exactly frozen native IDs', len(ctest_commands) == 9 and set(ctest_commands) == {x[1] for x in m['native_ids']})
native_targets = {}
for name, command in ctest_commands.items():
    check('generated CTest actual executable ' + name, command[0] == str(build / name))
    if name in ('calmetrics_engine_runtime_tests', 'calmetrics_engine_result_tests'):
        check('generated CTest actual worker ' + name, command[1:] == [str(build / 'calmetrics_worker')])
    native_targets[name] = {n: sha(n) for n in command}
check('generated CTest actual source directory', '# Source directory: ' + str(R) in ctest_text)
for state, stage in ((buildpipe, ACT), (full, FULL)):
    check('pipeline identity binding ' + stage.name, state['identity'] == str(ACT / 'package/identity.json') and state['identity_sha256'] == IDENTITY_SHA and state['package_audit']['build_id'] == BUILD_ID)
    check('pipeline logs pinned ' + stage.name, all(j['returncode'] == 0 and sha(j['log']) == j['log_sha256'] for j in state['jobs']))
    for job in state['jobs']:
        if job.get('xml'):
            check('job XML pinned ' + job['label'], sha(job['xml']) == job['xml_sha256'])
native_job = next(j for j in full['jobs'] if j['label'] == 'native')
check('full native invokes actual build', native_job['command'][native_job['command'].index('--test-dir') + 1] == str(build))
runner = PLAN / 'qualify_actual.py'
runner_source = runner.read_text()
check('frozen runner SHA', sha(runner) == m['helper_sha256']['qualify_actual.py'] == '1c89280685a38d2bfa108d3dd9e5851f79baa6102b3f532c3a74ea5819bb01cc')
tree = ast.parse(runner_source)
popen = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and ast.unparse(n.func) == 'subprocess.Popen']
check('runner Popen cwd R/env exact', len(popen) == 1 and {x.arg: ast.unparse(x.value) for x in popen[0].keywords}.get('cwd') == 'guard.R' and {x.arg: ast.unparse(x.value) for x in popen[0].keywords}.get('env') == 'env')
check('runner PYTHONPATH actual installed and no optimization', "PYTHONPATH=identity['installed']" in runner_source and "('PYTHONOPTIMIZE', 'DYLD_INSERT_LIBRARIES', 'PYTEST_ADDOPTS')" in runner_source)
check('full Python venv command boundary', all(j['command'][:4] == ['/Users/chenjunming/Desktop/myenv_312/bin/python3.12', '-B', '-m', 'pytest'] and j['command'][4] == 'tests' for j in full['jobs'] if j['label'] in ('collection', 'python')))
check('src layout no cwd package or conftest redirection', not (R / 'calmetrics_engine').exists() and not (R / 'conftest.py').exists() and not list((R / 'tests').rglob('conftest.py')))
check('pytest configured importlib mode', 'addopts = "-ra --import-mode=importlib"' in (R / 'pyproject.toml').read_text())
probe = json.loads((ACT / 'runtime-identity.log').read_text().splitlines()[-1])
check('prior successful runtime probe actual package path', probe == i['build_info'] and probe['package_path'] == str(install / 'calmetrics_engine/__init__.py') and probe['engine_build_id'] == BUILD_ID and probe['optimize'] == 0)
python_cases = ET.parse(FULL / 'python.xml').findall('.//testcase')
metadata_cases = [x for x in python_cases if x.get('classname') == 'tests.test_api' and x.get('name') == 'test_installed_metadata_and_one_native_extension']
check('full package metadata assertion executed/passed', len(metadata_cases) == 1 and not any(metadata_cases[0].find(n) is not None for n in ('failure', 'error', 'skipped')))
sha(R / 'tests/test_api.py')
check('input hashes unchanged across audit', all(sha(Path(n)) == h for n, h in list(observed.items())))
result = dict(status='passed_static_actual_r2_package_build_review' if all(x['passed'] for x in checks) else 'blocked_static_actual_r2_package_build_review', started_utc=started, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), checks=checks, identity_sha256=IDENTITY_SHA, recomputed_build_id=computed_id, source_count=len(source), payload_count=len(payload), wheel_record_hashed_members=27, payloads=payload, wheel_metadata=wheel_metadata, normalized_tu_count=len(tu), normalized_tu_sha256=recipe_hash, normal_configuration=normal_config, worker_built=worker_built, worker_installed=worker_installed, ctest_commands=ctest_commands, native_targets=native_targets, full_pipeline_sha256=sha(FULL / 'pipeline.json'), python_package_boundary=dict(installed=str(install), cwd=str(R), pytest_import_mode='importlib', prior_runtime_probe_actual_path=True, full_metadata_test_passed=True, per_test_import_path_recorded=False, limitation='Frozen launcher plus PYTHONPATH/src-layout/static import policy and metadata test support actual installed package execution. The full log does not record a module __file__ for every individual test.'), evidence_sha256=observed, source_modified=False, heavy_work_started=False, numeric_imports=False, current_performance_process_checked=False, performance_proved=False, production_adopted=False, goal_complete=False)
for name, obj in [('receipt.json', result), ('production-inputs.json', source), ('normalized-tu-recipes.json', tu)]:
    with (OUT / name).open('x') as f:
        f.write(json.dumps(obj, indent=2) + '\n')
manifest = dict(status=result['status'], files={p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file()})
with (OUT / 'manifest.json').open('x') as f:
    f.write(json.dumps(manifest, indent=2) + '\n')
with (OUT / 'manifest.sha256').open('x') as f:
    f.write(sha(OUT / 'manifest.json') + '\n')
print(json.dumps(dict(status=result['status'], checks=len(checks), failed=[x for x in checks if not x['passed']], receipt_sha256=sha(OUT / 'receipt.json'), manifest_sha256=sha(OUT / 'manifest.json')), indent=2))
