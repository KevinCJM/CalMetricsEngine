# Actual V99 affected 独立资格审核

结论：本次新 actual-R affected 资格通过，无 blocker。1049 个 Python 与 9 个 native 原始执行 IDs 完整匹配 r7 冻结预期，collection 同样完整匹配 1049，均无 failure/error/skip。此结论覆盖本次 affected 集合；full、性能 replay、生产采用和目标完成仍待各自证据。

原始终态 pipeline：`/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-qualification-affected-r1/pipeline.json`，SHA `58a1c99dcc479abb2a8708afe141c5ff230fff912f78d7df3d8efcb721bf0bdc`。父任务确认原句柄 57918 terminal exit 0；本审核独立读取终态与三个 exit 0 子项，未执行 guard 或项目代码。

原始证明：

- collection.log：1049 个唯一 node IDs，逐项等于 manifest `expected_ids.affected`，没有缺项、额外项或重复。该集合恰好是 49 focused 与 1000 related 的并集。
- python.xml：1049 个唯一完整 `(classname,name)` IDs，逐项等于冻结预期；digest `904ed688c0b8cb6e09dba28dc8a36e8f927ef1bdcbd9ca77f1fdcb626eaadb38`。XML SHA `80b04ab4f018cb132ed1588441c0a4fce72821318ca2bac8a7a5e5aec7ed7cd6`。原始日志结尾 `1049 passed in 712.87s`。
- native.xml：9 个唯一完整 IDs，逐项等于 manifest native IDs；digest `da8f2d93c48cebbd16b1e3dc7fb036f57a485c12dadd52b25109933c5770cd94`。XML SHA `b91aee21671f96f3d35281766de4347247634b16e398920db5f0cfc288db16bf`。原始日志指向 actual-r2 build，9/9 passed。
- 各 log/XML SHA 与 pipeline 原记录一致，XML testcase 与 suite 聚合均无失败、错误、跳过或 disabled。

此次执行绑定新 actual 包：

- frozen qualifier runner 的 SHA 为 r7 helper 记录值；其 cwd 为当前 R，PYTHONPATH 指向传入 identity 的 actual-r2 install，移除 PYTHONOPTIMIZE/PYTEST_ADDOPTS，启用 normal packet 模式。真实 R 采用 src layout、pytest importlib，根目录没有遮蔽包，tests 下没有 conftest 路径覆盖。
- 本次身份为 actual-r2 的 identity SHA `c89bb454821ddc73784af69c30bbb0a33748eaccaa15a69787b5071111c0cf53`，build ID `f789954a788004453f362c5aba57f9606c3a37d3148d63875c27ae8dae853434`；唯一 admission 为 decision-r2 SHA `ee7a1aebdd949e7be8f57f5dee6cc53cea63fdad72272accf9e14d57113b1e9f`，plan SHA `6513a4fd12b0f2c003466043bbf76c3e81b73a3ce82ff9e681a7d7f10f73a43f`。
- 独立重新核验 R93/D99/source93/actual identity 构建输入一致，当前 204 项测试 inventory 与 r7 code phase 完整一致。27332 个实际存量保护文件、20 helpers、441 frozen 文件、1759 decision evidence、10 F 文件均 hash 正确，Git phase-code 状态成立。
- 独立重新核验 25 个 wheel/install payload byte exact、全部 Python wrapper 与 R/src byte exact、wheel RECORD、native build/install、55 TU flags/defines/includes 与 qualified normal 一致。
- worker 的 built/installed SHA 各自正确，UUID 和全部 14 个 mapped sections 相同，strip 记录与符号数下降成立。9 条生成的 CTest 命令全部绑定 actual-r2 build 的 native 测试可执行文件，runtime/result 两条额外 worker argv 也绑定 actual-r2 built worker。其可执行文件当前 SHA 已单独记录。
- 未使用 candidate 历史 XML 来证明此次实际资格。CodeGraph 先查 import/测试定位未直接定位此次调用，随后核验真实 runner、pyproject、tests、CTest 源文件。

Python 实际覆盖：

| module | executed IDs |
|---|---:|
| test_compact_weight_lanes | 49 |
| test_mc_compact_graph | 53 |
| test_compact_path_execution | 130 |
| test_raw_state_batching | 15 |
| test_raw_factor_prefix | 65 |
| test_compact_parent_storage | 49 |
| test_axis_path_primitives | 220 |
| test_mc_projection_primitives | 193 |
| test_affine_projection_library | 43 |
| test_typed_results | 86 |
| test_dense_layout_transport | 130 |
| test_affine_projection_transport | 16 |

49 个新 weight-lane 案例的真实测试源码核验包含：C/F 输入与输出布局；ordinary/prepared；组合数 1/4/5/6/8/9 的 lane/tail/batch 全根比较；strided/negative weight view；公共根重排拒绝 compact admission；duplicate 根独立存储；+0/-0/subnormal 与 packet guard；NaN/Inf/非有限 producer、形状错误及原始错误顺序，失败后恢复；up/down/zero 舍入保持 scalar fold；同地址权重重打包与两代 owner；精确 memory budget 边界和 worker scratch capacity。参考仍为公开中间根的规范 DAG，另有 sparse-fence scalar compact 路径，未改 tolerance/reference math。两个同时出错的形状用例只证明 input-binding 优先顺序，不能外推为所有 downstream multi-hop 错误覆盖。

真实 private helper 在执行路径上断言 python_fallback/request_time_compilation 均为 0；该证据适用于这些已执行 helper 路径，未外推为全部 1049 用例或所有图都采集了这两项 audit。先前 runtime smoke 仍只是一张 `sum([1.])` 图，本报告的 1049/9 资格是独立的实际执行证据。

本轮另有明确授权的 Node/旧 compiler-id/V85 对象缓存清理，final-result SHA `a84354cd4c9fb321f7209ae6349bb0bed0a65e5cdb806ed12212f7e9993bb54b`。清理收据为 completed，128 旧编译中间文件加 1254 Node cache；本次资格审核重核了当前包、代码、冻结证据完整性，未把已授权缓存删除当作代码或证据损坏。

审核只运行自写的 stdlib 解析/hash/只读 Git 检查；未 import 项目、未运行 guard/测试/数值/perf/SAN，未修改源码。full-r1 pipeline 未读取或假设终态。审毕再次核验 affected pipeline、actual-r2 identity 与 R93 未变。
