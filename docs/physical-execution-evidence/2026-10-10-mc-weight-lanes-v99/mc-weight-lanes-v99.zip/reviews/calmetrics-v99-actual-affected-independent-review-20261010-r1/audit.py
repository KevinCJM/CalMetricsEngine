"""Independent read-only artifact audit; stdlib only, never import project/plan code."""
from pathlib import Path
import base64
import csv
import datetime
import hashlib
import io
import json
import re
import struct
import subprocess
import zipfile
import collections
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
PLAN = Path('/private/tmp/calmetrics-v99-adoption-plan-20261010/r7')
ACT = PLAN / 'actual-r2'
DECISION = Path('/private/tmp/calmetrics-v99-root-adoption-admission-20261010-r1/adoption-decision-r2.json')
CAND = Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010')
EXPECTED_PLAN = '6513a4fd12b0f2c003466043bbf76c3e81b73a3ce82ff9e681a7d7f10f73a43f'
EXPECTED_DECISION = 'ee7a1aebdd949e7be8f57f5dee6cc53cea63fdad72272accf9e14d57113b1e9f'
EXPECTED_PIPELINE = '15c3fb343105c2d0f403f417896aa66fc69ad27b676d54950930af3f555c22f8'
EXPECTED_IDENTITY = 'c89bb454821ddc73784af69c30bbb0a33748eaccaa15a69787b5071111c0cf53'
checks = []
def check(value, name):
    checks.append({'check': name, 'passed': bool(value)})
    if not value:
        raise AssertionError(name)
def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(131072), b''):
            h.update(block)
    return h.hexdigest()
def load(path):
    return json.loads(Path(path).read_text())
def hash_map(records, root=None):
    errors = []
    for name, expected in records.items():
        p = Path(name) if root is None else root / name
        if not p.is_file() or sha(p) != expected:
            errors.append(name)
    return {'count': len(records), 'errors': errors}
def native(root):
    names = sorted([str(p.relative_to(root)) for p in (root / 'cpp').rglob('*') if p.is_file()] +
                   ['CMakeLists.txt', 'pyproject.toml'])
    return {name: sha(root / name) for name in names}
def tests(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted((root / 'tests').rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py', '.cpp', '.hpp', '.json')}
def git(root, *args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=root)
def records(raw):
    return set(x for x in raw.split(b'\0') if x)
def recipes(build, root):
    result, duplicates = {}, []
    for match in re.finditer(r'^build ([^\n]+): CXX_COMPILER_[^\n]+\n((?:  [^\n]*\n)*)',
                             (build / 'build.ninja').read_text(), re.M):
        header, block = match.group(0).split('\n', 1)
        source = re.search(re.escape(str(root) + '/') + r'(cpp/[^ ]+)(?: |$)', header)
        if source is None:
            continue
        name = source.group(1)
        fields = {}
        for key in ['DEFINES', 'FLAGS', 'INCLUDES']:
            field = re.search(r'^  ' + key + r' = (.*)$', block, re.M)
            value = field.group(1) if field else ''
            fields[key] = value.replace(str(build), '<BUILD>').replace(str(root), '<SOURCE>')
        if name in result:
            duplicates.append(name)
            check(result[name] == fields, 'duplicate TU recipe consistency: ' + name)
        result[name] = fields
    return result, duplicates
def macho(path):
    data = path.read_bytes()
    h = struct.unpack_from('<IiiIIIII', data)
    check(h[0] == 0xfeedfacf and h[1] == 0x0100000c, 'Mach-O arm64 header: ' + path.name)
    cursor, uuid, sections, symtab = 32, [], {}, None
    for _ in range(h[4]):
        cmd, size = struct.unpack_from('<II', data, cursor)
        check(size >= 8 and cursor + size <= 32 + h[5], 'Mach-O command bounds: ' + path.name)
        if cmd == 0x1b:
            uuid.append(data[cursor + 8:cursor + 24].hex())
        elif cmd == 0x2:
            values = struct.unpack_from('<IIIIII', data, cursor)
            symtab = {'nsyms': values[3], 'strsize': values[5]}
        elif cmd == 0x19:
            segment = struct.unpack_from('<II16sQQQQiiII', data, cursor)
            check(72 + 80 * segment[9] <= size, 'Mach-O section table bounds: ' + path.name)
            for n in range(segment[9]):
                s = struct.unpack_from('<16s16sQQIIIIIIII', data, cursor + 72 + 80 * n)
                key = ':'.join(x.split(b'\0', 1)[0].decode() for x in s[:2])
                check(key not in sections, 'Mach-O unique section: ' + key)
                typ = s[8] & 255
                if typ in (1, 12, 18):
                    digest = None
                else:
                    check(s[4] + s[3] <= len(data), 'Mach-O mapped payload bounds: ' + key)
                    digest = sha_bytes(data[s[4]:s[4] + s[3]])
                sections[key] = {'address': s[2], 'size': s[3], 'type': typ, 'sha256': digest}
        cursor += size
    check(len(uuid) == 1 and cursor == 32 + h[5], 'Mach-O UUID and command traversal: ' + path.name)
    return {'header_cpu': list(h[1:4]), 'uuid': uuid[0], 'sections': sections, 'symbol_table': symtab,
            'file_bytes': len(data), 'sha256': sha_bytes(data)}

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
m, p, i, d = load(PLAN / 'manifest.json'), load(ACT / 'pipeline.json'), load(ACT / 'package/identity.json'), load(DECISION)
R, F = Path(m['project']), Path(m['platform'])
check(sha(PLAN / 'manifest.json') == EXPECTED_PLAN == (PLAN / 'manifest.sha256').read_text().strip(), 'r7 manifest SHA')
check(sha(DECISION) == EXPECTED_DECISION, 'sole adoption decision r2 SHA')
check(sha(ACT / 'pipeline.json') == EXPECTED_PIPELINE, 'actual-r2 terminal pipeline SHA')
check(sha(ACT / 'package/identity.json') == EXPECTED_IDENTITY == p['identity_sha256'], 'actual-r2 identity SHA')
check(p['status'] == 'passed_actual_build_identity_only' and 'current' not in p and p.get('finished_epoch'), 'build pipeline terminal success')
check([j['label'] for j in p['jobs']] == ['build', 'install', 'runtime-identity'] and
      all(j['returncode'] == 0 and sha(j['log']) == j['log_sha256'] for j in p['jobs']), 'all three terminal jobs and logs')
check(p['admission']['decision'] == str(DECISION) and p['admission']['decision_sha256'] == EXPECTED_DECISION,
      'build admission points to sole r2 decision')
check(d['plan_manifest_sha256'] == EXPECTED_PLAN and i['actual_plan_manifest_sha256'] == EXPECTED_PLAN,
      'decision/identity bound to r7 plan')
check(d['source_adopted_at_decision_time'] and d['adopt_source'] and not d['production_adopted'] and not d['goal_complete'],
      'decision phase and qualification boundary')
check(p['source_adopted'] and not p['production_adopted'] and not p['goal_complete'], 'pipeline phase boundary')
guards = {}
for label, mapping, root in [('helpers', m['helper_sha256'], PLAN), ('frozen', m['frozen_sha256'], None),
                             ('decision_evidence', d['evidence_sha256'], None)]:
    guards[label] = hash_map(mapping, root)
    check(not guards[label]['errors'], label + ' file SHAs')
check(p['admission']['evidence_files'] == len(d['evidence_sha256']), 'admission evidence count')
actual_source, candidate_source = native(R), native(CAND / 'source')
check(len(actual_source) == 93 and actual_source == candidate_source == m['native_after'] == i['source'], 'actual/candidate/r7/identity all 93 production inputs')
check(tests(R) == m['tests_after'] and len(m['tests_after']) == 204, 'actual phase code test inventory')
adopted = {x['path'] for x in m['adoption_changes']}
guards['actual_protected_code_phase'] = hash_map({n: h for n, h in m['project_sha256'].items() if n not in adopted}, R)
check(not guards['actual_protected_code_phase']['errors'], 'actual protected files in code phase')
guards['platform'] = hash_map(m['platform_sha256'], F)
check(not guards['platform']['errors'], 'platform protected files')
for all_files, key in [(False, 'repository_status_normal_hex'), (True, 'repository_status_all_hex')]:
    args = ['status', '--porcelain=v1', '-z'] + (['--untracked-files=all'] if all_files else [])
    expected = records(bytes.fromhex(m[key])) | {b'?? tests/test_compact_weight_lanes.py'}
    check(records(git(R, *args)) == expected, 'actual code-phase Git status all=' + str(all_files))
check(git(R, 'rev-parse', 'HEAD').decode().strip() == m['head'] and
      git(R, 'branch', '--show-current').decode().strip() == m['branch'], 'actual HEAD and branch')
check(sha_bytes(git(R, 'diff', '--cached', '--binary')) == m['index_diff_sha256'], 'actual preexisting index unchanged')
check(git(F, 'status', '--porcelain=v1', '-z').hex() == m['platform_status_hex'], 'platform status unchanged')
check({n for n in m['native_before'] if m['native_before'][n] != actual_source[n]} == {'cpp/compact_path.cpp'},
      'old actual93 intentionally differs only adopted compact')
for change in m['adoption_changes']:
    check(sha(R / change['path']) == change['new_sha256'], 'authorized source adoption: ' + change['path'])
ci = load(CAND / 'package-candidate-r3/identity.json')
check(ci['source'] == actual_source and ci['compiler'] == i['compiler'] == m['candidate_compiler'], 'qualified normal candidate source/compiler equality')
expected_id = sha_bytes((';'.join(i['compiler']) + ''.join(';' + n + ':' + h for n, h in actual_source.items())).encode())
check(expected_id == i['build_id'] == ci['build_id'] == m['candidate_build_id'] == d['candidate_build_id'], 'source and compiler recomputed build ID')
build, install, wheel = Path(i['build']), Path(i['installed']), Path(i['wheel'])
def cmake_config(directory):
    cache = {}
    for line in (directory / 'CMakeCache.txt').read_text().splitlines():
        match = re.match(r'^([^#/:][^:]*):[^=]+=(.*)$', line)
        if match:
            cache[match.group(1)] = match.group(2)
    wanted = ['CMAKE_CXX_COMPILER', 'CMAKE_BUILD_TYPE', 'CMAKE_CXX_FLAGS', 'CMAKE_CXX_FLAGS_RELEASE',
              'CMAKE_OSX_DEPLOYMENT_TARGET', 'CMAKE_OSX_ARCHITECTURES', 'CALMETRICS_ENGINE_USE_EIGEN',
              'CALMETRICS_ENGINE_USE_ACCELERATE', 'CALMETRICS_ENGINE_USE_HIGHWAY', 'CALMETRICS_ENGINE_SANITIZE']
    result = {k: cache.get(k) for k in wanted}
    compiler_files = list((directory / 'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'))
    check(len(compiler_files) == 1, 'one CMake compiler identity')
    for key in ['CMAKE_CXX_COMPILER_ID', 'CMAKE_CXX_COMPILER_VERSION']:
        match = re.search(r'set\(' + key + r' "([^"]*)"\)', compiler_files[0].read_text())
        check(match is not None, 'CMake compiler field: ' + key)
        result[key] = match.group(1)
    return result
actual_cmake, candidate_cmake = cmake_config(build), cmake_config(Path(ci['build']))
check(actual_cmake == candidate_cmake and actual_cmake['CMAKE_CXX_COMPILER_ID'] == i['compiler'][1] and
      actual_cmake['CMAKE_CXX_COMPILER_VERSION'] == i['compiler'][2] and
      actual_cmake['CMAKE_BUILD_TYPE'] == i['compiler'][4] and
      actual_cmake['CMAKE_CXX_FLAGS_RELEASE'] == i['compiler'][6], 'actual/qualified normal CMake compiler/configuration equality')
actual_recipes, duplicates = recipes(build, R)
candidate_recipes, candidate_duplicates = recipes(Path(ci['build']), CAND / 'source')
check(len(actual_recipes) == len(candidate_recipes) == 55 and actual_recipes == candidate_recipes == m['candidate_cpp_recipes'],
      '55 qualified normal per-TU defines/flags/includes equality')
check(all('-fno-fast-math' in x['FLAGS'] and '-ffp-contract=off' in x['FLAGS'] and
          '-ffast-math' not in x['FLAGS'] and 'EIGEN_DONT_VECTORIZE' not in x['DEFINES'] for x in actual_recipes.values()),
      'precise FP and normal packet configuration every TU')
check(sha(build / 'build.ninja') == i['ninja_sha256'], 'actual Ninja SHA')
recipe_digest = sha_bytes(json.dumps(sorted(actual_recipes.items()), separators=(',', ':')).encode())
check(recipe_digest == i['normalized_cpp_recipes_sha256'], 'normalized TU recipes digest')
check(sha(wheel) == i['wheel_sha256'] == p['package_audit']['wheel_sha256'], 'whole wheel SHA')
payloads = {}
with zipfile.ZipFile(wheel) as z:
    names = [n for n in z.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
    check(len(names) == len(set(names)) == 25, '25 unique package payloads')
    for name in names:
        raw = z.read(name)
        check(raw == (install / name).read_bytes(), 'whole installed payload equal wheel: ' + name)
        if name.endswith('.py'):
            check(raw == (R / 'src' / name).read_bytes(), 'Python wrapper byte exact actual source: ' + name)
        payloads[name] = {'bytes': len(raw), 'sha256': sha_bytes(raw)}
    record = next(n for n in z.namelist() if n.endswith('.dist-info/RECORD'))
    wheel_record_count = 0
    for name, digest, length in csv.reader(io.StringIO(z.read(record).decode())):
        if not digest:
            check(name == record, 'only wheel RECORD omits digest')
            continue
        raw = z.read(name)
        encoded = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).rstrip(b'=').decode()
        check(digest == 'sha256=' + encoded and int(length) == len(raw), 'wheel RECORD digest/length: ' + name)
        wheel_record_count += 1
extension = next(n for n in payloads if n.startswith('calmetrics_engine/_native.') and n.endswith('.so'))
check(len([n for n in payloads if n.startswith('calmetrics_engine/_native.') and n.endswith('.so')]) == 1, 'one native extension')
check(sha(build / Path(extension).name) == payloads[extension]['sha256'] == i['installed_binaries'][extension], 'native build/wheel/install equality')
worker_built = macho(build / 'calmetrics_worker')
worker_installed = macho(install / 'calmetrics_engine/calmetrics_worker')
check(worker_built['uuid'] == worker_installed['uuid'] == i['worker_uuid'] and
      worker_built['header_cpu'] == worker_installed['header_cpu'] and
      worker_built['sections'] == worker_installed['sections'] and len(worker_built['sections']) == 14,
      'worker UUID/CPU/all14 mapped sections equal')
check(worker_built['sha256'] == i['worker_build_sha256'] == p['package_audit']['worker_build_sha256'] and
      worker_installed['sha256'] == i['installed_binaries']['calmetrics_engine/calmetrics_worker'] ==
      p['package_audit']['worker_installed_sha256'], 'worker distinct file hashes')
check(worker_built['sha256'] != worker_installed['sha256'] and
      worker_installed['symbol_table']['nsyms'] < worker_built['symbol_table']['nsyms'], 'worker symbol strip evidence')
check(i['worker_strip_transform'] == 'strip -u -r' and 'execute_process(COMMAND "/usr/bin/strip" -u -r ' in
      (build / 'cmake_install.cmake').read_text(), 'CMake installed worker strip transform')
report = json.loads((ACT / 'runtime-identity.log').read_text().splitlines()[-1])
probe_sha = sha(PLAN / 'runtime_probe.py')
probe_source = (PLAN / 'runtime_probe.py').read_text()
check(probe_sha == m['helper_sha256']['runtime_probe.py'], 'runtime probe frozen SHA')
check("assert result.audit['python_fallback'] == 0" in probe_source and
      "assert result.audit['request_time_compilation'] == 0" in probe_source and
      'assert sys.flags.optimize == 0' in probe_source, 'successful nonoptimized probe asserts zero fallback/request compilation')
check(report == i['build_info'] and report['optimize'] == 0 and report['engine_build_id'] == expected_id and
      report['package_path'] == str(install / 'calmetrics_engine/__init__.py'), 'runtime log identity and package binding')
check(report['build_info']['runtime_jit'] == 0 and report['build_info']['execution_backend'] == 'pybind11_aot' and
      report['build_info']['graph_execution_backend'] == 'native_graph_interpreter', 'runtime reports AOT/native graph/no JIT')
check(sha(ACT / 'pipeline.json') == EXPECTED_PIPELINE and sha(ACT / 'package/identity.json') == EXPECTED_IDENTITY and
      native(R) == actual_source, 'terminal pipeline/identity/source unchanged across review')
result = {'status': 'passed_independent_actual_r2_build_identity_review_only', 'started_utc': started,
          'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'pipeline_sha256': EXPECTED_PIPELINE, 'identity_sha256': EXPECTED_IDENTITY,
          'plan_manifest_sha256': EXPECTED_PLAN, 'decision_sha256': EXPECTED_DECISION,
          'checks': checks, 'guards': guards, 'source_count': len(actual_source),
          'source_build_id': expected_id, 'test_inventory_count': len(m['tests_after']),
          'payloads': payloads, 'wheel_record_hashed_members': wheel_record_count,
          'actual_recipe_count': len(actual_recipes), 'duplicate_tu_blocks': duplicates,
          'candidate_duplicate_tu_blocks': candidate_duplicates, 'recipes_digest': recipe_digest,
          'cmake_configuration': actual_cmake,
          'worker_built': worker_built, 'worker_installed': worker_installed,
          'runtime_probe_sha256': probe_sha, 'runtime_smoke_asserts_zero_fallback_and_request_compilation': True,
          'runtime_smoke_is_one_sum_graph_only': True, 'project_imported_by_reviewer': False,
          'heavy_work_started_by_reviewer': False, 'numeric_qualification_proved_by_this_review': False,
          'performance_proved_by_this_review': False, 'production_adopted': False, 'goal_complete': False}
(OUT / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'production-inputs.json').write_text(json.dumps(actual_source, indent=2) + '\n')
(OUT / 'normalized-tu-recipes.json').write_text(json.dumps(actual_recipes, indent=2) + '\n')

# New actual affected qualification audit. Revalidates the whole fresh package
# and source above; no historical candidate XML is used for this result.
QUAL = PLAN / 'actual-qualification-affected-r1'
QUAL_SHA = '58a1c99dcc479abb2a8708afe141c5ff230fff912f78d7df3d8efcb721bf0bdc'
q = load(QUAL / 'pipeline.json')
check(sha(QUAL / 'pipeline.json') == QUAL_SHA, 'actual affected terminal pipeline SHA')
check(q['status'] == 'passed_actual_qualification_independent_review_pending' and q['scope'] == 'affected' and
      q.get('finished_epoch') and 'current' not in q, 'actual affected complete terminal state')
check(q['identity'] == str(ACT / 'package/identity.json') and q['identity_sha256'] == EXPECTED_IDENTITY,
      'affected identity is actual-r2 rather than snapshot candidate')
check(q['admission']['decision'] == str(DECISION) and q['admission']['decision_sha256'] == EXPECTED_DECISION and
      q['package_audit'] == p['package_audit'], 'affected same sole decision and revalidated actual package')
check([j['label'] for j in q['jobs']] == ['collection','native','python'] and
      all(j['returncode'] == 0 and sha(j['log']) == j['log_sha256'] for j in q['jobs']), 'affected three jobs exit0/raw logs')
runner_sha = sha(PLAN / 'qualify_actual.py')
check(runner_sha == m['helper_sha256']['qualify_actual.py'], 'qualification runner frozen SHA')
runner_source = (PLAN / 'qualify_actual.py').read_text()
check('PYTHONPATH=identity[\'installed\']' in runner_source and 'cwd=guard.R' in runner_source and
      "env.pop(key, None)" in runner_source and "'PYTHONOPTIMIZE'" in runner_source and
      "CME_EXPECT_WEIGHT_LANES='1'" in runner_source, 'actual runner source binds install/R/nonoptimized packet mode')
check(not (R / 'calmetrics_engine').exists() and not list((R / 'tests').rglob('conftest.py')) and
      '--import-mode=importlib' in (R / 'pyproject.toml').read_text(), 'src package layout/importlib no local conftest override')
modules = ['tests/test_compact_weight_lanes.py'] + m['related_modules']
check(q['jobs'][0]['command'][4:4+len(modules)] == modules and
      q['jobs'][2]['command'][4:4+len(modules)] == modules and
      q['jobs'][0]['command'][:4] == [m['python'],'-B','-m','pytest'],
      'affected commands select the 12 actual source test modules')
expected = {tuple(v) for v in m['expected_ids']['affected']}
native_expected = {tuple(v) for v in m['native_ids']}
check(len(expected) == len(m['expected_ids']['affected']) == 1049 and
      expected == {tuple(v) for v in m['expected_ids']['focused']} | {tuple(v) for v in m['expected_ids']['related']},
      'frozen affected exact IDs equal 49 focused plus1000 related')
def node(case):
    klass, name = case
    parts = klass.split('.')
    return 'tests/' + parts[1] + '.py::' + '::'.join(parts[2:] + [name])
collected_lines = [v.strip() for v in (QUAL / 'collection.log').read_text().splitlines()
                   if v.startswith('tests/') and '::' in v]
check(len(collected_lines) == len(set(collected_lines)) == 1049 and set(collected_lines) == {node(v) for v in expected},
      'complete collection exact IDs/no duplicate')
check(q['jobs'][0]['count'] == 1049 and q['jobs'][0]['exact_expected_ids'], 'collection receipt count agrees')
def xml_result(job, expected_ids):
    file = Path(job['xml'])
    check(file.parent == QUAL and sha(file) == job['xml_sha256'], 'fresh actual XML path/SHA: ' + job['label'])
    tree = ET.parse(file).getroot()
    cases = list(tree.iter('testcase'))
    ids = [(v.get('classname'),v.get('name')) for v in cases]
    bad = [v for v in cases if any(v.find(tag) is not None for tag in ('failure','error','skipped'))]
    check(len(ids) == len(set(ids)) == len(expected_ids) and set(ids) == expected_ids and not bad,
          'complete actual executed IDs/no duplicate/failure/error/skip: ' + job['label'])
    digest = sha_bytes(json.dumps(sorted(ids), separators=(',', ':')).encode())
    check(job['tests'] == len(ids) and job['ids_sha256'] == digest and
          all(job[k] == 0 for k in ('failures','errors','skips')), 'XML count and exact IDs digest: ' + job['label'])
    for suite in tree.iter('testsuite'):
        check(all(int(suite.get(k,0)) == 0 for k in ('failures','errors','skipped','disabled')), 'suite aggregate zero failures: ' + job['label'])
    return {'count':len(ids),'ids_sha256':digest,'module_counts':dict(collections.Counter(v[0] for v in ids)),
            'xml_sha256':sha(file), 'ids':sorted(ids), 'root_attributes':tree.attrib}
native_xml = xml_result(q['jobs'][1], native_expected)
python_xml = xml_result(q['jobs'][2], expected)
check(q['unique_python_tests'] == 1049 and q['unique_native_tests'] == 9 and q['actual_package_rebuilt'] and
      q['source_adopted'] and not q['goal_complete'], 'actual qualification phase/counts')
check(q['jobs'][1]['command'][1:3] == ['--test-dir',str(build)], 'native CTest explicitly actual-r2 build')
ctest = (build / 'CTestTestfile.cmake').read_text()
native_arguments = {name:re.findall(r'"([^"]+)"', tail) for name,tail in
                    re.findall(r'^add_test\(\[=\[([^\]]+)\]=\] ([^\n]+)\)$', ctest, re.M)}
native_commands = {name:args[0] for name,args in native_arguments.items()}
check(set(native_commands) == {v[1] for v in native_expected} and
      all(Path(path) == build / name and Path(path).is_file() for name,path in native_commands.items()),
      'nine generated CTest commands exclusively actual-r2 native executables')
check(all(all(Path(arg) == build/'calmetrics_worker' for arg in args[1:]) for args in native_arguments.values()),
      'native runtime/result extra arguments bind actual-r2 built worker')
native_binaries = {name:{'path':path,'sha256':sha(path),'bytes':Path(path).stat().st_size} for name,path in native_commands.items()}
check('Test project ' + str(build) in (QUAL/'native.log').read_text() and
      '100% tests passed, 0 tests failed out of 9' in (QUAL/'native.log').read_text() and
      '1049 passed' in (QUAL/'python.log').read_text(), 'raw actual native/python terminal summaries')
helper = (R / 'tests/test_compact_path_execution.py').read_text()
check('assert result.audit["python_fallback"] == 0' in helper and
      'assert result.audit["request_time_compilation"] == 0' in helper and
      'assert_private' in (R / 'tests/test_compact_weight_lanes.py').read_text(), 'executed private compact helper asserts no fallback/request compilation')
cleanup_path = Path('/private/tmp/calmetrics-requested-cache-cleanup-20261010T124826Z/final-result.json')
cleanup = load(cleanup_path)
check(cleanup['status'] == 'completed' and cleanup['cpp_deleted_files'] == 128 and
      cleanup['total_deleted_files'] == 1382, 'separate authorized cache cleanup receipt')
check(sha(QUAL/'pipeline.json') == QUAL_SHA and sha(ACT/'package/identity.json') == EXPECTED_IDENTITY and
      native(R) == actual_source, 'affected terminal/source/package identity unchanged across audit')
result.update(status='passed_independent_actual_affected_qualification_review',
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              affected_pipeline_sha256=QUAL_SHA, qualification_runner_sha256=runner_sha,
              qualification_runtime_binding='frozen runner PYTHONPATH actual-r2 install; cwd actual R; src layout/importlib; no conftest override',
              complete_collection_ids=sorted(collected_lines), actual_python_xml=python_xml,
              actual_native_xml=native_xml, actual_native_binaries=native_binaries,
              actual_native_command_arguments=native_arguments,
              cleanup_receipt_sha256=sha(cleanup_path), actual_protected_code_phase_count=27332,
              actual_affected_numeric_qualification_proved=True, full_numeric_qualification_proved=False,
              full_pipeline_not_read_or_assumed_terminal=True,
              numeric_qualification_proved_by_this_review=True,
              fallback_assert_scope='executed assert_private helper paths only; not every test/graph globally',
              production_adopted=False,goal_complete=False)
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','affected_pipeline_sha256','source_count','test_inventory_count',
                                    'source_build_id','actual_recipe_count','guards','actual_protected_code_phase_count']}))
