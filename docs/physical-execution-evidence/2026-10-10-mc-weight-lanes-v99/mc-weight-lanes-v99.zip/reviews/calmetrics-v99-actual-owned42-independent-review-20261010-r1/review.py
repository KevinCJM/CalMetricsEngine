"""Read-only stdlib metadata review. --final only after root confirms original session terminal."""
from pathlib import Path
import argparse, ast, datetime, hashlib, json, math, statistics, zipfile
O=Path(__file__).resolve().parent
P=Path('/private/tmp/calmetrics-v99-adoption-plan-20261010/r7')
Q=P/'replay-r1'
FULL=Path('/private/tmp/calmetrics-v99-actual-full-independent-review-20261010-r1')
EXPECTED='885742ad47010f7a12c0ad32e1ec400c14e6b4a0c551cb838df6f60d5280da84'
PLATFORM=Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/FundInvestmentResearchPlatform/backend/scenario_stress/numba_kernels.py')
PLATFORM_SHA='bb53056653d697c698dab4ac5e716d96dbaec9071157d755c3fbef32e9831b79'
E={};CHECKS=[]
def check(v,s):
 CHECKS.append({'check':s,'passed':bool(v)})
 if not v:raise RuntimeError(s)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(131072),b''):h.update(b)
 return h.hexdigest()
def record(p,want=None):
 p=Path(p);h=sha(p);check(want is None or h==want,'SHA '+str(p))
 if str(p) in E:check(E[str(p)]==h,'same evidence SHA '+str(p))
 E[str(p)]=h;return h
def load(p,want=None):record(p,want);return json.loads(Path(p).read_text())
def save(n,v):
 p=O/n;check(not p.exists(),'fresh output '+n);p.write_text(json.dumps(v,indent=2)+'\n');return sha(p)
def signatures(r):
 s=r['signatures'];check(s['rng_can_compile'] is False and len(s['rng'])==len(s['transform'])==1,'one disabled RNG/transform signature')
 check(len(s['consumers'])==4,'all four fixed consumers')
 for n,d in s['consumers'].items():
  check(d['can_compile'] is False and len(d['signatures'])==len(d['nopython_signatures'])==1,'disabled single '+n)
  check(d['targetoptions']['nopython'] is True and d['targetoptions']['nogil'] is True,'fixed options '+n)
 return s
def nodes(p):
 record(p);t=ast.parse(Path(p).read_bytes());out={}
 for n in t.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):out[n.name]=ast.dump(n,include_attributes=False)
  elif isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):out[n.targets[0].id]=ast.dump(n,include_attributes=False)
 return out
def ref_proof(r,m):
 v=r['reference'];check(v['upstream_path']==str(PLATFORM) and v['upstream_sha256']==PLATFORM_SHA,'reference exact source')
 for k in ['full_function_and_decorator_ast_identical','type_alias_ast_identical','fixed_c_dtype_signatures_preserved','cache_and_nogil_preserved']:check(v[k] is True,'reference '+k)
 check(not v['production_runtime_imported'] and v['quantile_inline']=='always','reference import/inline')
 check(v['numba_cache_directory']==str(Q/'support-snapshot/production-numba-cache'),'shared numba cache path')
 check(v['transform']['request_compilation_disabled'] and v['transform']['complete_function_and_decorator_ast_identical'],'transform disabled exact AST')
 check(v['extracted_source_sha256']==m['lightweight_files_sha256'][v['extracted_path']],'fixed extracted source SHA')
 check(v['transform']['extracted_sha256']==m['lightweight_files_sha256'][str(Q/'support-snapshot/transform_signature_kernel.py')],'transform extracted SHA')
 return v

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--final',action='store_true');a=ap.parse_args()
 check(a.final,'no default full SHA scanning permitted')
 confirmation=load(O/'root-terminal-confirmation.json')
 check(confirmation['original_session']==66475 and confirmation['original_exit_code']==0 and confirmation['root_confirmed_terminal'],'root original session exit0 confirmed')
 process=load(O/'process-terminal.json');check(process['all_original_pids_absent'],'all original parent/launcher PIDs absent')
 m=load(Q/'manifest.json',EXPECTED);check((Q/'manifest.sha256').read_text().strip()==EXPECTED,'replay manifest digest file')
 qraw=(Q/'pipeline.json').read_bytes();q=json.loads(qraw);qh=record(Q/'pipeline.json')
 check(qh==confirmation['pipeline_sha256']=='f6d756ca562052f8d212c724ddaf3d5721de2d4bfc7d998eb9e3838ab75b5e07','original terminal pipeline SHA')
 check(q['status']=='passed_actual_owned_full_chain_independent_review_pending' and q.get('finished_epoch') and 'current' not in q,'actual42 terminal state')
 check(q['manifest_sha256']==EXPECTED and q['manifest']==str(Q/'manifest.json') and q['pid']==86567,'pipeline manifest and original parent')
 check(q['source_adopted'] and not q['goal_complete'],'actual42 phase scope')
 check(len(q['jobs'])==len(m['jobs'])==42 and len({j['label'] for j in q['jobs']})==42,'42 unique planned jobs')
 expected_raw={j['label']+suffix for j in m['jobs'] for suffix in ['.json','.launch.json','.log']}
 actual_raw={p.name for p in Q.iterdir() if p.is_file() and p.name.startswith(('normal_','student_'))}
 check(actual_raw==expected_raw and len(actual_raw)==126,'exact126 raw/log/launch inventory')
 check(m['actual_adoption_manifest_sha256']=='6513a4fd12b0f2c003466043bbf76c3e81b73a3ce82ff9e681a7d7f10f73a43f','r7 binding')
 record(m['actual_qualification'],m['actual_qualification_sha256'])
 prior=load(FULL/'reviewed.json','f5285f7347a1f4cc9353627e3a60be566a2a2b1a87dd302b58feba7ab4354437')
 check(prior['full_qualification_passed'] and prior['build_id']==m['packages']['actual99']['build_id'],'prior actual full qualification same BuildID')
 # Full protected/source/raw receipt verification is intentionally deferred until terminal.
 prior_shas=load(FULL/'sha256-receipt.json','1de547a73ab40ac16742ed9e043d2c2a71f3f9df6874719b4eb778da2b710520')
 for n,h in prior_shas['evidence_sha256'].items():record(n,h)
 check(prior['exact_protected_code_phase_count']==27332,'exact protected count preserved')
 r7=load(P/'manifest.json',m['actual_adoption_manifest_sha256'])
 guard_receipt=load(O/'code-guard.json');check(guard_receipt['status']=='passed_readonly_code_guard' and guard_receipt['exit_code']==0,'fresh r7 code phase guard')
 for n,h in m['lightweight_files_sha256'].items():record(n,h)
 for key,d in m['drivers'].items():record(d['path'],d['sha256'])
 for n in ['run_replay.py','replay_launcher.py']:record(P/n,r7['helper_sha256'][n])
 record(m['probe'],m['probe_sha256'])
 record(PLATFORM,PLATFORM_SHA)
 original=nodes(PLATFORM)
 for name in ['production_signature_kernels.py','transform_signature_kernel.py']:
  extracted=nodes(Q/'support-snapshot'/name)
  for k,v in extracted.items():
   if k in original:check(v==original[k],'exact math/decorator/alias AST '+name+':'+k)
 rng_path=Path(m['drivers']['owned']['path']).parent/'fixed_signature_reference.py'
 for k,v in nodes(rng_path).items():
  if k in original:check(v==original[k],'exact platform RNG AST '+k)
 identities={}
 for name,p in m['packages'].items():
  i=load(p['identity'],p['identity_sha256']);identities[name]=i
  check(i['build_id']==p['build_id'] and i['installed']==p['install'] and len(i['source'])==93,'selected '+name+' source identity')
  inventory={str(x.relative_to(Path(p['source']))) for x in (Path(p['source'])/'cpp').rglob('*') if x.is_file()}|{'CMakeLists.txt','pyproject.toml'}
  check(inventory==set(i['source']),'selected93 inventory '+name)
  for n,h in i['source'].items():record(Path(p['source'])/n,h)
  for n,h in i['installed_binaries'].items():record(Path(p['install'])/n,h)
  record(i['wheel'],i['wheel_sha256'])
  with zipfile.ZipFile(i['wheel']) as z:
   names=[n for n in z.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
   check(len(names)==len(set(names))==25,'25 whole wheel payloads '+name)
   for n in names:check((Path(p['install'])/n).read_bytes()==z.read(n),'wheel/install '+name+':'+n);record(Path(p['install'])/n)
  enc=';'.join(i['compiler'])+''.join(';'+n+':'+h for n,h in sorted(i['source'].items()))
  check(hashlib.sha256(enc.encode()).hexdigest()==p['build_id'],'recomputed '+name+' build ID')
 check([n for n in identities['actual99']['source'] if identities['actual99']['source'][n]!=identities['actual79']['source'][n]]==['cpp/compact_path.cpp'],'only authorized native delta')
 owned=Path(m['drivers']['owned']['path']).read_text();rss=Path(m['drivers']['rss']['path']).read_text()
 for fragment in ['assert set(named)==set(targets)','v.shape==e.shape and v.dtype==e.dtype','not v.flags.writeable','np.testing.assert_array_equal(output.root_statuses,[0])','rtol=2e-12,atol=2e-13','rs.old.independent(np,old,current)','start=time.perf_counter_ns()','current=(native if backend==\'cpp\' else ref).run()','assert sig==signatures()']:
  check(fragment in owned,'unchanged raw proof '+fragment)
 helper=Path(m['packages']['actual99']['source'])/'tools/benchmark_memory.py';record(helper,'b3862bb22e58f01f874bad0fd8466a3eb63ac4f3803186846184aafb47f4d7f8')
 check('probe.cme_heap_begin()' in helper.read_text() and 'report["warm_peak_bytes"] = stages["warm_heap"].peak_bytes' in helper.read_text(),'continuous heap and no peak stage sum')
 check('stop.wait(.0005)' in rss and 'ready.wait()' in rss and 'current=owner.run()' in rss,'RSS sampling and ownership source')
 cases={'large_c1':dict(steps=200,paths=10000,factors=4,assets=32,combinations=1,tier='large'),
        'large_c8':dict(steps=200,paths=10000,factors=4,assets=32,combinations=8,tier='large'),
        'short_many':dict(steps=5,paths=50000,factors=32,assets=32,combinations=32,tier='large_short_wide_horizon')}
 kinds=['time_actual79_before','time_actual99','time_actual79_after','heap_actual99','heap_njit','rss_actual99','rss_njit']
 expected_labels=[f'{family}_{case}_{kind}' for family in ['normal','student'] for case in cases for kind in kinds]
 check([j['label'] for j in m['jobs']]==expected_labels,'six by seven serial schedule')
 reports={};epochs=[];untracked={}
 for j,p in zip(q['jobs'],m['jobs']):
  label=j['label'];family,case,kind=next((f,c,k) for f in ['normal','student'] for c in cases for k in kinds if f'{f}_{c}_{k}'==label)
  student=family=='student';metric=j['metric'];backend='njit' if kind.endswith('_njit') else 'cpp'
  check(all(j[k]==v for k,v in p.items()) and j['returncode']==0,'completed exact plan exit0 '+label)
  for k,suffix in [('log','.log'),('output','.json'),('launch','.launch.json')]:check(j[k]==str(Q/(label+suffix)),'fresh raw path '+label+':'+k)
  r=load(j['output'],j['output_sha256']);l=load(j['launch'],j['launch_sha256']);record(j['log'],j['log_sha256'])
  check(l['status']=='passed_original_driver_assertions' and l['pid']==j['pid'],'original assert terminal '+label)
  check(q['started_epoch']<=l['started_epoch']<l['finished_epoch']<=j['finished_epoch']<=q['finished_epoch'],'job epochs '+label)
  if epochs:check(epochs[-1]['parent_finished_epoch']<=l['started_epoch'],'no child lifetime overlap '+label)
  epochs.append(dict(label=label,pid=j['pid'],started_epoch=l['started_epoch'],finished_epoch=l['finished_epoch'],parent_finished_epoch=j['finished_epoch']))
  check(l['selected_identity']==m['packages'][j['package']] and l['selected_package']==j['package'],'launch exact package '+label)
  check(l['assertions']==dict(optimize=0,sentinel_raised=True) and l['heavy_proof_in_parent_only'] and l['unchanged_numerical_driver'],'live assertion and guard boundary '+label)
  check(l['cache_path_adaptation']==['production_bench_support.HERE','production_reference.DESTINATION','transform_reference.DEST'],'unchanged cache path adapter '+label)
  selected=m['packages'][j['package']];i=identities[j['package']];identity=r['identity']
  check(identity['build_id']==selected['build_id'] and identity['build_id_verified'] and identity['source_root']==selected['source'],'runtime source '+label)
  check(identity['manifest_path']==selected['identity'] and identity['manifest_sha256']==selected['identity_sha256'],'runtime manifest '+label)
  check(identity['source_sha256']==i['source'] and identity['installed_binary_sha256']==i['installed_binaries'],'runtime package actual SHAs '+label)
  check(r['case']==case and r['student']==student,'actual workload '+label)
  check(all(pool['num_threads']==1 for pool in r['threadpools']),'runtime library thread caps '+label)
  parity=r['parity'];a=parity['audit'];roots=cases[case]['combinations']*48
  check(parity['all_named_roots_compared']==len(a['outputs'])==roots,'all numerical roots '+label)
  for start in range(0,roots,48):
   group=a['outputs'][start:start+48]
   check(group[0]==dict(dtype='float64',kind='matrix',axes=['component','time'],shape=['5','(1+T)']),'fan schema '+label)
   check(group[1]==dict(dtype='float64',kind='matrix',axes=['path','time'],shape=['12','(1+T)']),'samples schema '+label)
   check(all(v==dict(dtype='float64',kind='scalar',axes=[],shape=[]) for v in group[2:]),'stats/contribution scalar schema '+label)
  check(a['engine_build_id']==selected['build_id'] and a['native_aot'] and a['execution_backend']=='cpp_aot','actual AOT execution '+label)
  check(a['cpu_budget']==a['thread_count']==a['process_count']==1 and a['cpu_tokens']==1,'CPU1 '+label)
  check(all(a[k]==0 for k in ['python_fallback','python_operator_calls','request_time_compilation','python_worker_callbacks']),'zero recorded fallback/request compile '+label)
  check(a['result_lifetime']=='independent' and a['output_copy_bytes']==0 and a['boundary_copy_bytes']==0,'independent result and boundary copy '+label)
  check(a['error_policy']=='raise' and a['status_contract']=='indicator-status-1','root status and error policy '+label)
  check(not a['prepared'] and isinstance(a['prepared_cached'],bool) and 'bounded_compact_scan_consumer_closure' in a['reason_codes'],'ordinary scheduler execution with actual cache flag '+label)
  check(r.get('reference_replay_copy_bytes_per_call',0)==0,'no extra immutable replay copy '+label)
  check(r['driver_sha256']==m['drivers']['rss' if metric=='rss' else 'owned']['sha256'],'unchanged original driver '+label)
  if metric in ['time','rss']:signatures(r);ref_proof(r,m)
  log=Path(j['log']).read_text();tail=log.strip().splitlines()[-1];prefix='PASS '+case+' '+(backend if metric=='rss' else str(student))+' '
  check(tail.startswith(prefix) and ast.literal_eval(tail[len(prefix):])==r.get('medians_ms',r.get('measurement')),'raw log terminal values '+label)
  if metric=='time':
   check(r['dimensions']==cases[case] and r['two_result_generations_retained'],'time dimensions and two owners '+label)
   check(r['input_preparation']==dict(same_frozen_input_preparation=True,source_sha256=PLATFORM_SHA,no_experimental_rng=True),'same owned RNG prep '+label)
   check(r['graph_construction_and_static_fixture_outside_timer'] and r['rng_allocation_and_native_boundary_inside_timer'] and r['rng_preparation_external_to_engine'],'full run timer '+label)
   check(not r['experimental_native_rng_used_inside_measured_calls'],'no experimental RNG '+label)
   for n,v in r['samples'].items():check(len(v)==3 and all(math.isfinite(x) and x>0 for x in v) and r['medians_ms'][n]==statistics.median(v),'three raw samples exact median '+label+':'+n)
   for turn in range(3):
    mark=case+' '+str(student)+' '+str(turn)+' ';ls=[v for v in log.splitlines() if v.startswith(mark)]
    check(len(ls)==1 and ast.literal_eval(ls[0][len(mark):])=={k:v[turn] for k,v in r['samples'].items()},'raw paired round '+label+':'+str(turn))
   check(r['excluded']==['covariance_root_generation','coverage','limits','JSON','stage_ordered_first_fault'],'time business exclusions '+label)
  else:
   check(r['backend']==backend and r['pid']==j['pid'],'memory backend PID '+label)
   v=r['measurement']
   if metric=='heap':
    check(v['heap_schema']=='continuous-live-1' and r['two_result_generations_overlap'] and r['no_heap_stage_peak_summing'],'continuous heap two-generation contract '+label)
    check(r['heap_epoch_includes_static_inputs_graph_owner_and_all_rng_calls'] and not r['complete_allocator_evidence'],'complete setup epoch and blindspots '+label)
    check(r['probe_sha256']==m['probe_sha256'] and r['helper_sha256']=='b3862bb22e58f01f874bad0fd8466a3eb63ac4f3803186846184aafb47f4d7f8','heap instrumentation '+label)
    check(v['cold_peak_bytes']==v['cold_heap']['peak_bytes'] and v['warm_peak_bytes']==v['warm_heap']['peak_bytes'],'heap stage peaks selected '+label)
    stages=['setup_heap','cold_heap','cold_retained_heap','warm_baseline_heap','warm_heap','warm_retained_heap']
    for stage in stages:
     s=v[stage];check(s['table_overflows']==0 and s['peak_bytes']>=s['live_bytes'] and s['allocations']>=s['frees'],'heap counter sanity '+label+':'+stage)
    check(all(v[stages[k]]['allocated_bytes']<=v[stages[k+1]]['allocated_bytes'] for k in range(len(stages)-1)),'continuous cumulative allocation counters '+label)
    untracked[label]={stage:v[stage]['untracked_frees'] for stage in stages}
   else:
    check(v['schema']=='complete-setup-cold-warm-owned-rss-1' and v['sampling_interval_ms']==.5,'RSS schema/sample '+label)
    check(v['rss_peak']>=v['rss_baseline']>0 and v['rss_delta']==v['rss_peak']-v['rss_baseline'],'RSS total/delta '+label)
    check(r['includes']==['static_input_construction','graph_and_scheduler','cold_call','five_warm_calls','three_replacement_calls','two_result_generations'],'RSS complete setup and replacement '+label)
    check(r['excludes']==['imports','machine_code_compilation','tiny_warmup','post_epoch_validation'] and not r['allocator_audit_complete'],'RSS exclusions and allocator boundary '+label)
    check(not r['experimental_rng_loaded'],'RSS fixed source RNG '+label)
  reports[label]=r
 # Conservative summary retains raw anomalous NJIT results and never silently adjusts samples.
 rows=[];anomalies=[];negative=[]
 for family in ['normal','student']:
  for case in cases:
   prefix=family+'_'+case+'_';before=reports[prefix+'time_actual79_before'];cur=reports[prefix+'time_actual99'];after=reports[prefix+'time_actual79_after']
   check(before['signatures']==cur['signatures']==after['signatures'],'paired signatures identical '+prefix)
   check(before['parity']['static_inputs_unchanged']==cur['parity']['static_inputs_unchanged']==after['parity']['static_inputs_unchanged'],'paired physical static input content '+prefix)
   check(before['dimensions']==cur['dimensions']==after['dimensions'] and before['threadpools']==cur['threadpools']==after['threadpools'],'paired workload/runtime libraries '+prefix)
   check(before['reference']['runtime_versions']==cur['reference']['runtime_versions']==after['reference']['runtime_versions'],'paired NumPy/Numba/Python versions '+prefix)
   check(before['input_preparation']==cur['input_preparation']==after['input_preparation'],'paired input-preparation source '+prefix)
   cpp=cur['medians_ms']['cpp_ms'];old=min(before['medians_ms']['cpp_ms'],after['medians_ms']['cpp_ms'])
   ni_controls=[before['medians_ms']['njit_ms'],cur['medians_ms']['njit_ms'],after['medians_ms']['njit_ms']];ni=min(ni_controls)
   row=dict(student=family=='student',case=case,dimensions=cases[case],time=dict(actual99_ms=cpp,actual79_before_ms=before['medians_ms']['cpp_ms'],actual79_after_ms=after['medians_ms']['cpp_ms'],actual99_cpp_over_stronger_actual79=cpp/old,actual99_cpp_change_vs_stronger_old_pct=100*(cpp/old-1),raw_njit_before_actual99_after_ms=ni_controls,conservative_njit_ms=ni,actual99_cpp_over_conservative_njit=cpp/ni,conservative_speedup=ni/cpp,raw_own_pair_speedup=cur['medians_ms']['njit_ms']/cpp,all_raw_samples=dict(before=before['samples'],actual99=cur['samples'],after=after['samples'])))
   audit=cur['parity']['audit']
   row['actual99_copy_accounting_from_validation_audit']=dict(boundary_copy_bytes=audit['boundary_copy_bytes'],output_copy_bytes=audit['output_copy_bytes'],algorithm_copy_bytes=sum(c.get('algorithm_copy_bytes',0) for c in audit['native_chunks']),root_copy_bytes=sum(c.get('root_copy_bytes',0) for c in audit['native_chunks']),direct_output_bytes=sum(c.get('direct_output_bytes',0) for c in audit['native_chunks']),scope='Same workload validation audit; scratch copies are counted inside whole run and are not claimed zero.')
   if max(ni_controls)/min(ni_controls)>1.25:
    anomalies.append(dict(code='paired_njit_control_variation',case=case,student=family=='student',raw_medians_ms=ni_controls,max_over_min=max(ni_controls)/min(ni_controls),source_parameters_signatures_thread_caps_same=True,cause='not established from retained metadata',resolution='use strongest same-run NJIT median conservatively; preserve anomaly; retest required if genuine differing conditions are found',anomalous_raw_speedup_not_adoption_basis=True))
   for metric,keys in [('heap',['cold_peak_bytes','warm_peak_bytes']),('rss',['rss_baseline','rss_peak','rss_delta'])]:
    left=reports[prefix+metric+'_actual99']['measurement'];right=reports[prefix+metric+'_njit']['measurement']
    row[metric]={k:dict(actual99_bytes=left[k],njit_bytes=right[k],actual99_minus_njit_bytes=left[k]-right[k],actual99_over_njit=left[k]/right[k]) for k in keys}
   row['strict_diagnostics']=dict(time_pass=cpp<=ni,heap_pass=all(row['heap'][k]['actual99_minus_njit_bytes']<=0 for k in ['cold_peak_bytes','warm_peak_bytes']),rss_delta_pass=row['rss']['rss_delta']['actual99_minus_njit_bytes']<=0,total_rss_pass=row['rss']['rss_peak']['actual99_minus_njit_bytes']<=0)
   for k,passed in row['strict_diagnostics'].items():
    if not passed:negative.append(dict(case=case,student=family=='student',diagnostic=k))
   rows.append(row)
 check((Q/'pipeline.json').read_bytes()==qraw,'terminal pipeline unchanged throughout review')
 result=dict(schema='actual-v99-owned42-independent-review-1',status='passed_independent_actual_owned42_evidence_review_with_retained_anomalies',confirmed_blockers=[],reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pipeline_sha256=qh,manifest_sha256=EXPECTED,jobs_reviewed=42,raw_log_launch_files=126,load_count=6,rows=rows,anomalies=anomalies,negative_results=negative,untracked_frees=untracked,child_epochs=epochs,checks=CHECKS,source_adopted=True,actual_owned42_replay_verified=True,normal_non_sanitizer=True,overall_performance_accepted=False,production_adopted=False,goal_complete=False,
  source_identity=dict(actual99=m['packages']['actual99'],actual79=m['packages']['actual79']),
  numerical_proof_boundary='Verified successful frozen-driver assertions and raw exact-root metadata; reviewer did not rerun numerical computation; JSON stores root schemas/audit, not every numerical array value.',
  prepared_cache_validation_audits={n:dict(prepared=r['parity']['audit']['prepared'],prepared_cached=r['parity']['audit']['prepared_cached']) for n,r in reports.items()},
  prepared_cache_boundary='All frozen calls use ordinary scheduler.execute; no explicit prepared execution. Audit prepared_cached denotes ordinary binding cache hit; normal_large_c1_rss_actual99 post-epoch validation audit records true, other41 false. These validation audits do not trace every timed/cache call.',
  assertions='Full named root shape/dtype/readonly/status0 plus discrete equality/allclose, static input hash, two independent generations, CPU1 and zero recorded callbacks/request JIT preserved by frozen unchanged drivers.',
  timing_scope='Same fixed-production NJIT RNG allocation, transform, projection, NAV, fan, all stats/samples/contributions; ordinary scheduler validation/planner/result inside timer; static fixture/graph outside.',
  memory_scope='Same owned chain setup+cold/warm/replacement; continuous malloc-family snapshots never summed; total RSS and peak-minus-prewarm baseline separately,0.5ms sampling.',
  limits=['Only3 paired time rounds per job; no confidence interval, long-term stability or hardware-noise causation proof.', 'Anomalous NJIT controls retained; strongest same-run NJIT median used conservatively. No11x claim from C8 outlier.', 'C32 tracked heap debt retained; no universal memory leadership or complete allocator/leak claim.', 'Heap misses Python arena suballocations/mmap/nonintercepted allocators/stack/preexisting Numba TLS; untracked frees retained.', 'RSS0.5ms can miss brief peaks; total and delta are distinct.', 'Covariance-root generation, coverage, limits, JSON packaging, stage-ordered first fault excluded.', 'This actual normal owned42 review does not prove actual SAN or upstream business admission.'],
  no_heavy_operation_started_by_reviewer=True,no_project_or_frozen_material_modified=True,evidence_sha256=dict(sorted(E.items())))
 review_sha=save('reviewed.json',result)
 table=['|负载|实际C++ ms|保守NJIT ms|保守倍数|旧C++前/后 ms|warm heap差值 B|RSS增量差值 B|','|---|---:|---:|---:|---:|---:|---:|']
 for r in rows:
  t=r['time'];table.append(f"|{'Student' if r['student'] else 'Normal'} {r['case']}|{t['actual99_ms']:.6f}|{t['conservative_njit_ms']:.6f}|{t['conservative_speedup']:.3f}|{t['actual79_before_ms']:.6f}/{t['actual79_after_ms']:.6f}|{r['heap']['warm_peak_bytes']['actual99_minus_njit_bytes']}|{r['rss']['rss_delta']['actual99_minus_njit_bytes']}|")
 (O/'comparison.md').write_text('\n'.join(table)+'\n')
 manifest=dict(schema='actual-v99-owned42-review-manifest-1',status='completed_readonly_evidence_review',replay_manifest_sha256=EXPECTED,actual_pipeline_sha256=qh,reviewed=str(O/'reviewed.json'),reviewed_sha256=review_sha,complete_sha256_receipt=str(O/'sha256-receipt.json'),raw_files=126,source_files=93,test_files=204,protected_code_files=27332,actual_owned42_verified=True,overall_performance_accepted=False,goal_complete=False)
 mh=save('manifest.json',manifest);(O/'manifest.sha256').write_text(mh+'\n')
 for p in O.rglob('*'):
  if p.is_file():record(p)
 sh=save('sha256-receipt.json',dict(status='all_bound_sha256_verified',unique_files=len(E),evidence_sha256=dict(sorted(E.items())),self_digest_stored_separately=True))
 (O/'sha256-receipt.sha256').write_text(sh+'\n')
 print(json.dumps(dict(status=result['status'],reviewed_sha256=review_sha,manifest_sha256=mh,sha256_receipt_sha256=sh,raw_files=126,unique_evidence_files=len(E),checks=len(CHECKS),anomalies=anomalies,negative_results=negative)))
if __name__=='__main__':main()
