# CMake generated Testfile for 
# Source directory: /Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine
# Build directory: /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[calmetrics_engine_excel_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_excel_tests")
set_tests_properties([=[calmetrics_engine_excel_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;231;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_native_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_native_tests")
set_tests_properties([=[calmetrics_engine_native_tests]=] PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;235;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_operator_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_operator_tests")
set_tests_properties([=[calmetrics_engine_operator_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;253;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_graph_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_graph_tests")
set_tests_properties([=[calmetrics_engine_graph_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;256;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_compiler_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_compiler_tests")
set_tests_properties([=[calmetrics_engine_compiler_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;259;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_runtime_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_runtime_tests" "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_worker")
set_tests_properties([=[calmetrics_engine_runtime_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;262;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_math_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_math_tests")
set_tests_properties([=[calmetrics_engine_math_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;265;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_stateful_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_stateful_tests")
set_tests_properties([=[calmetrics_engine_stateful_tests]=] PROPERTIES  _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;268;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
add_test([=[calmetrics_engine_result_tests]=] "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_engine_result_tests" "/private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r2/build/calmetrics_worker")
set_tests_properties([=[calmetrics_engine_result_tests]=] PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;271;add_test;/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/CMakeLists.txt;0;")
subdirs("_deps/highway-build")
