"""Read-only V99 adoption guards. No native/NumPy/JIT imports or project writes."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import runpy
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
R = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine')
F = Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/FundInvestmentResearchPlatform')
D99 = Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010')
MODES = ('normal-full', 'eigen-off', 'compact-packets-off', 'asan-ubsan')

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(131072), b''):
            h.update(part)
    return h.hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def git(root, *args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=root)

def status(root, all_files=False):
    args = ['status', '--porcelain=v1', '-z']
    if all_files:
        args += ['--untracked-files=all']
    return git(root, *args)

def records(raw):
    items = [item for item in raw.split(b'\0') if item]
    require(all(len(x) > 3 and b'R' not in x[:2] and b'C' not in x[:2] for x in items),
            'rename/copy status needs an explicit new reviewed plan')
    return set(items)

def native_sources(root):
    names = sorted([str(p.relative_to(root)) for p in (root / 'cpp').rglob('*') if p.is_file()] +
                   ['CMakeLists.txt', 'pyproject.toml'])
    return {name: sha(root / name) for name in names}

def cpp_recipes(build, source):
    """Normalize only source/build locations, never compiler options/definitions."""
    build, source = Path(build), Path(source)
    result = {}
    for block in (build / 'build.ninja').read_text().split('\n\nbuild '):
        header = block.splitlines()[0]
        if 'CXX_COMPILER_' not in header:
            continue
        match = re.search(r' ' + re.escape(str(source) + '/') + r'(cpp/[^ ]+)', header)
        if match is None:
            continue
        name = match.group(1)
        fields = {}
        for key in ('DEFINES', 'FLAGS', 'INCLUDES'):
            found = re.search(r'^  ' + key + r' = (.*)$', block, re.M)
            value = found.group(1) if found else ''
            fields[key] = value.replace(str(build), '<BUILD>').replace(str(source), '<SOURCE>')
        if name in result:
            require(result[name] == fields, 'one source has conflicting compile recipes: ' + name)
        result[name] = fields
    require('cpp/compact_path.cpp' in result and result, 'production TU recipes missing')
    return result

def tests(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted((root / 'tests').rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py', '.cpp', '.hpp', '.json')}

def manifest():
    path = HERE / 'manifest.json'
    require(sha(path) == (HERE / 'manifest.sha256').read_text().strip(), 'plan manifest changed')
    m = load(path)
    require(sys.flags.optimize == 0, 'assertions must execute')
    for name, expected in m['helper_sha256'].items():
        require(sha(HERE / name) == expected, 'plan helper changed: ' + name)
    for name, expected in m['frozen_sha256'].items():
        require(sha(name) == expected, 'frozen input changed: ' + name)
    return m

def verify(phase='before', document_receipt=None):
    m = manifest()
    require(phase in ('before', 'code', 'documents'), 'unknown adoption phase')
    changed = {x['path'] for x in m['adoption_changes']} if phase != 'before' else set()
    doc_changes = {}
    if phase == 'documents':
        require(document_receipt is not None, 'explicit independently reviewed document receipt required')
        d = load(document_receipt)
        require(d['status'] == 'reviewed_v99_actual_documents', 'documents have not been reviewed')
        require(d['plan_manifest_sha256'] == sha(HERE / 'manifest.json'), 'document receipt plan differs')
        doc_changes = {x['path']: x for x in d['files']}
        require(set(doc_changes) <= set(m['document_allowlist']), 'document scope expanded')
        for name, item in doc_changes.items():
            require(item['before_sha256'] == m['project_sha256'].get(name), 'document old SHA differs: ' + name)
            require(sha(R / name) == item['after_sha256'], 'document SHA differs: ' + name)
        changed.update(doc_changes)
    source_key = 'native_before' if phase == 'before' else 'native_after'
    test_key = 'tests_before' if phase == 'before' else 'tests_after'
    require(native_sources(R) == m[source_key], 'actual native source inventory/content differs')
    require(tests(R) == m[test_key], 'actual test inventory/content differs')
    require(native_sources(D99 / 'source') == m['native_after'], 'candidate native sources changed')
    require(sha(D99 / 'source/tests/test_compact_weight_lanes.py') == m['adoption_changes'][1]['new_sha256'],
            'candidate 49-case test changed')
    for name, expected in m['project_sha256'].items():
        if name not in changed:
            require(sha(R / name) == expected, 'protected existing file changed: ' + name)
    if phase == 'before':
        require(not (R / m['adoption_changes'][1]['path']).exists(), 'new R test already exists')
    else:
        for item in m['adoption_changes']:
            require(sha(R / item['path']) == item['new_sha256'], 'adopted file differs: ' + item['path'])
    for all_files, key in [(False, 'repository_status_normal_hex'), (True, 'repository_status_all_hex')]:
        if phase == 'documents' and not all_files:
            # normal Git output collapses new untracked directories; all-file output below
            # verifies every new file and all existing records exactly.
            continue
        expected = records(bytes.fromhex(m[key]))
        if phase != 'before':
            expected.add(b'?? tests/test_compact_weight_lanes.py')
        if phase == 'documents':
            for name, item in doc_changes.items():
                if item['before_sha256'] is None:
                    expected.add(('?? ' + name).encode())
        require(records(status(R, all_files)) == expected, 'unexpected actual Git status/inventory change')
    require(git(R, 'rev-parse', 'HEAD').decode().strip() == m['head'], 'actual HEAD changed')
    require(git(R, 'branch', '--show-current').decode().strip() == m['branch'], 'actual branch changed')
    require(hashlib.sha256(git(R, 'diff', '--cached', '--binary')).hexdigest() == m['index_diff_sha256'],
            'existing staged changes changed')
    require(status(F).hex() == m['platform_status_hex'], 'platform Git status changed')
    for name, expected in m['platform_sha256'].items():
        require(sha(F / name) == expected, 'platform protected source changed: ' + name)
    return dict(status='passed_readonly_' + phase + '_guard', source_files=len(m[source_key]),
                test_files=len(m[test_key]), protected_existing_files=len(m['project_sha256']) - len(changed),
                all_dirty_paths=len(m['dirty_paths']), project_modified_by_this_guard=False)

def xml_ids(path):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    ids = {(c.get('classname'), c.get('name')) for c in cases}
    require(len(ids) == len(cases), 'duplicate test IDs')
    require(all(not any(c.find(x) is not None for x in ('failure', 'error', 'skipped')) for c in cases),
            'failed/error/skipped qualification case')
    return ids

def ids_digest(ids):
    return hashlib.sha256(json.dumps(sorted(ids), separators=(',', ':')).encode()).hexdigest()

def bound_evidence(values, required=None):
    require(isinstance(values, dict) and values, 'empty evidence SHA map')
    if required is not None:
        require(all(values.get(name) == expected for name, expected in required.items()),
                'review does not bind every required raw evidence file')
    for name, expected in values.items():
        require(sha(name) == expected, 'bound evidence changed: ' + name)

def collection_nodes(path, expected):
    def node(case):
        klass, name = case
        parts = klass.split('.')
        return 'tests/' + parts[1] + '.py::' + '::'.join(parts[2:] + [name])
    actual = [line.strip() for line in Path(path).read_text(errors='replace').splitlines()
              if line.startswith('tests/') and '::' in line]
    require(len(actual) == len(set(actual)) and set(actual) == {node(x) for x in expected},
            'collection exact-ID mismatch')

def snapshot_full_chain(full_path, review, m):
    """Bind all six frozen loads and all raw/log/launch files, including cleanup followup."""
    full = load(full_path)
    require(full['status'] == 'passed_full_measurements_independent_review_pending' and 'current' not in full,
            'snapshot full chain not terminal passed')
    require(full['manifest_sha256'] == sha(m['candidate_full_manifest']), 'snapshot full plan differs')
    jobs = full['jobs']
    specs = {j['name']: j for j in m['candidate_full_jobs']}
    require(len(jobs) == len(specs) == 42 and {j['name'] for j in jobs} == set(specs),
            'six-load full chain missing/duplicate/extra jobs')
    evidence = {str(Path(full_path)): sha(full_path)}
    for j in jobs:
        spec = specs[j['name']]
        require(all(j[k] == value for k, value in spec.items()), 'full-chain workload/package differs')
        require(j['returncode'] == 0, 'full-chain child failed')
        for key, digest in [('log', 'log_sha256'), ('output', 'output_sha256'), ('launch_evidence', 'launch_sha256')]:
            require(sha(j[key]) == j[digest], 'full-chain raw/log/launch changed')
            evidence[j[key]] = j[digest]
        selected = m['candidate_full_packages'][j['package']]
        launch, raw = load(j['launch_evidence']), load(j['output'])
        require(launch['status'] == 'passed_original_driver_assertions' and launch['pid'] == j['pid'],
                'full-chain launch not passed/matching PID')
        require(launch['selected_package'] == j['package'] and launch['selected_identity'] == selected,
                'full-chain selected identity differs')
        require(launch['gate']['manifest_sha256'] == full['manifest_sha256'] and
                launch['assertions']['optimize'] == 0 and launch['assertions']['assert_sentinel_raised'] is True,
                'full-chain launch assertions/plan differ')
        require(launch['environment']['thread_caps'] == m['thread_environment'] and
                launch['environment']['pythonoptimize_absent'] is True and
                launch['environment']['heap_probe_injected'] == (j['metric'] == 'heap'),
                'full-chain CPU/assertion/probe environment differs')
        require(raw['case'] == j['case'] and raw['student'] == j['student'] and
                raw['identity']['build_id'] == selected['build_id'] and raw['identity']['build_id_verified'] is True,
                'full-chain raw workload/build differs')
        if j['metric'] == 'time':
            require(raw['cpu_budget'] == 1, 'full-chain time CPU budget differs')
        else:
            require(raw['backend'] == j['backend'] and raw['pid'] == j['pid'], 'full-chain raw backend/PID differs')
    parent_path, supplement_path, cleanup_path = (m[k] for k in
        ('parent_full_review', 'cleanup_overlap_supplement', 'cleanup_overlap_pipeline'))
    require(review['parent_review_sha256'] == sha(parent_path) and
            review['cleanup_supplement_sha256'] == sha(supplement_path), 'parent/cleanup review stale')
    parent, supplement, cleanup = load(parent_path), load(supplement_path), load(cleanup_path)
    require(parent['full_pipeline_sha256'] == sha(full_path) and
            supplement['original_full_review_sha256'] == sha(parent_path) and
            supplement['original_full_pipeline_sha256'] == sha(full_path) and
            supplement['replay_pipeline_sha256'] == sha(cleanup_path), 'cleanup review evidence binding differs')
    require(supplement['status'] == 'passed_independent_cleanup_overlap_heap_replay_supplement_not_adoption' and
            supplement['cleanup_overlap_followup_closed_for_heap_comparison'] is True,
            'cleanup overlap followup still open')
    require(cleanup['status'] == 'passed_single_heap_cleanup_overlap_replay_independent_review_pending' and
            cleanup['returncode'] == 0 and cleanup['fresh_assertions_passed'] is True and
            cleanup['full_pipeline_sha256'] == sha(full_path), 'cleanup replay not terminal/matching')
    require(cleanup['original_job'] == next(j for j in jobs if j['name'] == 'student_large_c8_heap_candidate_njit'),
            'cleanup replay substitutes another job')
    for name in (parent_path, supplement_path, cleanup_path):
        evidence[name] = sha(name)
    for key in ('output', 'launch'):
        require(sha(cleanup[key]) == cleanup[key + '_sha256'], 'cleanup raw/launch changed')
        evidence[cleanup[key]] = cleanup[key + '_sha256']
    log = str(Path(cleanup_path).parent / 'child.log')
    require(sha(log) == cleanup['log_sha256'], 'cleanup log changed')
    evidence[log] = cleanup['log_sha256']
    bound_evidence(review['evidence_sha256'], evidence)
    return evidence

def qualification_binding(mode, path, q, m):
    """Exactly r2 normal/Eigen and r3 compact/SAN; never an arbitrary runner/configuration."""
    spec = m['qualification_mode_plans'][mode]
    require(Path(path).resolve() == Path(spec['pipeline']).resolve(), 'unapproved mode pipeline path')
    require(q['runner_sha256'] == spec['runner_sha256'] and q['manifest_sha256'] == spec['manifest_sha256'],
            'mode runner/manifest identity differs')
    bound_evidence(spec['proof_sha256'])
    plan = load(spec['manifest'])
    require(plan['modes'][spec['config_key']] == spec['configuration'] and
            plan['case_sets'] == m['qualification_case_sets'] and
            plan['numerical_source_sha256'] == m['native_after']['cpp/compact_path.cpp'],
            'mode configuration/math/case contract differs')
    i = q['identity']
    require(i['source'] == m['native_after'] and i['compiler'] == spec['compiler'] and
            i['build_id'] == spec['build_id'], 'mode source/compiler/build identity differs')
    fresh_audit = runpy.run_path(spec['runner'])['audit_package'](i, mode)
    require(fresh_audit == q['package_audit'], 'mode package/configuration audit differs')
    private = hashlib.sha256(json.dumps(dict(identity=i, audit=fresh_audit), sort_keys=True).encode()).hexdigest()
    require(private == q['private_qualification_identity_sha256'], 'mode private identity differs')
    if mode == 'compact-packets-off':
        require(i['external_cmake_include_sha256'] == spec['configuration']['external_include_sha256'],
                'compact OFF configuration identity differs')
    if mode == 'asan-ubsan':
        require(q['sanitizer_leak_detection'] is False and i['sanitizer_runtime'] == spec['configuration']['runtime'],
                'sanitizer qualification contract differs')
        require(all('-fsanitize=address,undefined' in x['FLAGS'] and '-fno-omit-frame-pointer' in x['FLAGS']
                    for x in cpp_recipes(i['build'], D99 / 'source').values()), 'sanitizer native recipes differ')
    for receipt_path, expected_status in spec['terminal_receipts'].items():
        receipt = load(receipt_path)
        require(receipt['status'] == expected_status and receipt['pipeline_sha256'] == sha(path),
                'normal/Eigen terminal review stale or wrong scope')
        require(not receipt.get('confirmed_blockers', []), 'mode terminal review has blockers')
    return dict(pipeline=str(Path(path).resolve()), pipeline_sha256=sha(path),
                manifest_sha256=spec['manifest_sha256'], runner_sha256=spec['runner_sha256'],
                configuration_sha256=hashlib.sha256(json.dumps(spec['configuration'], sort_keys=True).encode()).hexdigest(),
                build_id=i['build_id'], private_identity_sha256=private,
                compact_source_sha256=m['native_after']['cpp/compact_path.cpp'], proof_sha256=spec['proof_sha256'])

def admission(decision_path):
    """Future root decision, four terminal modes and full-chain independent evidence."""
    m = manifest()
    d = load(decision_path)
    require(d['status'] == 'reviewed_v99_adoption_ready_for_actual_rebuild' and d['adopt_source'] is True,
            'root has not approved source adoption based on final evidence')
    require(d['plan_manifest_sha256'] == sha(HERE / 'manifest.json'), 'adoption decision plan differs')
    require(d['candidate_build_id'] == m['candidate_build_id'], 'adoption build differs')
    require(d['negative_results_retained'] is True and d['uncertainty_considered'] is True,
            'negative/uncertainty evidence missing')
    require(isinstance(d['rationale'], str) and d['rationale'].strip(), 'missing workload adoption rationale')
    refs = d['evidence_sha256']
    bound_evidence(refs)
    require(set(d['qualification_pipelines']) == set(MODES), 'four mode qualifications required')
    mode_evidence = {}
    mode_bindings = {}
    for mode, path in d['qualification_pipelines'].items():
        require(str(Path(path)) in refs, 'qualification is not bound by decision SHA')
        q = load(path)
        require(q['status'] == 'passed_qualification_independent_review_pending' and 'current' not in q,
                'qualification not terminal passed: ' + mode)
        require(q['mode'] == mode and q['identity']['source'] == m['native_after'], 'qualified mode/source differs')
        mode_bindings[mode] = qualification_binding(mode, path, q, m)
        mode_evidence.update(m['qualification_mode_plans'][mode]['proof_sha256'])
        jobs = {j['label']: j for j in q['jobs']}
        require(len(jobs) == len(q['jobs']) and {'collection', 'python', 'native'} <= set(jobs),
                'qualification duplicate/incomplete jobs')
        expected = {tuple(x) for x in m['expected_ids']['full' if mode == 'normal-full' else
                    'eigen_off_affected' if mode == 'eigen-off' else 'affected']}
        for job in q['jobs']:
            require(job['returncode'] == 0 and sha(job['log']) == job['log_sha256'], 'mode job/log failed')
            mode_evidence[job['log']] = job['log_sha256']
            for key in ('xml', 'collection'):
                if key in job:
                    require(sha(job[key]) == job[key + '_sha256'], 'mode XML/collection changed')
                    mode_evidence[job[key]] = job[key + '_sha256']
        require(xml_ids(jobs['python']['xml']) == expected, 'mode Python exact-ID mismatch')
        require(xml_ids(jobs['native']['xml']) == {tuple(x) for x in m['native_ids']}, 'mode native exact-ID mismatch')
        collection_nodes(jobs['collection']['log'], expected)
        require(jobs['collection']['exact_expected_ids'] if 'exact_expected_ids' in jobs['collection'] else
                load(jobs['collection']['collection'])['exact_expected_ids'], 'mode collection proof missing')
    # Review schemas evolve; require bound, explicit final reviews covering this exact evidence.
    require(d['all_mode_independent_review_passed'] is True and d['full_chain_independent_review_passed'] is True,
            'final independent review still incomplete')
    mode_review_path = d['all_mode_independent_review']
    full_review_path = d['full_chain_independent_review']
    require(str(Path(mode_review_path)) in refs and str(Path(full_review_path)) in refs,
            'independent reviews must be bound by evidence SHA')
    mode_review = load(mode_review_path)
    require(mode_review['status'] == 'passed_independent_v99_modes_review' and not mode_review['confirmed_blockers'],
            'all-mode independent review failed')
    require(mode_review['pipeline_sha256'] == {mode: sha(path) for mode, path in d['qualification_pipelines'].items()},
            'mode review is stale or incomplete')
    require(mode_review['mode_bindings'] == mode_bindings, 'final review mode runner/config/package bindings differ')
    bound_evidence(mode_review['evidence_sha256'], mode_evidence)
    require(str(Path(d['full_chain_pipeline'])) in refs, 'full chain not bound by decision SHA')
    full_review = load(full_review_path)
    require(full_review['status'] == 'passed_independent_v99_full_chain_review' and not full_review['confirmed_blockers'],
            'full-chain independent review failed')
    require(full_review['pipeline_sha256'] == sha(d['full_chain_pipeline']) and
            full_review['candidate_build_id'] == m['candidate_build_id'], 'full-chain review stale/wrong package')
    full_evidence = snapshot_full_chain(d['full_chain_pipeline'], full_review, m)
    bound_evidence(refs, {**mode_evidence, **full_evidence})
    return dict(decision=str(Path(decision_path).resolve()), decision_sha256=sha(decision_path),
                evidence_files=len(refs), snapshot_qualification_is_actual_adoption=False)

def package(identity_path):
    """Identity from an actual-R build; never compare package file SHA to snapshot binary SHA."""
    m = manifest()
    i = load(identity_path)
    require(i['source'] == m['native_after'] and i['build_id'] == m['candidate_build_id'], 'actual build/source differs')
    require(i['actual_source_root'] == str(R), 'identity did not come from actual R')
    require(sha(i['wheel']) == i['wheel_sha256'], 'actual wheel changed')
    install = Path(i['installed'])
    for name, expected in i['installed_binaries'].items():
        require(sha(install / name) == expected, 'actual native/worker changed')
    with zipfile.ZipFile(i['wheel']) as z:
        names = [n for n in z.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
        require(len(names) == len(set(names)) == 25, 'actual wheel inventory differs')
        for name in names:
            require((install / name).read_bytes() == z.read(name), 'actual install differs from whole wheel')
            if name.endswith('.py'):
                require((R / 'src' / name).read_bytes() == z.read(name), 'actual Python wrapper differs')
    native = [n for n in names if n.startswith('calmetrics_engine/_native.') and n.endswith('.so')]
    require(len(native) == 1, 'ambiguous native extension')
    require(sha(Path(i['build']) / Path(native[0]).name) == i['installed_binaries'][native[0]], 'native build/install differs')
    checker = runpy.run_path(m['macho_checker'])['macho_payload']
    worker_payload = checker(Path(i['build']) / 'calmetrics_worker')
    require(worker_payload == checker(install / 'calmetrics_engine/calmetrics_worker'),
            'worker UUID/mapped section content differs')
    require(worker_payload['uuid'] == i['worker_uuid'] and
            sha(Path(i['build']) / 'calmetrics_worker') == i['worker_build_sha256'], 'worker build proof differs')
    require('execute_process(COMMAND "/usr/bin/strip" -u -r ' in
            (Path(i['build']) / 'cmake_install.cmake').read_text(), 'worker strip transform differs')
    actual_recipes = cpp_recipes(i['build'], R)
    require(actual_recipes == m['candidate_cpp_recipes'], 'actual per-TU flags/defines/includes differ from qualified normal candidate')
    require(sha(Path(i['build']) / 'build.ninja') == i['ninja_sha256'], 'actual Ninja recipes changed')
    require(ids_digest(actual_recipes.items()) == i['normalized_cpp_recipes_sha256'], 'private compile recipe identity differs')
    return dict(status='passed_actual_package_identity', build_id=i['build_id'], payloads=25,
                wheel_sha256=i['wheel_sha256'], worker_build_sha256=i['worker_build_sha256'],
                worker_installed_sha256=i['installed_binaries']['calmetrics_engine/calmetrics_worker'])

def idle():
    text = subprocess.check_output(['/bin/ps', '-axo', 'pid=,ppid=,command='],
                                  env=dict(os.environ, LC_ALL='C'), encoding='utf-8', errors='replace')
    own = {os.getpid(), os.getppid()}
    tokens = (' -m pytest', '/ctest ', 'pip wheel', 'cmake --build', '/ninja', '/run_screen.py',
              '/driver_launcher.py', '/fair_owned_chain.py', '/fair_rss_modes.py', '/run_current.py',
              '/run_qualification.py', '/build_actual.py', '/qualify_actual.py', '/complete_actual.py',
              '/calmetrics_worker', 'benchmark_mc_', '/run_replay.py', '/run_full.py')
    busy = []
    for line in text.splitlines():
        fields = line.strip().split(None, 2)
        if len(fields) == 3 and int(fields[0]) not in own and any(t in fields[2] for t in tokens):
            busy.append(line)
    require(not busy, 'live heavy task; preserve its handle and do not overlap: ' + repr(busy))

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--phase', choices=('before', 'code', 'documents'), default='before')
    p.add_argument('--document-receipt')
    args = p.parse_args()
    print(json.dumps(verify(args.phase, args.document_receipt)))
