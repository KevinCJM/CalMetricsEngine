"""Prepared explicit actual-R AOT wheel build. Inactive unless --execute is supplied."""
from pathlib import Path
import argparse
import fcntl
import hashlib
import json
import os
import re
import runpy
import signal
import subprocess
import sys
import time
import zipfile
import guard

PYTHON = '/Users/chenjunming/Desktop/myenv_312/bin/python3.12'
DEPS = Path('/private/tmp/calmetrics-multiroot-matmul-v65-20261008/build-deps')

def build(attempt, decision):
    guard.require(re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}', attempt), 'unsafe/fixed attempt name')
    guard.require(sys.executable == PYTHON and sys.prefix == '/Users/chenjunming/Desktop/myenv_312', 'wrong venv')
    m = guard.manifest()
    admitted = guard.admission(decision)
    guard.verify('code')
    guard.idle()
    with (guard.HERE / '.heavy.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        out = guard.HERE / ('actual-' + attempt)
        out.mkdir(exist_ok=False)
        builddir, package = out / 'build', out / 'package'
        package.mkdir(exist_ok=False)
        env = dict(os.environ, PATH=str(DEPS / 'bin') + ':/opt/homebrew/bin:/usr/bin:/bin',
                   PYTHONPATH=str(DEPS), PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1',
                   PYTHONDONTWRITEBYTECODE='1', CMAKE_BUILD_PARALLEL_LEVEL='1', MACOSX_DEPLOYMENT_TARGET='15.0',
                   OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
                   NUMBA_NUM_THREADS='1', MKL_NUM_THREADS='1', LC_ALL='C')
        for key in ('PYTHONOPTIMIZE', 'DYLD_INSERT_LIBRARIES', 'PYTEST_ADDOPTS'):
            env.pop(key, None)
        for key in ('CMAKE_ARGS', 'SKBUILD_CMAKE_ARGS', 'CMAKE_PROJECT_INCLUDE', 'CMAKE_PROJECT_TOP_LEVEL_INCLUDES',
                    'CC', 'CXX', 'CFLAGS', 'CXXFLAGS', 'LDFLAGS', 'ARCHFLAGS'):
            env.pop(key, None)
        env['PIP_CONFIG_FILE'] = '/dev/null'
        guard.require(Path('/opt/homebrew/bin/cmake').is_file(), 'Homebrew cmake required')
        state = dict(status='running', pid=os.getpid(), started_epoch=time.time(), jobs=[], admission=admitted,
                     actual_source_root=str(guard.R), source_adopted=True, production_adopted=False, goal_complete=False)
        destination = out / 'pipeline.json'
        def save():
            state['heartbeat_epoch'] = time.time()
            temp = destination.with_suffix('.tmp.json')
            temp.write_text(json.dumps(state, indent=2) + '\n')
            temp.replace(destination)
        signal_control = dict(pending_signals=[])
        def interrupted(signum, _):
            # Queue only: never raise between child creation, registration or cleanup instructions.
            signal_control['pending_signals'].append(signum)
        def raise_pending():
            if signal_control['pending_signals']:
                signum = signal_control['pending_signals'].pop(0)
                raise KeyboardInterrupt('actual runner interrupted by signal ' + str(signum))
        signal.signal(signal.SIGTERM, interrupted)
        signal.signal(signal.SIGINT, interrupted)
        def job(label, cmd):
            guard.verify('code')
            guard.idle()
            log = out / (label + '.log')
            with log.open('x') as stream:
                child = None
                try:
                    raise_pending()
                    child = subprocess.Popen(cmd, cwd=guard.R, env=env, stdout=stream,
                                             stderr=subprocess.STDOUT, start_new_session=True)
                    state['current'] = dict(label=label, pid=child.pid, command=cmd, started_epoch=time.time(), log=str(log))
                    raise_pending()
                    save()
                    raise_pending()
                    print('START', label, child.pid, flush=True)
                    raise_pending()
                    heartbeat = time.monotonic()
                    while child.poll() is None:
                        raise_pending()
                        try:
                            child.wait(timeout=0.25)
                        except subprocess.TimeoutExpired:
                            pass
                        raise_pending()
                        if time.monotonic() - heartbeat >= 2:
                            save()
                            heartbeat = time.monotonic()
                        raise_pending()
                    raise_pending()
                    child.wait()
                    raise_pending()
                except BaseException:
                    if child is None:
                        state['interrupted_child'] = dict(created=False, pid=None, returncode=None)
                    else:
                        if child.poll() is None:
                            try:
                                os.killpg(child.pid, signal.SIGTERM)
                            except ProcessLookupError:
                                pass
                            try:
                                child.wait(timeout=5)
                            except subprocess.TimeoutExpired:
                                try:
                                    os.killpg(child.pid, signal.SIGKILL)
                                except ProcessLookupError:
                                    pass
                                child.wait()
                        else:
                            child.wait()
                        state['interrupted_child'] = dict(created=True, pid=child.pid, returncode=child.returncode)
                    if signal_control['pending_signals']:
                        state['cleanup_deferred_signals'] = list(signal_control['pending_signals'])
                    raise
            state['jobs'].append(dict(label=label, returncode=child.returncode, log=str(log),
                                      log_sha256=guard.sha(log), command=cmd, finished_epoch=time.time()))
            state.pop('current', None)
            save()
            guard.require(child.returncode == 0, 'child failed: ' + label)
            guard.verify('code')
            return log
        save()
        try:
            raise_pending()
            cmd = [PYTHON, '-m', 'pip', 'wheel', '.', '--no-deps', '--no-build-isolation',
                   '-Cbuild-dir=' + str(builddir), '-Ccmake.define.CALMETRICS_ENGINE_BUILD_PYTHON=ON',
                   '-Ccmake.define.CALMETRICS_ENGINE_BUILD_TESTS=ON', '-Ccmake.define.CALMETRICS_ENGINE_USE_EIGEN=ON',
                   '-Ccmake.define.CALMETRICS_ENGINE_USE_ACCELERATE=ON', '-Ccmake.define.CALMETRICS_ENGINE_USE_HIGHWAY=ON',
                   '-Ccmake.define.CALMETRICS_ENGINE_SANITIZE=OFF', '-w', str(package / 'wheels')]
            job('build', cmd)
            wheels = list((package / 'wheels').glob('*.whl'))
            guard.require(len(wheels) == 1, 'wheel count differs')
            install = package / 'install'
            job('install', [PYTHON, '-m', 'pip', 'install', '--no-deps', '--target', str(install), str(wheels[0])])
            env['PYTHONPATH'] = str(install)
            report = json.loads(job('runtime-identity', [PYTHON, '-B', str(guard.HERE / 'runtime_probe.py'),
                                                   str(install)]).read_text().splitlines()[-1])
            compiler = m['candidate_compiler']
            expected = hashlib.sha256((';'.join(compiler) + ''.join(';' + n + ':' + h
                                       for n, h in m['native_after'].items())).encode()).hexdigest()
            guard.require(report['engine_build_id'] == expected == m['candidate_build_id'], 'source/runtime build ID differs')
            with zipfile.ZipFile(wheels[0]) as z:
                natives = [n for n in z.namelist() if n.startswith('calmetrics_engine/_native.') and n.endswith('.so')]
            guard.require(len(natives) == 1, 'ambiguous native extension')
            checker = runpy.run_path(m['macho_checker'])['macho_payload']
            built_worker, installed_worker = builddir / 'calmetrics_worker', install / 'calmetrics_engine/calmetrics_worker'
            payload = checker(built_worker)
            guard.require(payload == checker(installed_worker), 'worker build/installed UUID/mapped sections differ')
            guard.require('execute_process(COMMAND "/usr/bin/strip" -u -r ' in
                          (builddir / 'cmake_install.cmake').read_text(), 'worker strip transform changed')
            ninja = (builddir / 'build.ninja').read_text()
            guard.require('-fno-fast-math' in ninja and '-ffp-contract=off' in ninja and '-DEIGEN_DONT_VECTORIZE' not in ninja,
                          'normal precise/packet compile configuration differs')
            recipes = guard.cpp_recipes(builddir, guard.R)
            guard.require(recipes == m['candidate_cpp_recipes'], 'actual native TU recipe differs from qualified snapshot')
            identity = dict(build_id=expected, source=m['native_after'], compiler=compiler, build=str(builddir),
                            installed=str(install), wheel=str(wheels[0]), wheel_sha256=guard.sha(wheels[0]), build_info=report,
                            installed_binaries={n: guard.sha(install / n) for n in (natives[0], 'calmetrics_engine/calmetrics_worker')},
                            actual_source_root=str(guard.R), actual_plan_manifest_sha256=guard.sha(guard.HERE / 'manifest.json'),
                            worker_build_sha256=guard.sha(built_worker), worker_uuid=payload['uuid'],
                            worker_mapped_sections_equal=True, worker_strip_transform='strip -u -r',
                            ninja_sha256=guard.sha(builddir / 'build.ninja'),
                            normalized_cpp_recipes_sha256=guard.ids_digest(recipes.items()))
            identity_path = package / 'identity.json'
            identity_path.write_text(json.dumps(identity, indent=2) + '\n')
            final_result = dict(status='passed_actual_build_identity_only', identity=str(identity_path),
                                identity_sha256=guard.sha(identity_path), package_audit=guard.package(identity_path),
                                finished_epoch=time.time())
            # Terminal commit boundary: finish every blocking audit before consuming pending cancellation.
            raise_pending()
            state.update(**final_result)
        except BaseException as error:
            state.update(status='failed', error=repr(error), finished_epoch=time.time())
            raise
        finally:
            save()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--execute', action='store_true')
    p.add_argument('--attempt')
    p.add_argument('--adoption-decision')
    args = p.parse_args()
    if args.execute:
        guard.require(args.attempt and args.adoption_decision, 'explicit attempt and final adoption decision required')
        build(args.attempt, args.adoption_decision)
    else:
        print(json.dumps(dict(status='prepared_not_executed', actual_source_root=str(guard.R),
                              cmake='/opt/homebrew/bin/cmake', cpu_budget=1, global_install=False,
                              required_phase='code', root_decision_and_all_four_modes_required=True)))
