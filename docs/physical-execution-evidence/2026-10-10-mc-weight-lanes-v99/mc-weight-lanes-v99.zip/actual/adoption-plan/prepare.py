"""One-time static preparation. Standard-library reads; writes only this fresh tmp directory."""
from pathlib import Path
import ast
import hashlib
import json
import runpy
import time
import guard

HERE, R, F, D99 = guard.HERE, guard.R, guard.F, guard.D99
A93 = Path('/private/tmp/calmetrics-f-density-eigen-v93-20261010/adoption')
D98 = Path('/private/tmp/calmetrics-mc-owned-current-v98-20261010')
QUAL = D99 / 'qualification-plan-next-r2'
PERF = D99 / 'candidate-performance-plan-r3'
guard.require(not (HERE / 'manifest.json').exists(), 'preparation is immutable; create a new directory for revisions')
old_guard = runpy.run_path(str(A93 / 'actual_guards.py'))['guard']()
before = guard.native_sources(R)
identity = guard.load(D99 / 'package-candidate-r3/identity.json')
recipes = guard.cpp_recipes(identity['build'], D99 / 'source')
after = guard.native_sources(D99 / 'source')
guard.require(after == identity['source'] and len(before) == len(after) == 93, 'candidate complete source differs')
changed = [n for n in before if before[n] != after[n]]
guard.require(changed == ['cpp/compact_path.cpp'], 'unexpected source adoption scope')
old_tests = guard.tests(R)
new_tests = guard.tests(D99 / 'source')
new_path = 'tests/test_compact_weight_lanes.py'
guard.require(len(old_tests) == 203 and len(new_tests) == 204 and not (R / new_path).exists(), 'new test creation condition differs')
guard.require({n: h for n, h in new_tests.items() if n != new_path} == old_tests, 'candidate replaced an old test')
changes = [dict(path='cpp/compact_path.cpp', existing=True, old_sha256=before['cpp/compact_path.cpp'],
                new_sha256=after['cpp/compact_path.cpp']),
           dict(path=new_path, existing=False, old_sha256=None, new_sha256=new_tests[new_path])]
for name, prefix in [('cpp/compact_path.cpp', 'c7115c1a'), (new_path, 'a9030028')]:
    guard.require(guard.sha(D99 / 'source' / name).startswith(prefix), 'pinned candidate SHA differs')
normal_status, all_status = guard.status(R), guard.status(R, True)
dirty_paths = sorted(x[3:].decode() for x in guard.records(all_status))
tracked = guard.git(R, 'ls-files', '-z').split(b'\0')
names = {x.decode() for x in tracked if x} | set(dirty_paths)
project = {}
for name in sorted(names):
    path = R / name
    if path.is_file():
        project[name] = guard.sha(path)
    elif path.exists():
        raise RuntimeError('unexpected tracked/dirty nonfile: ' + name)
baseline = guard.load(A93 / 'plan.json')
cases = runpy.run_path(str(QUAL / 'run_qualification.py'))['expected_cases']()
qplan = guard.load(QUAL / 'manifest.json')
guard.require(all(len(cases[n]) == qplan['case_sets'][n]['count'] for n in cases), 'exact qualification ID sets changed')
qualification_modes = {}
mode_roots = {'normal-full': QUAL, 'eigen-off': QUAL,
              'compact-packets-off': D99 / 'qualification-plan-next-r3', 'asan-ubsan': D99 / 'qualification-plan-next-r5'}
q3_review = Path('/private/tmp/calmetrics-v99-qualification-r3-independent-review-r2-20261010/reviewed.json')
guard.require(guard.sha(q3_review) == '12a7dfa4a16a3ded9359c3cb4428ba2dc77c90a1bbf61931085af049d8675571',
              'qualification r3 independent receipt differs')
q5_review = Path('/private/tmp/calmetrics-v99-qualification-r5-independent-review-20261010/reviewed.json')
guard.require(guard.sha(q5_review) == '13e81fc4ebfb432f80fb67e058ab54e9f3783e23937cdb706eb1fe7ee3f9499b',
              'qualification r5 independent receipt differs')
mode_control_reviews = {
    'qualification-plan-next-r3': dict(path=q3_review, status='passed_independent_v99_qualification_r3_control_review',
        math_key='original_numerical_build_and_case_selection_text_unchanged',
        manifest_sha256='b99e35df061f2afd886b644ce73e9d569316f594a021852ed492f48ad570ce66',
        runner_sha256='16ec2c92522db7c755d0d7583eb4244a479d007e10baaa32248f7c098a1e3237'),
    'qualification-plan-next-r5': dict(path=q5_review, status='passed_independent_v99_qualification_r5_control_review',
        math_key='math_build_and_case_selection_text_unchanged',
        manifest_sha256='d20b0a824bd45c9d868d48e0f79d89052e7fbe71e78f31193bad531645c97193',
        runner_sha256='e60b83c90899369ac389794e2c192d7124557d41a7eec2e153de704178b8da11')}
compact_terminal_pins = {
    str(D99 / 'qualification-plan-next-r3/execution-compact-packets-off/pipeline.json'):
        'ef5312bbf15e2a8be5c1db2e01bee057646aaababbe9a6180abb844c8ca3a8c1',
    str(D99 / 'qualification-compact-off-root-reviewed-r1.json'):
        '411cbc4deafad44e849675d256670e98629ca9e68e45b362a5827a0334949696',
    '/private/tmp/calmetrics-v99-compact-off-independent-review-20261010/reviewed.json':
        '367b62ac095ea3183a648236ed7799325b620a6d4f2e990c38d017d94277ed1c'}
guard.bound_evidence(compact_terminal_pins)
terminal_receipts = {
    'normal-full': [D99 / 'qualification-normal-full-root-reviewed-r1.json',
                    Path('/private/tmp/calmetrics-v99-normal-full-independent-review-r3-20261010/reviewed.json')],
    'eigen-off': [D99 / 'qualification-eigen-off-root-reviewed-r1.json',
                  Path('/private/tmp/calmetrics-v99-eigen-off-independent-review-20261010/reviewed.json')],
    'compact-packets-off': [D99 / 'qualification-compact-off-root-reviewed-r1.json',
                  Path('/private/tmp/calmetrics-v99-compact-off-independent-review-20261010/reviewed.json')], 'asan-ubsan': []}
for mode, root in mode_roots.items():
    selected_plan = guard.load(root / 'manifest.json')
    key = mode.replace('-', '_')
    guard.require(selected_plan['case_sets'] == qplan['case_sets'] and
                  selected_plan['numerical_source_sha256'] == after['cpp/compact_path.cpp'], 'mode math/cases changed')
    compiler = list(identity['compiler'])
    compiler[5] = '-fsanitize=address,undefined -fno-omit-frame-pointer' if mode == 'asan-ubsan' else ''
    compiler[7] = 'eigen_rotation=OFF' if mode == 'eigen-off' else 'eigen_rotation=ON'
    build_id = hashlib.sha256((';'.join(compiler) + ''.join(';' + n + ':' + h for n, h in after.items())).encode()).hexdigest()
    proof_paths = [root / n for n in ('manifest.json', 'run_qualification.py', 'runtime_probe.py',
                   'asan_python_bootstrap.py', 'compact_packets_off.cmake')]
    receipts = {}
    for path in terminal_receipts[mode]:
        receipt = guard.load(path)
        guard.require(receipt['status'].startswith('passed_') and receipt['pipeline_sha256'] ==
                      guard.sha(root / ('execution-' + mode) / 'pipeline.json'), 'terminal mode receipt stale')
        receipts[str(path)] = receipt['status']
        proof_paths += [path]
    if receipts:
        proof_paths += [root / ('execution-' + mode) / 'pipeline.json']
    if root.name in mode_control_reviews:
        control = mode_control_reviews[root.name]
        reviewed = guard.load(control['path'])
        guard.require(guard.sha(root / 'manifest.json') == control['manifest_sha256'] and
                      guard.sha(root / 'run_qualification.py') == control['runner_sha256'] and
                      reviewed['status'] == control['status'] and
                      reviewed['manifest_sha256'] == control['manifest_sha256'] and
                      reviewed['runner_sha256'] == control['runner_sha256'] and
                      reviewed[control['math_key']] is True and not reviewed['confirmed_blockers'],
                      'limited mode lifecycle/control proof differs')
        proof_paths += [control['path']]
    qualification_modes[mode] = dict(pipeline=str(root / ('execution-' + mode) / 'pipeline.json'),
        manifest=str(root / 'manifest.json'), runner=str(root / 'run_qualification.py'),
        manifest_sha256=guard.sha(root / 'manifest.json'), runner_sha256=guard.sha(root / 'run_qualification.py'),
        config_key=key, configuration=selected_plan['modes'][key], compiler=compiler, build_id=build_id,
        terminal_receipts=receipts, proof_sha256={str(p): guard.sha(p) for p in proof_paths})
perf = guard.load(PERF / 'manifest.json')
old_identity_path = A93 / 'actual-package/identity.json'
old_identity = guard.load(old_identity_path)
old_source = A93.parent / 'r5/source'
guard.require(guard.native_sources(old_source) == old_identity['source'] == before, 'old control source/pkg mismatch')
support_root = D99 / 'candidate-performance-plan-r3/support-snapshot'
support = {p.name: dict(path=str(p), sha256=guard.sha(p)) for p in sorted(support_root.glob('*.py'))}
guard.require(len(support) == 10, 'byte-identical support snapshot inventory changed')
frozen_paths = [A93 / 'actual_guards.py', A93 / 'plan.json', A93 / 'documents-applied.json', old_identity_path,
                D99 / 'manifest.json', D99 / 'candidate.patch', D99 / 'DESIGN.md', D99 / 'preflight.py',
                D99 / 'package-candidate-r3/identity.json', D99 / 'independent-qualification-review/review.py',
                D99 / 'independent-qualification-review/reviewed.json', QUAL / 'manifest.json', QUAL / 'run_qualification.py',
                PERF / 'manifest.json', PERF / 'guard.py', PERF / 'report_tools.py', PERF / 'run_screen.py',
                PERF / 'driver_launcher.py',
                D99 / 'qualification-plan-next-independent-review-r2/control_review.py',
                D99 / 'qualification-plan-next-independent-review-r2/reviewed.json',
                HERE.parent / 'r3-r2/manifest.json', HERE.parent / 'r3-r2/manifest.sha256',
                HERE.parent / 'r3-r2/lifecycle-fake-evidence.json', HERE.parent / 'r3-r2/admission-fake-evidence.json',
                HERE.parent / 'r3-r2/self-review.json', HERE.parent / 'r3-r2/r3.diff',
                Path('/private/tmp/calmetrics-v99-adoption-r3-r2-independent-review-20261010/reviewed.json'),
                Path('/private/tmp/calmetrics-v99-adoption-r3-r2-independent-review-20261010/cleanup-second-signal-reproduction.json'),
                Path(identity['build']) / 'build.ninja', Path(identity['build']) / 'cmake_install.cmake',
                Path(perf['probe']), Path(identity['wheel']), Path(old_identity['wheel']),
                *(D99 / 'source' / n for n in after), D99 / 'source' / new_path,
                *(old_source / n for n in before), old_source / 'tests/test_mc_compact_graph.py',
                *(Path(entry['path']) for entry in support.values()),
                *(p for p in D98.rglob('*') if p.is_file() and '__pycache__' not in p.parts),
                *(Path(identity['installed']) / n for n in identity['installed_binaries']),
                *(Path(old_identity['installed']) / n for n in old_identity['installed_binaries'])]
frozen = {str(p): guard.sha(p) for p in frozen_paths}
for spec in qualification_modes.values():
    frozen.update(spec['proof_sha256'])
for name in ('manifest.json', 'manifest.sha256', 'lifecycle-fake-evidence.json', 'admission-fake-evidence.json',
             'self-review.json', 'r4.diff'):
    path = HERE.parent / 'r4' / name
    frozen[str(path)] = guard.sha(path)
r4_review = Path('/private/tmp/calmetrics-v99-adoption-r4-cleanup-independent-review-20261010/reviewed.json')
guard.require(guard.sha(r4_review) == 'a8e853877aa0371507a41f23c7702ed37e5a05edbf5e1253115dc5bbf10e476b',
              'r4 cleanup independent receipt differs')
frozen[str(r4_review)] = guard.sha(r4_review)
for name in ('manifest.json', 'manifest.sha256', 'lifecycle-fake-evidence.json', 'admission-fake-evidence.json',
             'mode-binding-fake-evidence.json', 'self-review.json', 'r5.diff'):
    path = HERE.parent / 'r5' / name
    frozen[str(path)] = guard.sha(path)
for name in guard.load(HERE.parent / 'r5/manifest.json')['helper_sha256']:
    path = HERE.parent / 'r5' / name
    frozen[str(path)] = guard.sha(path)
r5_rejection = Path('/private/tmp/calmetrics-v99-adoption-r5-independent-review-20261010/reviewed.json')
r5_trace = r5_rejection.parent / 'except-entry-trace-reproduction.json'
guard.require(guard.sha(r5_rejection) == '911453b23be32d9b06ccde623b00e2221e606261403193c0b8ba744858627ee1' and
              guard.sha(r5_trace) == '2d3fc3f64020bffb154679ce992d62059cdab65d830d1b9de5368bee3963dd09',
              'r5 rejected lifecycle history differs')
q4_rejection = Path('/private/tmp/calmetrics-v99-qualification-r4-independent-review-20261010/reviewed.json')
guard.require(guard.sha(q4_rejection) == '3ac66748d9fe7709a3ebbb3bd154f15c9e6ecfcf8432b0a1e31cd18031b3d1aa',
              'qualification r4 rejection differs')
for path in (r5_rejection, r5_trace, q4_rejection, D99 / 'qualification-plan-next-r4/manifest.json',
             D99 / 'qualification-plan-next-r4/run_qualification.py'):
    frozen[str(path)] = guard.sha(path)
r6_root = HERE.parent / 'r6'
for name in ('manifest.json', 'manifest.sha256', 'self-review.json', 'r6.diff',
             'lifecycle-fake-evidence-r3.json', 'lifecycle-trace-fake-evidence-r4.json',
             'admission-fake-evidence.json', 'mode-binding-fake-evidence-r2.json'):
    path = r6_root / name
    frozen[str(path)] = guard.sha(path)
for name in guard.load(r6_root / 'manifest.json')['helper_sha256']:
    path = r6_root / name
    frozen[str(path)] = guard.sha(path)
r6_rejection = Path('/private/tmp/calmetrics-v99-adoption-r6-independent-review-20261010/reviewed.json')
guard.require(guard.sha(r6_rejection) == '23c145ea82290547b4dc3a6cebb9fc5bfafb76be7508e3b2bbf62b5e5f0ee88b',
              'r6 independent final-audit rejection differs')
r6_reproduction = r6_rejection.parent / 'build-final-audit-cancel-reproduction.json'
reviewed = guard.load(r6_rejection)
guard.require(len(reviewed['confirmed_blockers']) == 1 and
              reviewed['confirmed_blockers'][0]['id'] == 'P2_final_actual_build_package_audit_after_pending_checkpoint' and
              guard.sha(r6_reproduction) == reviewed['evidence_sha256'][str(r6_reproduction)],
              'r6 final-audit counterexample binding differs')
for path in (r6_rejection, r6_reproduction):
    frozen[str(path)] = guard.sha(path)
native_names = ['calmetrics_engine_excel_tests', 'calmetrics_engine_native_tests', 'calmetrics_engine_operator_tests',
                'calmetrics_engine_graph_tests', 'calmetrics_engine_compiler_tests', 'calmetrics_engine_runtime_tests',
                'calmetrics_engine_math_tests', 'calmetrics_engine_stateful_tests', 'calmetrics_engine_result_tests']
new_arch = 'docs/physical-execution-evidence/2026-10-10-mc-weight-lanes-v99'
docs = ['docs/mc-projection-primitives.md', 'docs/execution-guide.md', 'docs/physical-execution-optimization.md',
        'docs/README.md', new_arch + '/README.md', new_arch + '/mc-weight-lanes-v99.zip']
guard.require(all(not (R / n).exists() for n in docs[-2:]), 'future archive path already owned by another task')
helpers = {p.name: guard.sha(p) for p in sorted(HERE.iterdir()) if p.suffix in ('.py', '.md', '.json')}
for p in HERE.glob('*.py'):
    ast.parse(p.read_text(), filename=str(p))
manifest = dict(schema='v99-actual-adoption-preparation-7', status='prepared_not_executed', prepared_epoch=time.time(),
                project=str(R), platform=str(F), python='/Users/chenjunming/Desktop/myenv_312/bin/python3.12',
                head=guard.git(R, 'rev-parse', 'HEAD').decode().strip(), branch=guard.git(R, 'branch', '--show-current').decode().strip(),
                index_diff_sha256=hashlib.sha256(guard.git(R, 'diff', '--cached', '--binary')).hexdigest(),
                repository_status_normal_hex=normal_status.hex(), repository_status_all_hex=all_status.hex(),
                dirty_paths=dirty_paths, project_sha256=project, native_before=before, native_after=after,
                tests_before=old_tests, tests_after=new_tests, adoption_changes=changes,
                platform_status_hex=guard.status(F).hex(), platform_sha256=baseline['platform_readonly_sha256'],
                old_actual_identity=str(old_identity_path), old_source=str(old_source),
                candidate_build_id=identity['build_id'], candidate_compiler=identity['compiler'],
                candidate_cpp_recipes=recipes,
                qualification_mode_plans=qualification_modes, qualification_case_sets=qplan['case_sets'],
                candidate_full_manifest=str(PERF / 'manifest.json'), candidate_full_jobs=perf['jobs']['full'],
                candidate_full_packages=perf['packages'],
                parent_full_review=str(D99 / 'independent-full-review-r1/reviewed.json'),
                cleanup_overlap_supplement=str(D99 / 'independent-full-review-r1/cleanup-heap-replay-reviewed.json'),
                cleanup_overlap_pipeline=str(D99 / 'cleanup-overlap-replay-r1/pipeline.json'),
                expected_ids={name: sorted(value) for name, value in cases.items()},
                native_ids=[(n, n) for n in native_names], related_modules=['tests/' + n + '.py' for n in
                    runpy.run_path(str(QUAL / 'run_qualification.py'))['RELATED']],
                macho_checker=str(D99 / 'independent-qualification-review/review.py'),
                original_support=perf['original_support'], replay_support=support, replay_drivers=perf['drivers'],
                probe=perf['probe'], probe_sha256=guard.sha(perf['probe']), thread_environment=perf['thread_environment'],
                replay_exclusions=['covariance_root_generation', 'coverage', 'limits', 'JSON_packaging', 'platform_stage_ordered_first_fault'],
                document_allowlist=docs, frozen_sha256=frozen, helper_sha256=helpers,
                legacy_actual79_guard_used_before_adoption_only=True, snapshot_is_actual_adoption=False,
                numerical_execution=False, build_execution=False, pytest_collection=False, source_adopted=False, goal_complete=False)
destination = HERE / 'manifest.json'
destination.write_text(json.dumps(manifest, indent=2) + '\n')
(HERE / 'manifest.sha256').write_text(guard.sha(destination) + '\n')
receipt = dict(status='prepared_static_only_not_executed', manifest_sha256=guard.sha(destination),
               native_before=len(before), native_after=len(after), tests_before=len(old_tests), tests_after=len(new_tests),
               all_dirty_files=len(dirty_paths), protected_project_files=len(project), frozen_files=len(frozen),
               candidate_changed_source_files=len(changed), new_python_test_sources=1,
               helper_python_ast_files=len(list(HERE.glob('*.py'))), old_actual_guard=old_guard,
               numerical_import=False, compilation=False, install=False, pytest_collection=False,
               project_writes=False, created_epoch=time.time(), guard=guard.verify('before'))
(HERE / 'static-preparation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
