"""Create a future actual-package full-chain queue without executing any job."""
from pathlib import Path
import argparse
import hashlib
import json
import guard

def prepare(identity_path, qualification_path, output):
    m = guard.manifest()
    guard.verify('code')
    guard.package(identity_path)
    i = guard.load(identity_path)
    q = guard.load(qualification_path)
    guard.require(q['status'] == 'passed_actual_qualification_independent_review_pending' and q['scope'] == 'full' and
                  'current' not in q and len(q['jobs']) == 3 and
                  {j['label'] for j in q['jobs']} == {'collection', 'native', 'python'},
                  'actual full qualification not passed')
    guard.require(q['identity_sha256'] == guard.sha(identity_path) and q['unique_python_tests'] == 17179,
                  'actual full qualification belongs to another package')
    for job in q['jobs']:
        guard.require(job['returncode'] == 0 and guard.sha(job['log']) == job['log_sha256'], 'actual qualification log differs')
        if 'xml' in job:
            guard.require(guard.sha(job['xml']) == job['xml_sha256'], 'actual qualification XML differs')
    python_job = next(x for x in q['jobs'] if x['label'] == 'python')
    guard.require(guard.xml_ids(python_job['xml']) == {tuple(x) for x in m['expected_ids']['full']}, 'actual full IDs differ')
    native_job = next(x for x in q['jobs'] if x['label'] == 'native')
    guard.require(guard.xml_ids(native_job['xml']) == {tuple(x) for x in m['native_ids']}, 'actual native IDs differ')
    collection_job = next(x for x in q['jobs'] if x['label'] == 'collection')
    guard.collection_nodes(collection_job['log'], {tuple(x) for x in m['expected_ids']['full']})
    output = Path(output).resolve()
    guard.require(output.is_relative_to(guard.HERE), 'replay output must remain under preparation tmp directory')
    output.mkdir(exist_ok=False)
    support = output / 'support-snapshot'
    support.mkdir(exist_ok=False)
    for name, entry in m['replay_support'].items():
        blob = Path(entry['path']).read_bytes()
        guard.require(hashlib.sha256(blob).hexdigest() == entry['sha256'], 'frozen replay support differs')
        (support / name).write_bytes(blob)
    old = guard.load(m['old_actual_identity'])
    packages = dict(actual79=dict(source=m['old_source'], identity=m['old_actual_identity'], install=old['installed'],
                                 build_id=old['build_id'], identity_sha256=guard.sha(m['old_actual_identity'])),
                    actual99=dict(source=str(guard.R), identity=str(Path(identity_path).resolve()), install=i['installed'],
                                  build_id=i['build_id'], identity_sha256=guard.sha(identity_path)))
    manifest_path = output / 'manifest.json'
    plan = dict(status='prepared_actual_replay_not_executed', actual_adoption_manifest_sha256=guard.sha(guard.HERE / 'manifest.json'),
                actual_qualification=str(Path(qualification_path).resolve()), actual_qualification_sha256=guard.sha(qualification_path),
                packages=packages, drivers=m['replay_drivers'], original_support=m['original_support'],
                support_snapshot=str(support), probe=m['probe'], probe_sha256=m['probe_sha256'],
                thread_environment=m['thread_environment'], jobs=[], source_adopted=True, goal_complete=False,
                measured_scope='owned fixed-production-NJIT input preparation, transform, projection, NAV, fan, all stats/samples/contributions',
                excluded=m['replay_exclusions'], original_driver_changes=False, benchmark_only_source_proof_inside_child=False)
    for student in (False, True):
        for case in ('large_c1', 'large_c8', 'short_many'):
            prefix = ('student_' if student else 'normal_') + case
            jobs = [('time_actual79_before', 'actual79', 'time', None), ('time_actual99', 'actual99', 'time', None),
                    ('time_actual79_after', 'actual79', 'time', None), ('heap_actual99', 'actual99', 'heap', 'cpp'),
                    ('heap_njit', 'actual99', 'heap', 'njit'), ('rss_actual99', 'actual99', 'rss', 'cpp'),
                    ('rss_njit', 'actual99', 'rss', 'njit')]
            for suffix, package, metric, backend in jobs:
                label = prefix + '_' + suffix
                data = output / (label + '.json')
                launch = output / (label + '.launch.json')
                rest = ['--case', case, '--output', str(data)]
                if student:
                    rest += ['--student']
                if metric == 'time':
                    rest += ['--rounds', '3']
                elif metric == 'heap':
                    rest += ['--heap', '--backend', backend]
                else:
                    rest += ['--backend', backend]
                command = [m['python'], '-B', str(guard.HERE / 'replay_launcher.py'), '--manifest', str(manifest_path),
                           '--package', package, '--metric', metric, '--launch-evidence', str(launch), '--', *rest]
                plan['jobs'].append(dict(label=label, package=package, metric=metric, command=command,
                                         output=str(data), launch=str(launch), log=str(output / (label + '.log'))))
    light = [guard.HERE / 'replay_launcher.py', *(support / n for n in m['replay_support'])]
    plan['lightweight_files_sha256'] = {str(p): guard.sha(p) for p in light}
    manifest_path.write_text(json.dumps(plan, indent=2) + '\n')
    (output / 'manifest.sha256').write_text(guard.sha(manifest_path) + '\n')
    print(json.dumps(dict(status=plan['status'], manifest=str(manifest_path), jobs=len(plan['jobs']),
                         actual_build_id=i['build_id'], original_drivers_unmodified=True, numerical_execution=False)))

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--identity')
    p.add_argument('--full-qualification')
    p.add_argument('--output')
    args = p.parse_args()
    if all([args.identity, args.full_qualification, args.output]):
        prepare(args.identity, args.full_qualification, args.output)
    else:
        guard.require(not any([args.identity, args.full_qualification, args.output]), 'all three preparation args required')
        print(json.dumps(dict(status='prepared_not_executed', future_queue_jobs=42,
                              input_prep_inside_owned_timer=True, ordinary_scheduler=True, retained_result_generations=2,
                              original_numerical_driver_changes=False, heavy_proof_in_parent_only=True)))
