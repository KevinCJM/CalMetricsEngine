"""Stdlib AST + fake child tests only; never launch a process or deliver real signals."""
from pathlib import Path
import ast
import hashlib
import json
import signal
import subprocess
import sys
import tempfile
import types

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'r5'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sys.flags.optimize == 0 and sys.dont_write_bytecode
results, sources = [], {}


def extract(name):
    old_text, text = (OLD / name).read_text(), (HERE / name).read_text()
    old_tree, tree = ast.parse(old_text), ast.parse(text)
    def handler_in(t):
        return next(n for n in ast.walk(t) if isinstance(n, ast.FunctionDef) and n.name == 'interrupted')
    def log_with(t, source):
        return next(n for n in ast.walk(t) if isinstance(n, ast.With) and
                    ast.get_source_segment(source, n).startswith("with log.open('x')"))
    old_handler, handler = handler_in(old_tree), handler_in(tree)
    checkpoint = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'raise_pending')
    old_with, child_with = log_with(old_tree, old_text), log_with(tree, text)
    control = next(n for n in ast.walk(tree) if isinstance(n, ast.Assign) and
                   any(isinstance(t, ast.Name) and t.id == 'signal_control' for t in n.targets))
    old_control = next(n for n in ast.walk(old_tree) if isinstance(n, ast.Assign) and
                       any(isinstance(t, ast.Name) and t.id == 'signal_control' for t in n.targets))
    lines, old_lines = text.splitlines(keepends=True), old_text.splitlines(keepends=True)
    restored = list(lines)
    for start, end, replacement in sorted([
        (control.lineno - 1, checkpoint.end_lineno, old_lines[old_control.lineno - 1:old_handler.end_lineno]),
        (child_with.lineno - 1, child_with.end_lineno, old_lines[old_with.lineno - 1:old_with.end_lineno])
    ], reverse=True):
        restored[start:end] = replacement
    if name == 'build_actual.py':
        final = next(n for n in ast.walk(tree) if isinstance(n, ast.Assign) and
                     any(isinstance(x, ast.Name) and x.id == 'final_result' for x in n.targets))
        update = next(n for n in ast.walk(tree) if isinstance(n, ast.Expr) and
                      ast.unparse(n) == 'state.update(**final_result)')
        old_update = next(n for n in ast.walk(old_tree) if isinstance(n, ast.Expr) and
                          'passed_actual_build_identity_only' in ast.get_source_segment(old_text, n))
        # Restore only this precisely bounded final-audit change; all other source still compares byte-for-byte.
        joined = ''.join(restored)
        jtree = ast.parse(joined)
        jfinal = next(n for n in ast.walk(jtree) if isinstance(n, ast.Assign) and
                      any(isinstance(x, ast.Name) and x.id == 'final_result' for x in n.targets))
        jupdate = next(n for n in ast.walk(jtree) if isinstance(n, ast.Expr) and
                       ast.unparse(n) == 'state.update(**final_result)')
        jlines = joined.splitlines(keepends=True)
        jlines[jfinal.lineno-1:jupdate.end_lineno] = old_lines[old_update.lineno-1:old_update.end_lineno]
        restored = jlines
    assert ''.join(line for line in restored if line.strip() != 'raise_pending()') == old_text, name + ': change beyond signal handler/lifecycle'
    assert 'pthread_sigmask' not in text and 'preexec_fn' not in text
    cleanup = next(n for n in ast.walk(child_with) if isinstance(n, ast.Try) and
                   any(isinstance(h.type, ast.Name) and h.type.id == 'BaseException' for h in n.handlers))
    protected = ast.get_source_segment(text, cleanup)
    for needed in ('subprocess.Popen(', "state['current'] =", 'save()', "print('START"):
        assert needed in protected, (name, needed)
    assert len([n for n in ast.walk(child_with) if isinstance(n, ast.Call) and
                isinstance(n.func, ast.Attribute) and n.func.attr == 'Popen']) == 1
    body = [child_with, ast.Return(value=ast.Attribute(value=ast.Name(id='child', ctx=ast.Load()),
                                                       attr='returncode', ctx=ast.Load()))]
    wrapper = ast.FunctionDef(name='run_child', args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[],
                             kw_defaults=[], defaults=[]), body=body, decorator_list=[])
    compiled = compile(ast.fix_missing_locations(ast.Module(body=[handler, checkpoint, wrapper], type_ignores=[])),
                       str(HERE / name) + ':AST-extracted-control-only', 'exec')
    sources[name] = sha(HERE / name)
    return compiled, handler, checkpoint


def simulate(compiled, runner, name, *, launch_signals=(), registration_signal=None,
             popen_failure=False, registration_failure=False, save_failure=0,
             print_failure=False, alive=True, wait_signal=None, timeout=False,
             term_race=False, kill_race=False, ordinary=False,
             term_wait_signals=(), kill_wait_signals=(), exited_reap_signals=()):
    events, namespace = [], {}
    control = dict(pending_signals=[])
    class State(dict):
        def __setitem__(self, key, value):
            if key == 'current':
                if registration_signal is not None:
                    namespace['interrupted'](registration_signal, None)
                    events.append(['registration_signal_deferred', registration_signal])
                if registration_failure:
                    raise OSError('simulated current registration failure')
            super().__setitem__(key, value)
    state = State(jobs=[])
    class Child:
        pid = 424242  # Fake only; never sent to an OS API.
        def __init__(self):
            self.returncode = None if alive else 0
            self.waits = 0
            self.term_waits = 0
        def poll(self):
            events.append(['poll', self.returncode])
            return self.returncode
        def wait(self, timeout=None):
            self.waits += 1
            events.append(['wait', timeout])
            if timeout == 0.25:
                if wait_signal is not None:
                    namespace['interrupted'](wait_signal, None)
                elif ordinary:
                    self.returncode = 0
                if self.returncode is None:
                    raise subprocess.TimeoutExpired('FAKE_NO_PROCESS', timeout)
                return self.returncode
            if timeout == 5:
                self.term_waits += 1
                signals = term_wait_signals
            else:
                signals = kill_wait_signals if self.term_waits else exited_reap_signals
            for signum in signals:
                namespace['interrupted'](signum, None)
                events.append(['cleanup_wait_signal_deferred', signum])
            if timeout == 5 and wait_timeout:
                raise subprocess.TimeoutExpired('FAKE_NO_PROCESS', timeout)
            if self.returncode is None:
                self.returncode = 0
            return self.returncode
    child, wait_timeout, saves = Child(), timeout, 0
    def save():
        nonlocal saves
        saves += 1
        events.append(['save', saves])
        if saves == save_failure:
            raise OSError('simulated state persistence failure')
    def fake_print(*args, **kwargs):
        events.append(['print', args[0]])
        if print_failure:
            raise BrokenPipeError('simulated START output failure')
    def popen(command, **kwargs):
        assert command == ['FAKE_NO_PROCESS']
        assert kwargs['start_new_session'] is True and 'preexec_fn' not in kwargs
        events.append(['Popen_enter'])
        for signum in launch_signals:
            namespace['interrupted'](signum, None)
            events.append(['Popen_signal_deferred', signum])
        if popen_failure:
            raise OSError('simulated Popen failure')
        events.append(['Popen_returned_fake_child'])
        return child
    def killpg(pid, signum):
        assert pid == child.pid
        events.append(['killpg', signum])
        if signum == signal.SIGTERM:
            if term_race:
                child.returncode = 0
                raise ProcessLookupError('simulated TERM exit race')
            if not wait_timeout:
                child.returncode = -signal.SIGTERM
        elif signum == signal.SIGKILL:
            child.returncode = 0 if kill_race else -signal.SIGKILL
            if kill_race:
                raise ProcessLookupError('simulated KILL exit race')
        else:
            raise AssertionError(signum)
    now = 1000.0
    def fake_time():
        nonlocal now
        now += 1
        return now
    def fake_sleep(_seconds):
        events.append(['sleep_no_actual_wait'])
        if wait_signal is not None:
            namespace['interrupted'](wait_signal, None)
        elif ordinary:
            child.returncode = 0
    with tempfile.TemporaryDirectory(prefix='fake-child-', dir=HERE) as temp:
        log = Path(temp) / 'fake.log'
        namespace.update(log=log, label='fake', cmd=['FAKE_NO_PROCESS'], scope='fake-control-only', out=Path(temp),
                         item=dict(label='fake', command=['FAKE_NO_PROCESS']), env={}, state=state,
                         signal_control=control, save=save, print=fake_print,
                         guard=types.SimpleNamespace(R=Path('/fake/source')),
                         subprocess=types.SimpleNamespace(Popen=popen, STDOUT=subprocess.STDOUT,
                                                          TimeoutExpired=subprocess.TimeoutExpired),
                         os=types.SimpleNamespace(killpg=killpg), signal=signal,
                         time=types.SimpleNamespace(time=fake_time, monotonic=fake_time, sleep=fake_sleep))
        exec(compiled, namespace)
        error, result = None, None
        try:
            result = namespace['run_child']()
        except BaseException as caught:
            error = caught
        if ordinary:
            assert error is None and result == 0
            assert not any(e[0] == 'killpg' for e in events)
        else:
            assert error is not None, (runner, name)
            expected_error = (KeyboardInterrupt if (launch_signals or registration_signal is not None) and
                              not popen_failure and not registration_failure else OSError)
            if wait_signal is not None:
                expected_error = KeyboardInterrupt
            assert isinstance(error, expected_error), (runner, name, repr(error))
            if wait_signal is not None:
                assert 'signal ' + str(wait_signal) in str(error), 'original signal exception was replaced'
            if save_failure:
                assert str(error) == 'simulated state persistence failure', 'original I/O failure was replaced'
            if popen_failure:
                assert state['interrupted_child'] == dict(created=False, pid=None, returncode=None)
                assert not any(e[0] in ('killpg', 'wait') for e in events)
            else:
                assert state['interrupted_child']['created'] is True
                assert state['interrupted_child']['pid'] == child.pid
                assert child.returncode is not None and child.waits >= 1
                if not alive:
                    assert not any(e[0] == 'killpg' for e in events)
                if (launch_signals or registration_signal is not None) and not registration_failure:
                    assert saves == 0 and not any(e[0] == 'print' for e in events)
                    first = launch_signals[0] if launch_signals else registration_signal
                    assert 'signal ' + str(first) in str(error)
            if timeout:
                assert ['killpg', signal.SIGTERM] in events and ['killpg', signal.SIGKILL] in events
            if term_race:
                assert ['killpg', signal.SIGTERM] in events and ['killpg', signal.SIGKILL] not in events
        cleanup_signals = term_wait_signals + kill_wait_signals + exited_reap_signals
        if cleanup_signals:
            assert control['pending_signals'][0] == cleanup_signals[0], 'first cleanup signal was overwritten'
            assert state['cleanup_deferred_signals'][0] == cleanup_signals[0]
            assert child.waits >= (2 if timeout else 1) and child.returncode is not None
        results.append(dict(runner=runner, name=name, passed=True, error=repr(error) if error else None,
                            interrupted_child=state.get('interrupted_child'), events=events,
                            pending_signals_at_exit=list(control['pending_signals']),
                            first_cleanup_signal=control['pending_signals'][0] if control['pending_signals'] else None))


for runner in ('build_actual.py', 'qualify_actual.py', 'run_replay.py'):
    compiled, handler, checkpoint = extract(runner)
    for signum in (signal.SIGINT, signal.SIGTERM):
        ns = dict(signal_control=dict(pending_signals=[]))
        exec(compile(ast.fix_missing_locations(ast.Module(body=[handler, checkpoint], type_ignores=[])), '<fake-handler>', 'exec'), ns)
        ns['interrupted'](signum, None)
        assert ns['signal_control']['pending_signals'] == [signum]
        try:
            ns['raise_pending']()
        except KeyboardInterrupt as error:
            assert 'signal ' + str(signum) in str(error)
            results.append(dict(runner=runner, name='outside_launch_queued_at_safe_point_' + str(signum), passed=True))
        else:
            raise AssertionError('queued signal did not interrupt at safe point')
    def case(name, **kwargs):
        simulate(compiled, runner, name, **kwargs)
    case('launch_SIGINT_alive', launch_signals=(signal.SIGINT,))
    case('launch_SIGTERM_alive', launch_signals=(signal.SIGTERM,))
    case('launch_repeated_signals_preserve_first', launch_signals=(signal.SIGINT, signal.SIGTERM))
    case('launch_SIGTERM_already_exited', launch_signals=(signal.SIGTERM,), alive=False)
    case('registration_SIGTERM_deferred', registration_signal=signal.SIGTERM)
    case('Popen_failure_no_child', popen_failure=True)
    case('Popen_failure_after_deferred_signal_no_child', launch_signals=(signal.SIGTERM,), popen_failure=True)
    case('registration_failure_child_known', registration_failure=True)
    case('first_save_failure_alive', save_failure=1)
    case('first_save_failure_already_exited', save_failure=1, alive=False)
    case('START_print_failure_alive', print_failure=True)
    case('polling_SIGTERM_alive', wait_signal=signal.SIGTERM)
    case('heartbeat_save_failure_alive', save_failure=2)
    case('TERM_ProcessLookupError_race', save_failure=1, term_race=True)
    case('TERM_timeout_KILL_and_reap', save_failure=1, timeout=True)
    case('KILL_ProcessLookupError_race', save_failure=1, timeout=True, kill_race=True)
    case('ordinary_already_exited_success', alive=False, ordinary=True)
    case('ordinary_alive_to_exit_success', ordinary=True)
    case('TERM_wait_second_SIGINT_preserves_IO_error', save_failure=1, timeout=True,
         term_wait_signals=(signal.SIGINT,))
    case('TERM_wait_second_SIGTERM_preserves_IO_error', save_failure=1, timeout=True,
         term_wait_signals=(signal.SIGTERM,))
    case('KILL_wait_second_SIGINT_preserves_IO_error', save_failure=1, timeout=True,
         kill_wait_signals=(signal.SIGINT,))
    case('TERM_KILL_wait_repeated_signals_preserve_first', save_failure=1, timeout=True,
         term_wait_signals=(signal.SIGINT, signal.SIGTERM), kill_wait_signals=(signal.SIGTERM, signal.SIGINT))
    case('cleanup_second_SIGINT_preserves_original_SIGTERM', wait_signal=signal.SIGTERM, timeout=True,
         term_wait_signals=(signal.SIGINT,))
    case('already_exited_reap_second_signal_deferred', save_failure=1, alive=False,
         exited_reap_signals=(signal.SIGTERM, signal.SIGINT))

report = dict(status='passed_stdlib_fake_lifecycle_not_runtime_qualification', helper_sha256=sha(__file__),
              predecessor_manifest_sha256=sha(OLD / 'manifest.json'), runner_sha256=sources,
              simulations=len(results), results=results, protected_Popen_registration_first_save_first_print=True,
              all_handler_calls_queue_only=True, outside_launch_signals_raise_only_at_safe_point=True, first_launch_signal_preserved=True,
              cleanup_repeated_signals_never_raise_from_handler=True, original_cleanup_trigger_exception_preserved=True,
              killed_by_FAKE_PID_only=True, direct_real_subprocess_calls=False, real_signal_calls=False,
              active_PID_access=False, heavy_guard_called=False, numerical_import=False,
              compilation=False, install=False, pytest_execution=False, perf_execution=False,
              proof_boundary='AST-extracted control flow with stdlib fake children only; actual runners not executed.')
target = HERE / 'lifecycle-fake-evidence.json'
assert not target.exists(), 'preserve immutable previous fake evidence'
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status=report['status'], simulations=len(results), report=str(target), report_sha256=sha(target))))
