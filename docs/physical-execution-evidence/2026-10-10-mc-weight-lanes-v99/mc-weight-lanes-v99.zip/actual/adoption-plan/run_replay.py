"""Future serial 42-job actual owned-chain replay, never implicit execution."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import signal
import subprocess
import sys
import time
import zipfile
import guard

def execute(path):
    path = Path(path).resolve()
    plan = guard.load(path)
    guard.require(guard.sha(path) == path.with_name('manifest.sha256').read_text().strip(), 'replay plan changed')
    guard.require(plan['actual_adoption_manifest_sha256'] == guard.sha(guard.HERE / 'manifest.json'), 'adoption plan differs')
    guard.require(sys.executable == guard.manifest()['python'] and sys.flags.optimize == 0, 'wrong interpreter/assertions')
    out = path.parent
    target = out / 'pipeline.json'
    guard.require(not target.exists(), 'preserve previous running/failed/terminal replay')
    def verify():
        guard.verify('code')
        guard.require(guard.sha(plan['actual_qualification']) == plan['actual_qualification_sha256'], 'actual qualification changed')
        for name, expected in plan['lightweight_files_sha256'].items():
            guard.require(guard.sha(name) == expected, 'replay source changed')
        for name, selected in plan['packages'].items():
            guard.require(guard.sha(selected['identity']) == selected['identity_sha256'], 'selected identity changed')
            i = guard.load(selected['identity'])
            guard.require(guard.native_sources(Path(selected['source'])) == i['source'], 'selected complete source differs')
            guard.require(guard.sha(i['wheel']) == i['wheel_sha256'], 'selected wheel changed')
            with zipfile.ZipFile(i['wheel']) as z:
                members = [n for n in z.namelist() if n.startswith('calmetrics_engine/') and not n.endswith('/')]
                guard.require(len(members) == len(set(members)) == 25, 'selected wheel payload inventory differs')
                for n in members:
                    guard.require((Path(i['installed']) / n).read_bytes() == z.read(n), 'selected installed package differs')
            if name == 'actual99':
                guard.package(selected['identity'])
        guard.require(guard.sha(plan['probe']) == plan['probe_sha256'], 'heap probe changed')
        for item in plan['drivers'].values():
            guard.require(guard.sha(item['path']) == item['sha256'], 'frozen driver changed')
    verify()
    guard.idle()
    with (guard.HERE / '.heavy.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state = dict(status='running', pid=os.getpid(), started_epoch=time.time(), manifest=str(path),
                     manifest_sha256=guard.sha(path), jobs=[], source_adopted=True, goal_complete=False)
        def save():
            state['heartbeat_epoch'] = time.time()
            temporary = target.with_suffix('.tmp.json')
            temporary.write_text(json.dumps(state, indent=2) + '\n')
            temporary.replace(target)
        signal_control = dict(pending_signals=[])
        def interrupted(signum, _):
            # Queue only: never raise between child creation, registration or cleanup instructions.
            signal_control['pending_signals'].append(signum)
        def raise_pending():
            if signal_control['pending_signals']:
                signum = signal_control['pending_signals'].pop(0)
                raise KeyboardInterrupt('actual runner interrupted by signal ' + str(signum))
        signal.signal(signal.SIGTERM, interrupted)
        signal.signal(signal.SIGINT, interrupted)
        save()
        try:
            raise_pending()
            for item in plan['jobs']:
                verify()
                guard.idle()
                selected = plan['packages'][item['package']]
                env = dict(os.environ, **plan['thread_environment'], PYTHONDONTWRITEBYTECODE='1', LC_ALL='C',
                           CME_OWNED_SOURCE_ROOT=selected['source'], CME_OWNED_INSTALL=selected['install'],
                           CME_PERF_PARENT_GUARD_MANIFEST_SHA=guard.sha(path))
                for key in ('PYTHONOPTIMIZE', 'DYLD_INSERT_LIBRARIES', 'PYTEST_ADDOPTS'):
                    env.pop(key, None)
                if item['metric'] == 'heap':
                    env['DYLD_INSERT_LIBRARIES'] = plan['probe']
                log = Path(item['log'])
                for n in ('log', 'output', 'launch'):
                    guard.require(not Path(item[n]).exists(), 'existing output: ' + item[n])
                with log.open('x') as stream:
                    child = None
                    try:
                        raise_pending()
                        child = subprocess.Popen(item['command'], cwd=out, env=env, stdout=stream,
                                                 stderr=subprocess.STDOUT, start_new_session=True)
                        state['current'] = dict(item, pid=child.pid, started_epoch=time.time())
                        raise_pending()
                        save()
                        raise_pending()
                        print('START actual owned', item['label'], child.pid, flush=True)
                        raise_pending()
                        heartbeat = time.monotonic()
                        while child.poll() is None:
                            raise_pending()
                            try:
                                child.wait(timeout=0.25)
                            except subprocess.TimeoutExpired:
                                pass
                            raise_pending()
                            if time.monotonic() - heartbeat >= 2:
                                save()
                                heartbeat = time.monotonic()
                            raise_pending()
                        raise_pending()
                        child.wait()
                        raise_pending()
                    except BaseException:
                        if child is None:
                            state['interrupted_child'] = dict(created=False, pid=None, returncode=None)
                        else:
                            if child.poll() is None:
                                try:
                                    os.killpg(child.pid, signal.SIGTERM)
                                except ProcessLookupError:
                                    pass
                                try:
                                    child.wait(timeout=5)
                                except subprocess.TimeoutExpired:
                                    try:
                                        os.killpg(child.pid, signal.SIGKILL)
                                    except ProcessLookupError:
                                        pass
                                    child.wait()
                            else:
                                child.wait()
                            state['interrupted_child'] = dict(created=True, pid=child.pid, returncode=child.returncode)
                        if signal_control['pending_signals']:
                            state['cleanup_deferred_signals'] = list(signal_control['pending_signals'])
                        raise
                result = dict(item, returncode=child.returncode, pid=child.pid, finished_epoch=time.time(),
                              log_sha256=guard.sha(log))
                for n in ('output', 'launch'):
                    if Path(item[n]).exists():
                        result[n + '_sha256'] = guard.sha(item[n])
                state['jobs'].append(result)
                state.pop('current', None)
                save()
                guard.require(child.returncode == 0, 'actual complete child failed')
                launch = guard.load(item['launch'])
                guard.require(launch['status'] == 'passed_original_driver_assertions', 'original driver proof missing')
                data = guard.load(item['output'])
                guard.require(data['identity']['build_id'] == selected['build_id'], 'measured package differs')
                verify()
                print('PASS actual owned', len(state['jobs']), '/', len(plan['jobs']), flush=True)
            guard.require(len(state['jobs']) == 42, 'incomplete six-load replay')
            raise_pending()
            state.update(status='passed_actual_owned_full_chain_independent_review_pending', finished_epoch=time.time())
        except BaseException as error:
            state.update(status='failed', error=repr(error), finished_epoch=time.time())
            raise
        finally:
            save()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--execute', action='store_true')
    p.add_argument('--manifest')
    args = p.parse_args()
    if args.execute:
        guard.require(args.manifest, 'explicit fresh actual replay manifest required')
        execute(args.manifest)
    else:
        print(json.dumps(dict(status='prepared_not_executed', jobs=42, original_drivers_unmodified=True,
                              heavy_guards_in_parent_only=True, goal_complete=False)))
