"""Stdlib isolated mode-binding cases; fake files/audit functions only, no native imports."""
from pathlib import Path
import ast, copy, hashlib, json, sys, types
HERE=Path(__file__).resolve().parent
assert sys.flags.optimize==0 and sys.dont_write_bytecode
sha_file=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
tree=ast.parse((HERE/'guard.py').read_text())
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
compiled=compile(ast.fix_missing_locations(ast.Module(body=[functions[n] for n in
                 ('require','bound_evidence','qualification_binding')],type_ignores=[])),'<mode-binding-only>','exec')
MODES=('normal-full','eigen-off','compact-packets-off','asan-ubsan')
results=[]

def fixture(mode):
    hashes,objects={},{}
    def file(path,obj=None):
        hashes[path]=hashlib.sha256(('FAKE:'+path).encode()).hexdigest()
        if obj is not None:objects[path]=obj
        return path
    root='/fake/next-r2' if mode in ('normal-full','eigen-off') else '/fake/next-r3' if mode=='compact-packets-off' else '/fake/next-r5'
    config=dict(stage=mode,external_include_sha256='FAKE_CMAKE',runtime='/fake/ASAN_RUNTIME')
    key=mode.replace('-','_')
    manifest=file(root+'/manifest.json',dict(modes={key:copy.deepcopy(config)},case_sets={'focused':49},numerical_source_sha256='FAKE_SOURCE'))
    runner=file(root+'/run_qualification.py')
    control=file(root+'/independent-control.json')
    pipeline=file(root+'/execution-'+mode+'/pipeline.json')
    receipts={}
    if mode in ('normal-full','eigen-off'):
        receipt=file(root+'/'+mode+'-independent.json',dict(status='passed_FAKE_independent',pipeline_sha256=hashes[pipeline],confirmed_blockers=[]))
        receipts[receipt]='passed_FAKE_independent'
    spec=dict(pipeline=pipeline,manifest=manifest,runner=runner,manifest_sha256=hashes[manifest],runner_sha256=hashes[runner],
              config_key=key,configuration=config,compiler=['FAKE_COMPILER',mode],build_id='FAKE_BUILD_'+mode,
              terminal_receipts=receipts,proof_sha256={p:hashes[p] for p in [manifest,runner,control,*receipts]})
    m=dict(qualification_mode_plans={mode:spec},qualification_case_sets={'focused':49},native_after={'cpp/compact_path.cpp':'FAKE_SOURCE'})
    i=dict(source=copy.deepcopy(m['native_after']),compiler=list(spec['compiler']),build_id=spec['build_id'],build='/fake/build',
           external_cmake_include_sha256='FAKE_CMAKE',sanitizer_runtime='/fake/ASAN_RUNTIME')
    audit=dict(mode=mode,complete_native_config_verified='FAKE_AUDIT')
    q=dict(identity=i,manifest_sha256=hashes[manifest],runner_sha256=hashes[runner],package_audit=copy.deepcopy(audit),
           sanitizer_leak_detection=False)
    q['private_qualification_identity_sha256']=hashlib.sha256(json.dumps(dict(identity=i,audit=audit),sort_keys=True).encode()).hexdigest()
    return dict(mode=mode,m=m,q=q,path=pipeline,spec=spec,hashes=hashes,objects=objects,audit=audit,
                flags='-fsanitize=address,undefined -fno-omit-frame-pointer')

def run(name,mode,mutate=None):
    f=fixture(mode)
    if mutate:mutate(f)
    def audit(i,selected_mode):
        assert selected_mode==mode
        return f['audit']
    def run_path(path):
        assert path==f['spec']['runner']
        return {'audit_package':audit}
    ns=dict(Path=Path,D99=Path('/fake/D99'),hashlib=hashlib,json=json,
            sha=lambda p:f['hashes'][str(p)],load=lambda p:f['objects'][str(p)],
            runpy=types.SimpleNamespace(run_path=run_path),cpp_recipes=lambda *args:{'cpp/fake.cpp':{'FLAGS':f['flags']}})
    exec(compiled,ns)
    error=None
    try:ns['qualification_binding'](mode,f['path'],f['q'],f['m'])
    except (RuntimeError,KeyError) as caught:error=caught
    assert (error is None)==(mutate is None),(name,repr(error))
    results.append(dict(name=name,mode=mode,passed=True,accepted=error is None,rejection=repr(error) if error else None))

for mode in MODES:run('correct_exact_mixed_plan_'+mode,mode)
run('arbitrary_pipeline_rejected','normal-full',lambda f:f.update(path='/fake/unapproved/pipeline.json'))
run('compact_r2_pipeline_rejected','compact-packets-off',lambda f:f.update(path='/fake/next-r2/execution-compact-packets-off/pipeline.json'))
run('runner_SHA_rejected','normal-full',lambda f:f['q'].update(runner_sha256='WRONG'))
run('manifest_SHA_rejected','eigen-off',lambda f:f['q'].update(manifest_sha256='WRONG'))
run('config_mutation_rejected','compact-packets-off',lambda f:f['objects'][f['spec']['manifest']]['modes'][f['spec']['config_key']].update(stage='WRONG'))
run('math_mutation_rejected','normal-full',lambda f:f['objects'][f['spec']['manifest']].update(numerical_source_sha256='WRONG'))
run('case_contract_mutation_rejected','asan-ubsan',lambda f:f['objects'][f['spec']['manifest']].update(case_sets={'focused':45}))
run('source_mutation_rejected','eigen-off',lambda f:f['q']['identity']['source'].update({'cpp/compact_path.cpp':'WRONG'}))
run('compiler_mutation_rejected','normal-full',lambda f:f['q']['identity'].update(compiler=['WRONG']))
run('build_ID_mutation_rejected','eigen-off',lambda f:f['q']['identity'].update(build_id='WRONG'))
run('stored_package_audit_mutation_rejected','normal-full',lambda f:f['q']['package_audit'].update(mode='WRONG'))
run('private_identity_mutation_rejected','normal-full',lambda f:f['q'].update(private_qualification_identity_sha256='WRONG'))
run('stale_terminal_receipt_rejected','eigen-off',lambda f:next(f['objects'][p] for p in f['spec']['terminal_receipts']).update(pipeline_sha256='WRONG'))
run('blocked_terminal_receipt_rejected','normal-full',lambda f:next(f['objects'][p] for p in f['spec']['terminal_receipts']).update(confirmed_blockers=['P1']))
run('r3_control_receipt_SHA_rejected','compact-packets-off',lambda f:f['hashes'].update({f['spec']['runner'].replace('run_qualification.py','independent-control.json'):'WRONG'}))
run('SAN_r2_pipeline_rejected','asan-ubsan',lambda f:f.update(path='/fake/next-r2/execution-asan-ubsan/pipeline.json'))
run('SAN_r3_pipeline_rejected','asan-ubsan',lambda f:f.update(path='/fake/next-r3/execution-asan-ubsan/pipeline.json'))
run('selected_SAN_control_receipt_SHA_rejected','asan-ubsan',lambda f:f['hashes'].update({f['spec']['runner'].replace('run_qualification.py','independent-control.json'):'WRONG'}))
run('SAN_r4_pipeline_rejected','asan-ubsan',lambda f:f.update(path='/fake/next-r4/execution-asan-ubsan/pipeline.json'))
run('sanitizer_leaks_contract_rejected','asan-ubsan',lambda f:f['q'].update(sanitizer_leak_detection=True))
run('unsanitized_native_recipes_rejected','asan-ubsan',lambda f:f.update(flags='-O3'))
report=dict(status='passed_stdlib_mode_binding_fakes_not_mode_qualification',helper_sha256=sha_file(__file__),guard_sha256=sha_file(HERE/'guard.py'),
            scenarios=len(results),results=results,direct_real_process_calls=False,real_signal_calls=False,
            numerical_import=False,build_execution=False,pytest_execution=False,perf_execution=False,
            proof_boundary='AST mode binding with fake SHA/files/package-audit functions only; actual normal/Eigen static audit separately checked.')
p=HERE/'mode-binding-fake-evidence.json';assert not p.exists()
p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],scenarios=len(results),report_sha256=sha_file(p))))
