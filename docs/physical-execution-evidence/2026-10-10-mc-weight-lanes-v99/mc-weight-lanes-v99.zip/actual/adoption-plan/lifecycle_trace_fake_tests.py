"""Stdlib AST/sys.settrace/fake children only; no process, signal registration or heavy call."""
from pathlib import Path
import ast
import dis
import hashlib
import json
import signal
import subprocess
import sys
import tempfile
import types

HERE = Path(__file__).resolve().parent
assert sys.flags.optimize == 0 and sys.dont_write_bytecode
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
results, audited = [], {}


def extract(name):
    source = (HERE / name).read_text()
    tree = ast.parse(source)
    handler = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'interrupted')
    checkpoint = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'raise_pending')
    # A signal callback contains only one append; there is no asynchronous raise or mode branch.
    assert len(handler.body) == 1 and isinstance(handler.body[0], ast.Expr)
    call = handler.body[0].value
    assert isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == 'append'
    assert not any(isinstance(n, (ast.Raise, ast.If, ast.Try)) for n in ast.walk(handler))
    child_with = next(n for n in ast.walk(tree) if isinstance(n, ast.With) and
                      ast.get_source_segment(source, n).startswith("with log.open('x')"))
    protected = next(n for n in child_with.body if isinstance(n, ast.Try))
    cleanup = protected.handlers[0]
    assert ast.unparse(cleanup.type) == 'BaseException'
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'raise_pending'
                   for statement in cleanup.body for n in ast.walk(statement))
    calls = lambda region, method: [n for n in ast.walk(region) if isinstance(n, ast.Call) and
                                    isinstance(n.func, ast.Attribute) and n.func.attr == method]
    source_line = lambda node: ast.get_source_segment(source, node)
    targets = {'safe_point_before_Popen': protected.body[0].lineno,
               'Popen_instruction': calls(protected, 'Popen')[0].lineno,
               'registration_instruction': next(n for n in protected.body if isinstance(n, ast.Assign)).lineno}
    targets['registration_instruction'] = next(n for n in protected.body if isinstance(n, ast.Assign) and
                                             "state['current']" in source_line(n)).lineno
    targets['first_save_instruction'] = next(n for n in protected.body if isinstance(n, ast.Expr) and
                                            isinstance(n.value, ast.Call) and ast.unparse(n.value.func) == 'save').lineno
    targets['first_print_instruction'] = next(n for n in protected.body if isinstance(n, ast.Expr) and
                                             isinstance(n.value, ast.Call) and ast.unparse(n.value.func) == 'print').lineno
    loop = next(n for n in protected.body if isinstance(n, ast.While))
    targets['live_poll_instruction'] = loop.lineno
    targets['live_short_wait_instruction'] = calls(loop, 'wait')[0].lineno
    targets['success_reap_instruction'] = next(n for n in protected.body if isinstance(n, ast.Expr) and
                                               'child.wait()' in source_line(n)).lineno
    targets['except_first_statement'] = cleanup.body[0].lineno
    targets['cleanup_poll_instruction'] = calls(cleanup, 'poll')[0].lineno
    kills = calls(cleanup, 'killpg')
    targets['cleanup_TERM_instruction'] = next(n for n in kills if 'SIGTERM' in source_line(n)).lineno
    targets['cleanup_KILL_instruction'] = next(n for n in kills if 'SIGKILL' in source_line(n)).lineno
    waits = calls(cleanup, 'wait')
    targets['cleanup_TERM_wait_instruction'] = next(n for n in waits if 'timeout=5' in source_line(n)).lineno
    untimed = sorted([n for n in waits if 'timeout=' not in source_line(n)], key=lambda n:n.lineno)
    assert len(untimed) == 2
    targets['cleanup_KILL_wait_instruction'] = untimed[0].lineno
    targets['cleanup_exited_reap_instruction'] = untimed[1].lineno
    record = sorted([n for n in ast.walk(cleanup) if isinstance(n, ast.Assign) and
                     "state['interrupted_child']" in source_line(n)], key=lambda n:n.lineno)
    targets['cleanup_no_child_record_instruction'] = record[0].lineno
    targets['cleanup_known_child_record_instruction'] = record[1].lineno
    targets['cleanup_deferred_record_instruction'] = next(n for n in ast.walk(cleanup) if isinstance(n, ast.Assign) and
                                                          "state['cleanup_deferred_signals']" in source_line(n)).lineno
    targets['cleanup_original_reraise_instruction'] = cleanup.body[-1].lineno
    wrapper = ast.FunctionDef(name='run_child', args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[],
                             kw_defaults=[], defaults=[]), body=[child_with, ast.Return(value=ast.Name(id='child',ctx=ast.Load()))],
                             decorator_list=[])
    compiled = compile(ast.fix_missing_locations(ast.Module(body=[handler,checkpoint,wrapper],type_ignores=[])),
                       str(HERE / name) + ':trace-extracted-only','exec')
    audited[name] = dict(sha256=sha(HERE/name), targets=targets,
                        handler_queue_only=True, cleanup_contains_no_raise_pending=True,
                        normal_wait_timeout_seconds=0.25)
    return compiled, targets


def simulate(compiled, runner, name, target, signums, *, cleanup=False, no_child=False,
             already_exited=False, callback=None, seed_cleanup_signal=None):
    events, ns = [], {}
    pending, state = [], {'jobs':[]}
    hit, saves, term_waited, normal_waits = False, 0, False, 0
    class Child:
        pid = 424242
        returncode = 0 if already_exited else None
        waits = 0
        def poll(self):
            events.append(['poll', self.returncode])
            if callback == 'poll_callback' and not hit:
                inject('poll_callback')
            return self.returncode
        def wait(self, timeout=None):
            nonlocal term_waited, normal_waits
            self.waits += 1
            events.append(['wait', timeout])
            if callback == 'wait_callback' and not hit:
                inject('wait_callback')
            if timeout == 0.25:
                normal_waits += 1
                # Exit on the first short wait. A signal at this line still must lead to reap.
                self.returncode = 0
                return self.returncode
            if timeout == 5:
                term_waited = True
                if self.returncode is None:
                    raise subprocess.TimeoutExpired('FAKE_NO_PROCESS',timeout)
            if self.returncode is None:
                self.returncode = -signal.SIGKILL
            return self.returncode
    child = Child()
    def inject(stage):
        nonlocal hit
        assert not hit
        hit = True
        for signum in signums:
            ns['interrupted'](signum,None)
            events.append(['queued_signal', stage, signum])
    def popen(cmd,**kwargs):
        assert cmd == ['FAKE_NO_PROCESS'] and kwargs['start_new_session'] is True
        events.append(['Popen_fake_only'])
        if no_child:
            raise OSError('original_fake_Popen_failure')
        if callback == 'Popen_after_creation_before_return':
            inject(callback)
        return child
    class State(dict):
        def __setitem__(self,key,value):
            if callback == 'record_callback' and key == 'interrupted_child' and not hit:
                inject('record_callback')
            super().__setitem__(key,value)
    state = State(state)
    def save():
        nonlocal saves
        saves += 1
        events.append(['save',saves])
        if cleanup and saves == 1:
            raise OSError('original_fake_save_failure')
    def killpg(pid,signum):
        assert pid == child.pid
        events.append(['killpg_fake_only',signum])
        if seed_cleanup_signal is not None and signum == signal.SIGTERM:
            ns['interrupted'](seed_cleanup_signal,None)
            events.append(['seed_cleanup_queued_signal',seed_cleanup_signal])
        if callback == ('TERM_callback' if signum == signal.SIGTERM else 'KILL_callback') and not hit:
            inject(callback)
        if signum == signal.SIGKILL:
            child.returncode = -signal.SIGKILL
    popen_store_offset = None
    def tracer(frame,event,arg):
        if frame.f_code.co_name == 'run_child' and frame.f_code.co_filename.endswith(':trace-extracted-only'):
            frame.f_trace_opcodes = True
            if event == 'opcode' and target == 'Popen_return_before_STORE_FAST_child' and not hit and frame.f_lasti == popen_store_offset:
                inject('opcode_before_STORE_FAST_child')
        if event == 'line' and frame.f_code.co_name == 'run_child' and frame.f_code.co_filename.endswith(':trace-extracted-only'):
            if not hit and frame.f_lineno == target:
                inject('trace_before_instruction:'+str(target))
        return tracer
    with tempfile.TemporaryDirectory(prefix='trace-fake-',dir=HERE) as temp:
        ns.update(log=Path(temp)/'fake.log',label='fake',scope='fake',cmd=['FAKE_NO_PROCESS'],env={},
                  item=dict(label='fake',command=['FAKE_NO_PROCESS']),out=Path(temp),state=state,
                  signal_control=dict(pending_signals=pending),save=save,print=lambda *args,**kwargs:None,
                  guard=types.SimpleNamespace(R=Path('/fake/source')),
                  os=types.SimpleNamespace(killpg=killpg),signal=signal,time=types.SimpleNamespace(time=lambda:1000.,monotonic=lambda:1000.),
                  subprocess=types.SimpleNamespace(Popen=popen,STDOUT=subprocess.STDOUT,TimeoutExpired=subprocess.TimeoutExpired))
        exec(compiled,ns)
        stores=[i.offset for i in dis.get_instructions(ns['run_child']) if i.opname=='STORE_FAST' and i.argval=='child']
        assert len(stores)==2
        popen_store_offset=stores[1]
        error=None
        previous=sys.gettrace()
        try:
            sys.settrace(tracer)
            ns['run_child']()
        except BaseException as caught:
            error=caught
        finally:
            sys.settrace(previous)
    assert hit,(runner,name,'injection point not reached')
    assert error is not None,(runner,name,'pending signal or original exception was lost')
    if cleanup:
        assert isinstance(error,OSError) and str(error) == ('original_fake_Popen_failure' if no_child else 'original_fake_save_failure'),(runner,name,repr(error))
    else:
        assert isinstance(error,KeyboardInterrupt) and 'signal '+str(signums[0]) in str(error),(runner,name,repr(error))
    expected_created = not no_child and name != 'safe_point_before_Popen'
    assert state['interrupted_child']['created'] is expected_created,(runner,name,state)
    if expected_created:
        assert state['interrupted_child']['pid'] == child.pid and child.waits >= 1 and child.returncode is not None,(runner,name,state,events)
        assert state['interrupted_child']['returncode'] == child.returncode
    else:
        assert child.waits == 0 and not any(e[0]=='killpg_fake_only' for e in events)
    if cleanup:
        expected_queue=([seed_cleanup_signal] if seed_cleanup_signal is not None else [])+list(signums)
        assert pending[:len(expected_queue)] == expected_queue,'queue order changed'
    results.append(dict(runner=runner,name=name,signums=list(signums),target_line=target,passed=True,error=repr(error),
                        interrupted_child=state['interrupted_child'],events=events,pending_signals=list(pending)))


for runner in ('build_actual.py','qualify_actual.py','run_replay.py'):
    compiled,targets=extract(runner)
    for name,target in targets.items():
        cleanup=name.startswith('cleanup_') or name == 'except_first_statement'
        for signals in ((signal.SIGINT,),(signal.SIGTERM,),(signal.SIGINT,signal.SIGTERM,signal.SIGINT)):
            simulate(compiled,runner,name,target,signals,cleanup=cleanup,
                     no_child=name == 'cleanup_no_child_record_instruction',
                     already_exited=name == 'cleanup_exited_reap_instruction',
                     seed_cleanup_signal=signal.SIGTERM if name=='cleanup_deferred_record_instruction' else None)
    for signals in ((signal.SIGINT,),(signal.SIGTERM,),(signal.SIGINT,signal.SIGTERM)):
        simulate(compiled,runner,'Popen_return_before_STORE_FAST_child','Popen_return_before_STORE_FAST_child',signals)
    for callback in ('Popen_after_creation_before_return','poll_callback','wait_callback','TERM_callback','KILL_callback','record_callback'):
        simulate(compiled,runner,callback,-1,(signal.SIGINT,signal.SIGTERM),
                 cleanup=callback in ('TERM_callback','KILL_callback','record_callback'),callback=callback)
report=dict(status='passed_stdlib_trace_fake_lifecycle_not_runtime_qualification',helper_sha256=sha(__file__),
            runner_audits=audited,simulations=len(results),results=results,
            except_first_instruction_repeated_signals_covered=True,handler_always_queue_only=True,
            Popen_registration_poll_TERM_KILL_wait_record_injections_covered=True,original_exception_preserved=True,
            fake_process_only=True,real_process_calls=False,real_signal_calls=False,heavy_guard_calls=False,
            numerical_import=False,build_execution=False,installation=False,pytest_execution=False,JIT=False,perf_execution=False)
out=HERE/'lifecycle-trace-fake-evidence.json'
assert not out.exists()
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],simulations=len(results),report_sha256=sha(out))))
