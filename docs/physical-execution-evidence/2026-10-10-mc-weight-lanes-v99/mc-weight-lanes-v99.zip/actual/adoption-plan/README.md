# V99 实际采用准备（2026-10-10，未执行）

本目录只准备静态计划、保护脚本与未来可执行入口。当前 r7 只修复 r6 最终包审计位于最后取消安全点之后的 P2；r6 拒绝与原始反例保留。没有修改 CalMetricsEngine/FundInvestmentResearchPlatform，没有编译、安装、pytest 收集、数值导入、JIT 或性能执行。V99 镜像的资格与性能证据不等于实际采用。r1/r2/r3/r3-r2/r4/r5 的准备态、静态失败和独立审核证据原样保留。r5 因 except 首语句前第二次信号可能跳过回收而被拒绝；r6 改为信号处理器全过程只排队，受保护的安全点主动中断。r6 的最终资格路径绑定已独审通过的 r5/SAN 控制准备；SAN 数值资格尚未终态，仍不能执行采用准入。

## 1. 前置条件和逐文件范围

根目录 `manifest.json` 绑定当前实际 R 的 HEAD/branch、暂存 diff、normal/all Git 状态、全部现有 dirty 文件的 SHA，以及 A93 的原保护范围。F 的内容保护仅覆盖原10个源码与 normal Git 状态，不代表 F 全库存已逐文件散列。采用只能改变以下两项：

| 实际路径 | 条件 | 采用方式 |
| --- | --- | --- |
| `cpp/compact_path.cpp` | 当前 `4c85e0c6…`，候选 `c7115c1a…` | 已有 untracked 文件只能用此次已审核候选替换，不能覆盖其他 dirty 文件 |
| `tests/test_compact_weight_lanes.py` | 实际 R 必须不存在；候选 `a9030028…` | 创建新文件；若已有同名文件，停止并重新核对归属，不覆盖 |

完整哈希以 manifest 为准。只有这一处 C++ 变化；新测试的最终资格依据为 49 项 XML ID 集，不能读取候选 manifest 中过时的“45 unexecuted”描述作为计数。

采用前必须完成 normal-full、Eigen-OFF、仅 compact packet 关闭、ASan/UBSan 四个独立模式，以及 V99 r3 六类负载 42 项完整链复测和独立审核。OFF 990、compact-OFF/SAN 1049、normal-full 17179 个 Python 唯一 ID，各原生9；SAN 是受影响范围且关闭 LeakSanitizer，compact-OFF 不是全引擎 scalar 运行。所有失败与未适用项原样保留。

root 最终决策格式见 `adoption-decision-template.json`。决策必须绑定实际终态 pipeline、独立审核及所有原始证据 SHA，说明收益、负面结果、不确定性和采用理由。mode review 的 `evidence_sha256` 必须覆盖各 job 的日志、XML 与 collection JSON；full review 的同名字段必须覆盖42项的 log/raw/launch，以及原 full review、cleanup 补验的 supplement、pipeline、raw、launch 和日志。采用 gate 会逐项复核 SHA、四模式原生 exact 9-ID、Python/collection exact ID、六负载×7项唯一 job 与其原始负载/选包身份。final full review 另用 `parent_review_sha256` 与 `cleanup_supplement_sha256` 绑定既有审核；历史已清理的可再生 bytecode 由新适配 review 如实单列，不声称仍存在。只准备模板不代表审批；普通进入 full 的 screen decision 不能代替最终采用决策。

静态核对命令（无数值工作）：

```sh
/usr/bin/python3 -B /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/guard.py --phase before
```

root 审定后自行采用两文件；本目录没有自动改 R 的程序。采用时先执行 before guard，确认新测试仍不存在，完成后执行 `--phase code`。该阶段比对候选93个源码与204个测试，同时保护原有其他文件和 F。**采用后不调用旧 A93 actual_guards.py 来判断源码**，它只适用于采用前 actual79。

## 2. 真实 R 构建与完整包身份

使用唯一 venv Python、已存在的离线 build-deps 和 `/opt/homebrew/bin/cmake`。native 编译并发1，Eigen/Accelerate/Highway ON、SAN OFF、Release、原精度 flags；无全局安装、无网络依赖安装。新 attempt 目录不可覆盖，失败原样保留。

以下是未来执行命令，当前未执行；`FINAL_DECISION.json` 必须是 root 经 final 证据审定的真实文件：

```sh
env -u PYTHONOPTIMIZE -u DYLD_INSERT_LIBRARIES /Users/chenjunming/Desktop/myenv_312/bin/python3.12 -B /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/build_actual.py --execute --attempt r1 --adoption-decision FINAL_DECISION.json
```

pip wheel 的 cwd 必须为实际 R；build/target install 全在本目录新 `actual-r1`。身份包含实际R93个源码、编译器/options、所有生产TU的DEFINES/FLAGS/INCLUDES、wheel/native/worker SHA、runtime build ID、实际包路径、零 fallback/JIT smoke。TU对照只归一化source/build路径，不能忽略flag、define或其他include差异；公共build ID没有覆盖per-TU设置，因此实际每TU必须与已qualified normal候选完全一致。相同源码/config 预期 build ID 为 `f789954a…`；**不要求实际重建二进制 SHA 与镜像相同**。安装全部25个 payload 必须与同一个 wheel 逐字节一致，Python wrappers 与实际源码一致。worker 用已冻结的 Mach-O checker 核对 UUID/14映射section，保留 strip 前后不同 SHA，不能将文件哈希不同当作混装。

## 3. 实际安装包回归

未来先 affected，再 full；各次使用不同 attempt，严格收集/执行 ID 集对照且禁止 skip。新实际包的 identity 是唯一选择，不使用候选 install 或旧 worker。原生9项需要允许本地共享内存/子进程的执行环境。

```sh
env -u PYTHONOPTIMIZE -u DYLD_INSERT_LIBRARIES /Users/chenjunming/Desktop/myenv_312/bin/python3.12 -B /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/qualify_actual.py --execute --scope affected --attempt affected-r1 --identity /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r1/package/identity.json --adoption-decision FINAL_DECISION.json
env -u PYTHONOPTIMIZE -u DYLD_INSERT_LIBRARIES /Users/chenjunming/Desktop/myenv_312/bin/python3.12 -B /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/qualify_actual.py --execute --scope full --attempt full-r1 --identity /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r1/package/identity.json --adoption-decision FINAL_DECISION.json
```

full已包含affected和新49，最终唯一Python计数为17179，不能将1049相加。四种镜像构建资格不冒充实际R构建资格；实际普通包还须独立审核其身份/日志/XML与影响范围。数学顺序、错误、prepared重读、C/F/strided/reverse、输出独立所有权和两代保留均由现有/新回归保留。没有新公开算子/AST/DAG/transport/Excel数学契约变化；适用Excel回归在full中，历史真实Excel重算范围不扩张。

## 4. 实际包 owned 完整链复验

实际 full 通过后用 `prepare_replay.py` 生成 fresh replay-r1 的42-job队列及字节相同support快照；准备不运行数值：

```sh
/usr/bin/python3 -B /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/prepare_replay.py --identity /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-r1/package/identity.json --full-qualification /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/actual-qualification-full-r1/pipeline.json --output /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/replay-r1
env -u PYTHONOPTIMIZE -u DYLD_INSERT_LIBRARIES /Users/chenjunming/Desktop/myenv_312/bin/python3.12 -B /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/run_replay.py --execute --manifest /private/tmp/calmetrics-v99-adoption-plan-20261010/r7/replay-r1/manifest.json
```

**不改冻结D98/V99原driver、数学函数、decorator、signature、缓存设置或容差。**只提供原有source/install/build-ID selectors，并和V99 r3一样改3个非数学support/cache路径变量。原D98 source/bytecode/Numba cache不写。采用后 actual79 对照使用 immutable V93 `r5/source` 与旧whole install；actual99使用实际R与新whole install。

正态/Student × C1/C8/C32短历史，共6类负载。每类 actual79-before/actual99/actual79-after三组时间，每组原driver3轮交替CPP/NJIT；另新包/NJIT独立heap/RSS进程，共42项。双方CPU1、相同owned生产NJIT输入准备、ordinary Scheduler、相同全部输出、两代保留，input prep/copy/planning/return在完整计量内；编译/JIT静态定义不计。heap注入仅heap child，RSS保留实际baseline/total/delta，不用ru_maxrss冒充增量。

完整源/wheel/XML/dirty保护只在parent前后进行，child仅验证轻量manifest/env/small-SHA，原driver仍验证本次选中完整runtime。防止proof-only ZIP/XML分配使测量RSS基线额外膨胀。此改动是证据范围修正，不能当作C++内存优化收益。

每项记录真实PID、命令、heartbeat、日志/结果/launch SHA及终态；observer timeout不重新启动。三 runner 的 signal handler 始终只向 pending_signals 追加，不直接抛异常，也不依赖临时 cleanup/launch 标志。Popen、current 注册、首次 save/print、poll 与 wait 全在 cleanup try 内；子进程已知后、每次短 wait 后及批次通过前，通过 raise_pending() 安全点取出首个信号并主动中断。live child 的等待 timeout 为0.25秒，heartbeat仍为2秒，避免额外状态落盘影响将来的性能复验。异常时 TERM→5秒等待→必要时 KILL→reap；TERM/KILL退出竞态被处理，已退出child也须wait回收。cleanup 不调用 raise_pending()，第二次及后续信号继续排队，不能在except入口或清理指令之间跳出；完成回收与 interrupted_child 记录后，裸raise保留首次失败。一次只有一个heavy pipeline；失败保存并停止、重试用fresh plan/attempt。全部42项完成后还需独立审核实测收益/不确定性。C1有限收益/小耗时增加、C32比NJIT更大的tracked heap、权重pack额外2048B/workspace2112B等负面结果必须按最终数据保留。

该链不是平台完整business服务：仍排除covariance_root_generation、coverage、limits、JSON_packaging和stage_ordered_first_fault；新C++ RNG/旧seed匹配不在本次范围。不能将成功数学owned链写成平台正式替代已完成。

## 5. 权威文档与归档收尾

只有真实R重建、回归、完整链及独立审核闭环之后，更新以下现有权威文档，保持原历史数值/失败/日期：

- `docs/mc-projection-primitives.md`：组合lane准入/不适用、ascending asset与step→path数学顺序、pack/预算/只读/ownership，以及新实际包六负载时间、tracked heap、total/increment RSS与剩余范围。
- `docs/execution-guide.md`：私有compact路径的新增组合lane与实际计数，仍由同一Scheduler决定，C1/稀疏/异常/库关闭保持canonical路径。
- `docs/physical-execution-optimization.md`：按实际build/source列最终采用结论，区分镜像初筛与实际包复验，不关闭long-K/QP/frontier/exploration等整体问题。
- `docs/README.md`：当前说明到新证据入口的路由。
- 新建 `docs/physical-execution-evidence/2026-10-10-mc-weight-lanes-v99/README.md` 与 `mc-weight-lanes-v99.zip`：归档源码单文件patch、新49test、mode/normal/native相关日志与XML、身份/manifest/worker proof、static ISA、原screen/r3full/实际42项JSON/launch、独立review/决策/失败与当前边界；新zip每项有SHA目录。需要补充母目录入口时先核对其归属并重新列入allowlist，不能擅改旧归档。

默认仅上述4现有+2新文档/归档路径允许变化，不能覆盖A93既有zip或将其historical baseline变更。文档收尾后建立root/独立审核的 `status=reviewed_v99_actual_documents` receipt，列before/after SHA并绑定本plan，然后 `guard.py --phase documents --document-receipt ...`。使用all-file Git状态检查新目录内容，避免normal status的折叠目录误判。

AGENTS/数学与Excel纪律、operator-reference/public API不需改变：本次纯物理实现，registry190/逻辑图/Excel公式均保持。检查相关local链接和diff格式，新增性能数字应逐项对应原始证据。未提交、推送或发布；该计划不授予远端操作。

## 6. 冻结 r4 的历史静态修复证据

`lifecycle_fake_tests.py` 从实际三个 runner 的 AST 抽取 handler 与子进程区域，使用标准库假 Popen/child/save/print/signal 验证78个场景（原60项，加18项清理中重复信号）。它还将生命周期改动复原后逐字比较 r2，确认三个 runner 相比r3-r2仅改变 handler 与生命周期。`admission_fake_tests.py` 运行29个内存证据/collection 文本场景，确认错误 native 九 ID、42重复 job、错误或缺失 launch SHA、原始文件漏绑定和 cleanup 未闭合都会拒绝。两份证据均不调用真实 Popen、killpg、signal.signal 或 heavy guard，不导入 NumPy/native/pytest，不构建、安装、JIT或性能执行。它们是控制流准备检查，不等于实际运行验收。

三个 runner 的参考是已审核 `qualification-plan-next-r2`；该目录及 live normal-full 未被改变。实际采用仍需 root 最终决定、fresh实际包构建、affected/full回归、42项实际 owned链复验与独立审核。

首版 r3 的真实证据兼容核对发现 time-only `cpu_budget` 被错误要求于 heap/RSS。r3-r2 按 metric 分别核对 time 的 CPU字段、heap/RSS 的 backend/PID，并统一核对 launch 的 CPU1线程环境；无修改原始结果。

独立审核在r3-r2确认唯一P1：TERM后wait期间第二次信号可能跳过KILL/reap。r4用独立cleanup deferral状态封闭该窗口，并覆盖TERM timed-wait、KILL untimed-wait、退出child的reap及多次信号；首次I/O错误和首次中断都保留。原29项准入/collection证据与全部数学/两文件采用范围保持；新manifest另冻结原78项之前的60+29证据、r3-r2 manifest、自审/diff及独立拒绝与复现。

## 7. 冻结 r5 的历史有限资格路径修订

r4未硬编码终态必须同一目录，但未逐模式绑定runner/manifest，因此r5只增加此准入限制：normal-full、Eigen-OFF固定在qualification-plan-next-r2；compact-packets-off、ASan/UBSan固定在已独立审核的qualification-plan-next-r3。后一版仅修复cleanup重复信号，原数值/build/case-selection文本未变；其独立receipt `12a7dfa4…` 被冻结。normal与Eigen的root/独立终态receipt和pipeline被冻结；r4 cleanup独立通过 `a8e85387…` 也保留。尚未通过的两个模式不能执行admission，更不能据此采用实际R。

每模式绑定精确pipeline路径、runner/manifest SHA、模式配置、同一93源码与case集合、该模式compiler/build ID、whole包/recipes/worker的新鲜audit与private identity。Eigen-OFF保留自己的`18774a93…`身份；不能强制全部模式为normal `f789954a…`。SAN要求ASan运行时、关闭leak检测及实际native sanitizer flags；compact-OFF仅允许冻结外部CMake include的定义变化。最终all-mode独立review除原raw SHA外，必须有`mode_bindings`，等于guard逐模式返回的完整绑定；最终root决策SHA map也必须包含各绑定proof及全部原始件。

78项生命周期报告与r4逐字节相同；29个旧准入场景结果保持（新模式检查在其中使用stub，单独以21项AST/fake测试验证），不冒充四模式真实资格。normal/Eigen的新鲜只读包audit已通过；compact/SAN仍等各自实际终态和独立审核。

## 8. 冻结 r6 的历史生命周期与有限资格修订

r5 独立拒绝 receipt 911453b2… 与 except-entry trace 2d3fc3f6… 原样冻结；不把 r4 的 cleanup-only 通过当作 r5 或 r6 的准入通过。r6 的原78个假子进程场景保留，信号在所有位置改为排队，旧 outside-launch 的立即抛异常断言改为安全点主动抛。新增198个 AST/sys.settrace/假child场景，逐点覆盖 except 第一语句前、Popen 返回后 STORE_FAST child 前、注册、poll、0.25秒等待、TERM/KILL/5秒等待/reap和记录入口，并覆盖连发SIGINT/SIGTERM与首次I/O错误保持。handler只有append，cleanup没有任何主动信号异常。

lifecycle-fake-evidence-r3.json 与 lifecycle-trace-fake-evidence-r4.json 是最终生命周期静态自核；同目录早期阶段raw与一次编辑位置断言失败均保留，不能作为最终结果。所有假测试仅运行抽取的标准库控制流，没有真实子进程、signal.signal、killpg、数值import、编译、安装、pytest、JIT或性能执行。

最终四模式只允许以下有限路径：normal-full/Eigen-OFF 使用 next-r2；compact-packets-off 使用已在执行的 next-r3；SAN 使用 fresh next-r5。next-r4 因批次审计后待处理信号可能静默留存而独审拒绝，拒绝 receipt 3ac66748… 保留；不把它作为许可。next-r5 manifest固定为d20b0a82…、runner固定为e60b83c9…，独立控制 receipt 13e81fc4… 已确认数学/build/case-selection文本未变以及批次安全点关闭。不能接受任意其它runner，也不能把尚未终态的模式写成已通过。完整mode review仍须逐项绑定模式真实build ID、whole包、recipe、worker、配置与全部proof/raw SHA；之前r5的21项模式fake和29项准入fake不删减。

最终模式fake为25项：保留此前24项逻辑，并新增SAN误用next-r4路径的拒绝；旧24项raw保留，selected_SAN_control_receipt标签按最终r5控制身份表述。29项原准入raw与r5逐字节相同。mode-binding-fake-evidence-r2.json 是最终模式静态fake，旧stage的pending-final-freeze.json只保留当时状态；当前manifest和最终self-review拥有最新事实。

normal/Eigen/compact三个终态的root与独立receipt按精确SHA冻结；SAN只冻结next-r5的源码/manifest/config/control receipt，不冻结或读取正在运行的SAN pipeline为通过证据。只有SAN真正终态且完成final all-mode独立审核，root最终决定才可通过采用gate。guard的数值、两文件范围、whole包身份、full42与有限F保护逻辑未改变；r6新增的是控制生命周期与明确模式身份。

## 9. r7 最终审计与终态提交边界

r6 独立拒绝 receipt 23c145ea… 确认：build 的 state.update 参数内执行 guard.package(identity_path)，该审计在最后 raise_pending() 之后；审计期间排队的SIGINT/SIGTERM会被忽略，仍记录passed。r7只将所有最终字段预计算到final_result，包含identity SHA、完整包/recipe/worker审计及结束时间，再调用最后raise_pending()，最后state.update使用已计算字段。没有任何阻塞审计在该安全点之后执行。此安全点是终态提交的线性化边界：此前到达的取消须记录failed并保留首个信号/原始I/O异常；边界后到达的通知不回溯撤销已经完成的工作。

qualify_actual.py 与 run_replay.py 的末尾只更新有界状态、len和clock元数据，没有同类文件/包审计，源码与r6逐字相同。其非阻塞状态更新和最终save属于提交后的持久化，不被本次修改扩张为新的数值验收。

原330项fake/trace均重放；terminal_fake_tests.py另有38项，含冻结r6两项原反例、SHA/包审计/时间字段及提交前trace取消、首个审计I/O异常保持、ordinary成功、以及三runner的提交后通知控制。lifecycle-fake-evidence.json、lifecycle-trace-fake-evidence.json、admission-fake-evidence.json、mode-binding-fake-evidence.json、terminal-fake-evidence.json是本r7静态自核；以前各轮raw只引用冻结路径，不复制旧全量tree。它们不运行真实构建、安装、pytest、JIT或计算性能。

两文件范围、数学顺序、所有权、full42、有限模式r2/r3/r5、原F10源码+normalstatus保护均保持。SAN仍待真实终态，当前不执行采用gate或实际R/F变更。r7只新增必要小型helper、manifest、自审/diff与fake raw，不复制任何source/build/install/wheel/test产物目录。所有当前最终准入依赖和旧冻结证据保护；认为可清的旧冗余须先列范围和依赖，未经核对不删。
