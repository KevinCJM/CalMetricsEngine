"""Stdlib real-AST finalization with fake SHA/package audit/clock/state only."""
from pathlib import Path
import ast
import hashlib
import json
import signal
import sys
import types

HERE = Path(__file__).resolve().parent
PREVIOUS = HERE.parent / 'r6'
assert sys.flags.optimize == 0 and sys.dont_write_bytecode
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
results, checks = [], {}


def extract(name, previous=False):
    path = (PREVIOUS if previous else HERE) / name
    text = path.read_text(); tree = ast.parse(text)
    handler = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'interrupted')
    checkpoint = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'raise_pending')
    outer = next(n for n in ast.walk(tree) if isinstance(n, ast.Try) and n.col_offset == 8 and n.handlers and
                 ast.unparse(n.handlers[0].type) == 'BaseException')
    commit = outer.body[-1]
    assert isinstance(commit,ast.Expr) and ast.unparse(commit.value.func) == 'state.update'
    pending = outer.body[-2]
    assert ast.unparse(pending) == 'raise_pending()'
    start = -3 if name == 'build_actual.py' and not previous else -2
    body = outer.body[start:]
    if name == 'build_actual.py' and not previous:
        assert isinstance(body[0],ast.Assign) and ast.unparse(body[0].targets[0]) == 'final_result'
        assert ast.unparse(commit) == 'state.update(**final_result)'
        audit_calls = [n for n in ast.walk(body[0]) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and
                       ast.unparse(n.func) in ('guard.sha','guard.package')]
        assert {ast.unparse(n.func) for n in audit_calls} == {'guard.sha','guard.package'}
        assert all(n.lineno < pending.lineno for n in audit_calls)
        assert len([n for n in ast.walk(commit) if isinstance(n,ast.Call)]) == 1
    elif not previous:
        calls = [ast.unparse(n.func) for n in ast.walk(commit) if isinstance(n,ast.Call)]
        assert set(calls) <= {'state.update','len','time.time'},calls
        assert not any(s.startswith('guard.') for s in calls)
    checks[str(path)] = dict(source_sha256=sha(path),checkpoint_line=pending.lineno,commit_line=commit.lineno,
                            blocking_audit_after_boundary=previous)
    final = ast.Try(body=body,handlers=outer.handlers,orelse=[],finalbody=outer.finalbody)
    wrapper = ast.FunctionDef(name='run_final',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),
                             body=[final],decorator_list=[])
    compiled=compile(ast.fix_missing_locations(ast.Module(body=[handler,checkpoint,wrapper],type_ignores=[])),
                     str(path)+':fake-finalization-only','exec')
    return compiled,pending.lineno,commit.lineno


def simulate(name,stage,signals=(),*,previous=False,audit_error=False):
    compiled,boundary,commit=extract(name,previous)
    pending,events,ns=[],[],{}
    fired=False
    def inject(at):
        nonlocal fired
        assert not fired
        fired=True
        for s in signals:
            ns['interrupted'](s,None)
            events.append(['queued_signal',at,s])
    def fake_sha(path):
        assert str(path)=='/fake/identity.json'
        events.append(['fake_identity_SHA'])
        if stage=='identity_sha':inject(stage)
        return 'FAKE_IDENTITY_SHA'
    def fake_audit(path):
        assert str(path)=='/fake/identity.json'
        events.append(['fake_complete_package_audit'])
        if stage=='package_audit':inject(stage)
        if audit_error:raise OSError('first_fake_package_audit_failure')
        return {'whole_package_and_recipes_worker':'FAKE_CHECKED'}
    def clock():
        events.append(['fake_clock'])
        if stage=='final_clock' and not fired:inject(stage)
        return 1000.0
    state={'status':'running','jobs':[]}
    saved=[]
    def save():
        saved.append(dict(state))
        events.append(['save_status',state['status']])
        if stage=='post_commit_save' and not fired:inject(stage)
    def trace(frame,event,arg):
        if event=='line' and frame.f_code.co_name=='run_final':
            if stage=='before_boundary_trace' and frame.f_lineno==boundary and not fired:inject(stage)
            if stage=='after_boundary_before_commit_trace' and frame.f_lineno==commit and not fired:inject(stage)
        return trace
    ns.update(signal_control=dict(pending_signals=pending),state=state,save=save,identity_path=Path('/fake/identity.json'),
              guard=types.SimpleNamespace(sha=fake_sha,package=fake_audit),time=types.SimpleNamespace(time=clock),expected={'FAKE'})
    exec(compiled,ns)
    oldtrace=sys.gettrace(); error=None
    try:
        sys.settrace(trace)
        ns['run_final']()
    except BaseException as e:error=e
    finally:sys.settrace(oldtrace)
    if stage!='ordinary':assert fired,(name,stage)
    post=stage in ('after_boundary_before_commit_trace','post_commit_save')
    old_bug=previous and stage=='package_audit'
    if audit_error:
        assert isinstance(error,OSError) and str(error)=='first_fake_package_audit_failure'
        assert state['status']=='failed' and saved[-1]['status']=='failed'
    elif stage=='ordinary' or post or old_bug:
        assert error is None and state['status'].startswith('passed_') and saved[-1]['status']==state['status']
        if signals:assert pending==list(signals)
    else:
        assert isinstance(error,KeyboardInterrupt) and 'signal '+str(signals[0]) in str(error),(name,stage,repr(error))
        assert state['status']=='failed' and saved[-1]['status']=='failed'
        assert pending==list(signals[1:])
    results.append(dict(runner=name,name=stage,previous_r6=previous,signals=list(signals),audit_error=audit_error,
                        passed=True,previous_P2_reproduced=old_bug,error=repr(error) if error else None,
                        final_status=state['status'],saved_status=saved[-1]['status'],pending=list(pending),events=events,
                        post_commit_notification=post))


for sig in (signal.SIGINT,signal.SIGTERM):simulate('build_actual.py','package_audit',(sig,),previous=True)
for stage in ('identity_sha','package_audit','final_clock','before_boundary_trace'):
    for sigs in ((signal.SIGINT,),(signal.SIGTERM,),(signal.SIGINT,signal.SIGTERM)):
        simulate('build_actual.py',stage,sigs)
for sigs in ((),(signal.SIGINT,),(signal.SIGTERM,)):
    simulate('build_actual.py','package_audit',sigs,audit_error=True)
simulate('build_actual.py','ordinary')
for name in ('build_actual.py','qualify_actual.py','run_replay.py'):
    for stage in ('after_boundary_before_commit_trace','post_commit_save'):
        for sigs in ((signal.SIGINT,),(signal.SIGTERM,)):
            simulate(name,stage,sigs)
    if name!='build_actual.py':
        for sigs in ((signal.SIGINT,),(signal.SIGTERM,),(signal.SIGINT,signal.SIGTERM)):
            simulate(name,'before_boundary_trace',sigs)
        simulate(name,'ordinary')
report=dict(status='passed_stdlib_terminal_fakes_not_actual_build_or_qualification',helper_sha256=sha(__file__),
            scenarios=len(results),results=results,AST_boundary_checks=checks,previous_r6_P2_counterexamples=2,
            all_blocking_build_checks_precede_final_safe_point=True,build_commit_arguments_precomputed=True,
            terminal_safe_point_is_commit_linearization_boundary=True,post_commit_signals_do_not_retroactively_cancel=True,
            qualify_and_replay_source_unchanged=True,fake_process_calls=False,real_signal_calls=False,actual_PID_access=False,
            heavy_guard_execution=False,numerical_import=False,compilation=False,installation=False,pytest_execution=False,JIT=False,perf_execution=False)
out=HERE/'terminal-fake-evidence.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],scenarios=len(results),report_sha256=sha(out))))
