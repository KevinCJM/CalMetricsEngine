"""Stdlib in-memory admission negatives; no native/numerical import, process or signal."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import tempfile

HERE = Path(__file__).resolve().parent
assert sys.flags.optimize == 0 and sys.dont_write_bytecode
sha_file = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = (HERE / 'guard.py').read_text()
tree = ast.parse(source)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
compiled = compile(ast.fix_missing_locations(ast.Module(body=[functions[n] for n in
                   ('require', 'bound_evidence', 'snapshot_full_chain', 'admission')], type_ignores=[])),
                   str(HERE / 'guard.py') + ':AST-in-memory-admission-only', 'exec')
perf = json.loads(Path('/private/tmp/calmetrics-mc-weight-lanes-v99-20261010/candidate-performance-plan-r3/manifest.json').read_text())
old = json.loads((HERE.parent / 'r2/manifest.json').read_text())
results = []


def fixture():
    objects, hashes, ids, collection = {}, {}, {}, {}
    def register(path, obj=None):
        path = str(path)
        hashes[path] = hashlib.sha256(('FAKE_EVIDENCE:' + path).encode()).hexdigest()
        if obj is not None:
            objects[path] = obj
        return path
    plan_path = register(HERE / 'manifest.json')
    m = dict(native_after={'cpp/FAKE.cpp': 'FAKE_SOURCE_DIGEST'}, candidate_build_id=old['candidate_build_id'],
             expected_ids=dict(full=[('tests.test_FAKE', 'full')], affected=[('tests.test_FAKE', 'affected')],
                               eigen_off_affected=[('tests.test_FAKE', 'off')]), native_ids=old['native_ids'],
             candidate_full_manifest=register('/fake/full/manifest.json'), candidate_full_jobs=copy.deepcopy(perf['jobs']['full']),
             thread_environment=copy.deepcopy(perf['thread_environment']),
             candidate_full_packages=copy.deepcopy(perf['packages']), parent_full_review='/fake/review/parent.json',
             cleanup_overlap_supplement='/fake/review/cleanup-supplement.json', cleanup_overlap_pipeline='/fake/cleanup/pipeline.json')
    modes = ('normal-full', 'eigen-off', 'compact-packets-off', 'asan-ubsan')
    m['qualification_mode_plans'] = {mode: dict(proof_sha256={}) for mode in modes}
    m['fake_mode_bindings'] = {mode: dict(mode=mode, fixture='legacy_29_cases_mode_binding_tested_separately') for mode in modes}
    pipelines, mode_evidence = {}, {}
    for mode in modes:
        path = register('/fake/modes/' + mode + '/pipeline.json')
        pipelines[mode] = path
        expected = {tuple(x) for x in m['expected_ids']['full' if mode == 'normal-full' else
                    'eigen_off_affected' if mode == 'eigen-off' else 'affected']}
        jobs = []
        for label in ('collection', 'native', 'python'):
            log = register('/fake/modes/' + mode + '/' + label + '.log')
            j = dict(label=label, returncode=0, log=log, log_sha256=hashes[log])
            mode_evidence[log] = hashes[log]
            if label == 'collection':
                p = register('/fake/modes/' + mode + '/collection.json', dict(exact_expected_ids=True))
                j.update(collection=p, collection_sha256=hashes[p], exact_expected_ids=True)
                mode_evidence[p] = hashes[p]
                collection[log] = expected
            else:
                p = register('/fake/modes/' + mode + '/' + label + '.xml')
                j.update(xml=p, xml_sha256=hashes[p])
                mode_evidence[p] = hashes[p]
                ids[p] = {tuple(x) for x in m['native_ids']} if label == 'native' else expected
            jobs.append(j)
        objects[path] = dict(status='passed_qualification_independent_review_pending', mode=mode,
                             identity=dict(source=m['native_after']), jobs=jobs)
    full_path = register('/fake/full/pipeline.json')
    jobs, full_evidence = [], {full_path: hashes[full_path]}
    for number, spec in enumerate(m['candidate_full_jobs']):
        j = dict(spec, pid=424242 + number, returncode=0)
        selected = m['candidate_full_packages'][j['package']]
        log = register('/fake/full/' + j['name'] + '.log')
        raw = register('/fake/full/' + j['name'] + '.json', dict(case=j['case'], student=j['student'], cpu_budget=1,
                       backend=j['backend'], pid=j['pid'], identity=dict(build_id=selected['build_id'], build_id_verified=True)))
        if j['metric'] != 'time':
            objects[raw].pop('cpu_budget')
        launch = register('/fake/full/' + j['name'] + '.launch.json', dict(status='passed_original_driver_assertions',
                          pid=j['pid'], selected_package=j['package'], selected_identity=selected,
                          gate=dict(manifest_sha256=hashes[m['candidate_full_manifest']]),
                          environment=dict(thread_caps=m['thread_environment'], pythonoptimize_absent=True,
                                           heap_probe_injected=j['metric'] == 'heap'),
                          assertions=dict(optimize=0, assert_sentinel_raised=True)))
        j.update(log=log, log_sha256=hashes[log], output=raw, output_sha256=hashes[raw],
                 launch_evidence=launch, launch_sha256=hashes[launch])
        full_evidence.update({p: hashes[p] for p in (log, raw, launch)})
        jobs.append(j)
    objects[full_path] = dict(status='passed_full_measurements_independent_review_pending',
                             manifest_sha256=hashes[m['candidate_full_manifest']], jobs=jobs)
    parent = register(m['parent_full_review'], dict(full_pipeline_sha256=hashes[full_path]))
    cleanup_path = register(m['cleanup_overlap_pipeline'])
    original = next(j for j in jobs if j['name'] == 'student_large_c8_heap_candidate_njit')
    raw, launch, log = [register('/fake/cleanup/' + n) for n in ('measurement.json', 'launch.json', 'child.log')]
    objects[cleanup_path] = dict(status='passed_single_heap_cleanup_overlap_replay_independent_review_pending',
                                returncode=0, fresh_assertions_passed=True, full_pipeline_sha256=hashes[full_path],
                                original_job=copy.deepcopy(original), output=raw, output_sha256=hashes[raw],
                                launch=launch, launch_sha256=hashes[launch], log_sha256=hashes[log])
    supplement = register(m['cleanup_overlap_supplement'], dict(
        status='passed_independent_cleanup_overlap_heap_replay_supplement_not_adoption',
        original_full_review_sha256=hashes[parent], original_full_pipeline_sha256=hashes[full_path],
        replay_pipeline_sha256=hashes[cleanup_path], cleanup_overlap_followup_closed_for_heap_comparison=True))
    full_evidence.update({p: hashes[p] for p in (parent, supplement, cleanup_path, raw, launch, log)})
    mode_review = register('/fake/review/modes.json', dict(status='passed_independent_v99_modes_review',
                           confirmed_blockers=[], pipeline_sha256={mode: hashes[p] for mode, p in pipelines.items()},
                           mode_bindings=m['fake_mode_bindings'],
                           evidence_sha256=copy.deepcopy(mode_evidence)))
    full_review = register('/fake/review/full.json', dict(status='passed_independent_v99_full_chain_review',
                           confirmed_blockers=[], pipeline_sha256=hashes[full_path], candidate_build_id=m['candidate_build_id'],
                           parent_review_sha256=hashes[parent], cleanup_supplement_sha256=hashes[supplement],
                           evidence_sha256=copy.deepcopy(full_evidence)))
    refs = {**mode_evidence, **full_evidence, **{p: hashes[p] for p in pipelines.values()},
            mode_review: hashes[mode_review], full_review: hashes[full_review]}
    decision = register('/fake/decision.json', dict(status='reviewed_v99_adoption_ready_for_actual_rebuild', adopt_source=True,
                        plan_manifest_sha256=hashes[plan_path], candidate_build_id=m['candidate_build_id'],
                        qualification_pipelines=pipelines, all_mode_independent_review=mode_review,
                        all_mode_independent_review_passed=True, full_chain_pipeline=full_path,
                        full_chain_independent_review=full_review, full_chain_independent_review_passed=True,
                        evidence_sha256=refs, negative_results_retained=True, uncertainty_considered=True,
                        rationale='FAKE fixture only; never a real adoption decision'))
    return dict(objects=objects, hashes=hashes, ids=ids, collection=collection, m=m, decision=decision,
                pipelines=pipelines, full_path=full_path, mode_review=mode_review, full_review=full_review)


def run_case(name, mutate=None):
    f = fixture()
    if mutate:
        mutate(f)
    ns = dict(Path=Path, HERE=HERE, MODES=tuple(f['pipelines']), manifest=lambda: f['m'],
              sha=lambda p: f['hashes'][str(p)], load=lambda p: f['objects'][str(p)],
              xml_ids=lambda p: f['ids'][str(p)])
    def fake_collection(path, expected):
        if f['collection'][str(path)] != expected:
            raise RuntimeError('collection exact-ID mismatch')
    ns['collection_nodes'] = fake_collection
    ns['qualification_binding'] = lambda mode, path, q, m: m['fake_mode_bindings'][mode]
    exec(compiled, ns)
    error = None
    try:
        ns['admission'](f['decision'])
    except (RuntimeError, KeyError) as caught:
        error = caught
    assert (error is None) == (mutate is None), (name, repr(error))
    results.append(dict(name=name, passed=True, accepted=error is None, rejection=repr(error) if error else None))


run_case('complete_fake_fixture_passes')
run_case('changed_launch_SHA_rejected', lambda f: f['objects'][f['full_path']]['jobs'][0].update(launch_sha256='0' * 64))
run_case('42_duplicate_jobs_rejected', lambda f: f['objects'][f['full_path']]['jobs'].__setitem__(-1, copy.deepcopy(f['objects'][f['full_path']]['jobs'][0])))
run_case('wrong_nine_native_IDs_rejected', lambda f: f['ids'].__setitem__('/fake/modes/normal-full/native.xml', {(str(i), str(i)) for i in range(9)}))
run_case('missing_launch_SHA_rejected', lambda f: f['objects'][f['full_path']]['jobs'][0].pop('launch_sha256'))
run_case('wrong_workload_rejected', lambda f: f['objects'][f['full_path']]['jobs'][0].update(case='short_many'))
run_case('raw_wrong_case_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][0]['output']].update(case='short_many'))
run_case('raw_wrong_build_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][0]['output']]['identity'].update(build_id='0' * 64))
run_case('launch_not_terminal_PASS_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][0]['launch_evidence']].update(status='running'))
run_case('launch_wrong_PID_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][0]['launch_evidence']].update(pid=0))
run_case('launch_assertions_disabled_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][0]['launch_evidence']]['assertions'].update(optimize=1))
run_case('launch_CPU_caps_changed_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][0]['launch_evidence']]['environment'].update(thread_caps={'OMP_NUM_THREADS':'8'}))
run_case('heap_backend_mismatch_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][3]['output']].update(backend='njit'))
run_case('heap_PID_mismatch_rejected', lambda f: f['objects'][f['objects'][f['full_path']]['jobs'][3]['output']].update(pid=0))
run_case('full_review_missing_raw_binding_rejected', lambda f: f['objects'][f['full_review']]['evidence_sha256'].pop(f['objects'][f['full_path']]['jobs'][0]['output']))
run_case('decision_missing_raw_binding_rejected', lambda f: f['objects'][f['decision']]['evidence_sha256'].pop(f['objects'][f['full_path']]['jobs'][0]['output']))
run_case('mode_review_missing_XML_binding_rejected', lambda f: f['objects'][f['mode_review']]['evidence_sha256'].pop('/fake/modes/normal-full/native.xml'))
run_case('cleanup_review_stale_rejected', lambda f: f['objects'][f['full_review']].update(cleanup_supplement_sha256='0' * 64))
run_case('cleanup_followup_open_rejected', lambda f: f['objects'][f['m']['cleanup_overlap_supplement']].update(cleanup_overlap_followup_closed_for_heap_comparison=False))
run_case('cleanup_raw_changed_rejected', lambda f: f['objects'][f['m']['cleanup_overlap_pipeline']].update(output_sha256='0' * 64))
run_case('cleanup_log_changed_rejected', lambda f: f['objects'][f['m']['cleanup_overlap_pipeline']].update(log_sha256='0' * 64))
run_case('cleanup_wrong_original_job_rejected', lambda f: f['objects'][f['m']['cleanup_overlap_pipeline']]['original_job'].update(name='wrong'))
run_case('mode_duplicate_job_rejected', lambda f: f['objects'][f['pipelines']['normal-full']]['jobs'].append(copy.deepcopy(f['objects'][f['pipelines']['normal-full']]['jobs'][0])))
run_case('mode_collection_ID_mismatch_rejected', lambda f: f['collection'].__setitem__('/fake/modes/normal-full/collection.log', set()))
run_case('mode_collection_json_changed_rejected', lambda f: f['objects'][f['pipelines']['normal-full']]['jobs'][0].update(collection_sha256='0' * 64))

# Exercise the actual collection parser separately with temporary text, no pytest import/collection.
ns = dict(Path=Path)
exec(compile(ast.fix_missing_locations(ast.Module(body=[functions['require'], functions['collection_nodes']], type_ignores=[])),
             '<collection-parser-only>', 'exec'), ns)
with tempfile.TemporaryDirectory(prefix='fake-collection-', dir=HERE) as temp:
    p = Path(temp) / 'fake.log'
    for name, content, accept in [('exact_nodes', 'tests/test_FAKE.py::foo\n1 test collected\n', True),
                                  ('duplicate_nodes', 'tests/test_FAKE.py::foo\ntests/test_FAKE.py::foo\n', False),
                                  ('missing_nodes', '0 tests\n', False),
                                  ('extra_nodes', 'tests/test_FAKE.py::foo\ntests/test_FAKE.py::bar\n', False)]:
        p.write_text(content)
        error = None
        try:
            ns['collection_nodes'](p, {('tests.test_FAKE', 'foo')})
        except RuntimeError as caught:
            error = caught
        assert (error is None) == accept
        results.append(dict(name='collection_parser_' + name, passed=True, accepted=error is None,
                            rejection=repr(error) if error else None))
report = dict(status='passed_stdlib_admission_negatives_not_adoption', helper_sha256=sha_file(__file__),
              guard_sha256=sha_file(HERE / 'guard.py'), scenarios=len(results), results=results,
              direct_real_subprocess_calls=False, real_signal_calls=False, real_project_guard_called=False,
              numerical_import=False, compilation=False, install=False, pytest_execution=False, perf_execution=False,
              proof_boundary='Legacy 29 AST admission/collection cases; new mode binding is stubbed here and exercised separately by mode_binding_fake_tests.py.')
target = HERE / 'admission-fake-evidence.json'
assert not target.exists(), 'preserve immutable fake evidence'
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status=report['status'], scenarios=len(results), report=str(target), report_sha256=sha_file(target))))
