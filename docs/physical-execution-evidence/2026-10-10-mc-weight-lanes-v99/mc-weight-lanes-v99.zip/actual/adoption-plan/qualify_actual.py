"""Prepared actual installed-wheel regressions; exact collection/execution IDs."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import signal
import subprocess
import sys
import time
import guard

PYTHON = '/Users/chenjunming/Desktop/myenv_312/bin/python3.12'

def execute(scope, identity_path, attempt, decision):
    guard.require(sys.executable == PYTHON and sys.prefix == '/Users/chenjunming/Desktop/myenv_312', 'wrong venv')
    guard.require(attempt.replace('-', '').isalnum() and attempt.isascii(), 'unsafe attempt name')
    m = guard.manifest()
    admission = guard.admission(decision)
    guard.verify('code')
    package_audit = guard.package(identity_path)
    identity = guard.load(identity_path)
    guard.idle()
    with (guard.HERE / '.heavy.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        out = guard.HERE / ('actual-qualification-' + attempt)
        out.mkdir(exist_ok=False)
        expected = {tuple(x) for x in m['expected_ids']['full' if scope == 'full' else 'affected']}
        modules = ['tests'] if scope == 'full' else ['tests/test_compact_weight_lanes.py'] + m['related_modules']
        env = dict(os.environ, PYTHONPATH=identity['installed'], PYTHONDONTWRITEBYTECODE='1',
                   PATH='/opt/homebrew/bin:/usr/bin:/bin', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
                   VECLIB_MAXIMUM_THREADS='1', NUMBA_NUM_THREADS='1', MKL_NUM_THREADS='1', LC_ALL='C',
                   CALMETRICS_TEST_EXPECT_ACCELERATE='1', CALMETRICS_TEST_EXPECT_EIGEN='1',
                   CME_EXPECT_ACCELERATE='1', CME_EXPECT_EIGEN='1', CME_EXPECT_HIGHWAY='1', CME_EXPECT_WEIGHT_LANES='1')
        for key in ('PYTHONOPTIMIZE', 'DYLD_INSERT_LIBRARIES', 'PYTEST_ADDOPTS'):
            env.pop(key, None)
        state = dict(status='running', scope=scope, pid=os.getpid(), started_epoch=time.time(), jobs=[],
                     identity=str(Path(identity_path).resolve()), identity_sha256=guard.sha(identity_path),
                     package_audit=package_audit, admission=admission, source_adopted=True, goal_complete=False)
        target = out / 'pipeline.json'
        def save():
            state['heartbeat_epoch'] = time.time()
            tmp = target.with_suffix('.tmp.json')
            tmp.write_text(json.dumps(state, indent=2) + '\n')
            tmp.replace(target)
        signal_control = dict(pending_signals=[])
        def interrupted(signum, _):
            # Queue only: never raise between child creation, registration or cleanup instructions.
            signal_control['pending_signals'].append(signum)
        def raise_pending():
            if signal_control['pending_signals']:
                signum = signal_control['pending_signals'].pop(0)
                raise KeyboardInterrupt('actual runner interrupted by signal ' + str(signum))
        signal.signal(signal.SIGTERM, interrupted)
        signal.signal(signal.SIGINT, interrupted)
        save()
        jobs = [
            ('collection', [PYTHON, '-B', '-m', 'pytest', *modules, '--collect-only', '-q', '--color=no']),
            ('native', ['/opt/homebrew/bin/ctest', '--test-dir', identity['build'], '--output-on-failure']),
            ('python', [PYTHON, '-B', '-m', 'pytest', *modules, '-q', '--tb=short', '--color=no']),
        ]
        try:
            raise_pending()
            for label, cmd in jobs:
                guard.verify('code')
                guard.package(identity_path)
                guard.idle()
                log, xml = out / (label + '.log'), out / (label + '.xml')
                if label != 'collection':
                    cmd += ['--output-junit', str(xml)] if label == 'native' else ['--junitxml=' + str(xml)]
                with log.open('x') as stream:
                    child = None
                    try:
                        raise_pending()
                        child = subprocess.Popen(cmd, cwd=guard.R, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                                 start_new_session=True)
                        state['current'] = dict(label=label, pid=child.pid, command=cmd, log=str(log), started_epoch=time.time())
                        raise_pending()
                        save()
                        raise_pending()
                        print('START actual', scope, label, child.pid, flush=True)
                        raise_pending()
                        heartbeat = time.monotonic()
                        while child.poll() is None:
                            raise_pending()
                            try:
                                child.wait(timeout=0.25)
                            except subprocess.TimeoutExpired:
                                pass
                            raise_pending()
                            if time.monotonic() - heartbeat >= 2:
                                save()
                                heartbeat = time.monotonic()
                            raise_pending()
                        raise_pending()
                        child.wait()
                        raise_pending()
                    except BaseException:
                        if child is None:
                            state['interrupted_child'] = dict(created=False, pid=None, returncode=None)
                        else:
                            if child.poll() is None:
                                try:
                                    os.killpg(child.pid, signal.SIGTERM)
                                except ProcessLookupError:
                                    pass
                                try:
                                    child.wait(timeout=5)
                                except subprocess.TimeoutExpired:
                                    try:
                                        os.killpg(child.pid, signal.SIGKILL)
                                    except ProcessLookupError:
                                        pass
                                    child.wait()
                            else:
                                child.wait()
                            state['interrupted_child'] = dict(created=True, pid=child.pid, returncode=child.returncode)
                        if signal_control['pending_signals']:
                            state['cleanup_deferred_signals'] = list(signal_control['pending_signals'])
                        raise
                j = dict(label=label, returncode=child.returncode, log=str(log), log_sha256=guard.sha(log),
                         command=cmd, finished_epoch=time.time())
                if xml.exists():
                    j.update(xml=str(xml), xml_sha256=guard.sha(xml))
                state['jobs'].append(j)
                state.pop('current', None)
                save()
                guard.require(child.returncode == 0, 'actual regression failed: ' + label)
                if label == 'collection':
                    nodes = {line.strip() for line in log.read_text(errors='replace').splitlines()
                             if line.startswith('tests/') and '::' in line}
                    def node(case):
                        klass, name = case
                        parts = klass.split('.')
                        return 'tests/' + parts[1] + '.py::' + '::'.join(parts[2:] + [name])
                    guard.require(nodes == {node(x) for x in expected}, 'actual collected IDs differ')
                    j.update(count=len(nodes), exact_expected_ids=True)
                else:
                    actual = guard.xml_ids(xml)
                    if label == 'python':
                        guard.require(actual == expected, 'actual executed Python IDs differ')
                    else:
                        guard.require(actual == {tuple(x) for x in m['native_ids']}, 'actual native exact IDs differ')
                    j.update(tests=len(actual), ids_sha256=guard.ids_digest(actual), failures=0, errors=0, skips=0)
                save()
                guard.verify('code')
            raise_pending()
            state.update(status='passed_actual_qualification_independent_review_pending', unique_python_tests=len(expected),
                         unique_native_tests=9, finished_epoch=time.time(), actual_package_rebuilt=True)
        except BaseException as error:
            state.update(status='failed', error=repr(error), finished_epoch=time.time())
            raise
        finally:
            save()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--execute', action='store_true')
    p.add_argument('--scope', choices=('affected', 'full'))
    p.add_argument('--identity')
    p.add_argument('--attempt')
    p.add_argument('--adoption-decision')
    args = p.parse_args()
    if args.execute:
        guard.require(all([args.scope, args.identity, args.attempt, args.adoption_decision]), 'explicit actual qualification args required')
        execute(args.scope, args.identity, args.attempt, args.adoption_decision)
    else:
        print(json.dumps(dict(status='prepared_not_executed', affected_expected=1049, full_expected=17179,
                              native_expected=9, counts_do_not_replace_exact_ids=True)))
