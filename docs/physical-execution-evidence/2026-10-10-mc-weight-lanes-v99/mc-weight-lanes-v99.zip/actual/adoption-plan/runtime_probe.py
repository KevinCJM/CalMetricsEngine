"""Future actual package smoke. Never imported by preparation or read-only guards."""
from pathlib import Path
import json
import sys

install = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(install))
import numpy as np
import calmetrics_engine as package

assert Path(package.__file__).resolve() == install / 'calmetrics_engine/__init__.py'
assert sys.flags.optimize == 0
graph = package.GraphCompiler({'x': 'series'}).compile('sum(x)')
with package.AdaptiveScheduler(cpu_budget=1) as scheduler:
    result = scheduler.execute(graph, {'x': np.array([1.])}, np.array([0], np.int64), np.array([1], np.int64))
    assert result.audit['python_fallback'] == 0
    assert result.audit['request_time_compilation'] == 0
    print(json.dumps(dict(build_info=package.build_info(), engine_build_id=result.audit['engine_build_id'],
                         package_path=str(Path(package.__file__).resolve()), optimize=sys.flags.optimize)))
