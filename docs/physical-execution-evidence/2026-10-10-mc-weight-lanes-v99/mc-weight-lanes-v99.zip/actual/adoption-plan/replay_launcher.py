"""Future unchanged-driver invocation. Heavy source/wheel guards stay in parent."""
from pathlib import Path
import argparse
import hashlib
import importlib
import json
import os
import runpy
import sys
import time

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def require(value, message):
    if not value:
        raise RuntimeError(message)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--package', choices=('actual79', 'actual99'), required=True)
    p.add_argument('--metric', choices=('time', 'heap', 'rss'), required=True)
    p.add_argument('--launch-evidence', type=Path, required=True)
    p.add_argument('driver_args', nargs=argparse.REMAINDER)
    args = p.parse_args()
    m = json.loads(args.manifest.read_text())
    selected = m['packages'][args.package]
    require(sys.flags.optimize == 0 and sys.dont_write_bytecode and 'PYTHONOPTIMIZE' not in os.environ,
            'assertions/bytecode policy differs')
    try:
        assert False, 'sentinel'
    except AssertionError:
        pass
    else:
        raise RuntimeError('assertions omitted')
    require(os.environ['CME_PERF_PARENT_GUARD_MANIFEST_SHA'] == sha(args.manifest), 'parent guard token differs')
    require(os.environ['CME_OWNED_SOURCE_ROOT'] == selected['source'] and
            os.environ['CME_OWNED_INSTALL'] == selected['install'], 'selected source/package differs')
    for name in m['thread_environment']:
        require(os.environ.get(name) == '1', 'thread cap differs: ' + name)
    require(os.environ.get('DYLD_INSERT_LIBRARIES') == (m['probe'] if args.metric == 'heap' else None),
            'probe injection scope differs')
    for name, expected in m['lightweight_files_sha256'].items():
        require(sha(name) == expected, 'launcher/support source changed')
    require(not args.launch_evidence.exists(), 'preserve previous launch evidence')
    evidence = dict(status='running', pid=os.getpid(), started_epoch=time.time(), selected_package=args.package,
                    selected_identity=selected, assertions=dict(optimize=0, sentinel_raised=True),
                    heavy_proof_in_parent_only=True, unchanged_numerical_driver=True)
    def save():
        temp = args.launch_evidence.with_suffix('.tmp.json')
        temp.write_text(json.dumps(evidence, indent=2) + '\n')
        temp.replace(args.launch_evidence)
    save()
    try:
        os.environ['CME_MC_SOURCE_ROOT'] = selected['source']
        os.environ['CME_MC_EXPECT_BUILD_ID'] = selected['build_id']
        sys.path.insert(0, m['original_support'])
        rs = importlib.import_module('raw_support')
        snapshot = Path(m['support_snapshot'])
        rs.old.HERE = snapshot
        rs.old.production_reference.DESTINATION = snapshot / 'production_signature_kernels.py'
        rs.transform_reference.DEST = snapshot / 'transform_signature_kernel.py'
        evidence['cache_path_adaptation'] = ['production_bench_support.HERE',
            'production_reference.DESTINATION', 'transform_reference.DEST']
        save()
        path = m['drivers']['rss' if args.metric == 'rss' else 'owned']['path']
        sys.path.insert(0, str(Path(path).parent))
        rest = args.driver_args[1:] if args.driver_args[:1] == ['--'] else args.driver_args
        sys.argv = [path, *rest]
        runpy.run_path(path, run_name='__main__')
        evidence.update(status='passed_original_driver_assertions', finished_epoch=time.time())
    except BaseException as error:
        evidence.update(status='failed', error=repr(error), finished_epoch=time.time())
        raise
    finally:
        save()

if __name__ == '__main__':
    main()
