"""Explicit complete fixed-tape AST consumer; no FIRP runtime dependency.

This validation adapter uses the frozen CME test template/oracle. Construction,
reference checks and Python output assembly are outside native numeric timing
unless the driver explicitly includes them. It never implements an engine
operator/planner or imports the upstream project. Large ordinary execution is
not a benchmark until bounded compact execution is admitted.
"""

from __future__ import annotations

import hashlib
import importlib.util
from pathlib import Path

import numpy as np

from calmetrics_engine import AdaptiveScheduler


TEST_HELPER = Path("/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine/tests/test_mc_compact_graph.py")
TEST_HELPER_SHA256 = "ce9390dfec5378b7022102575233c9d871a54c1a90290978b7e42d0831e697af"
FIRP_FROZEN_SOURCE_SHA256 = "bb53056653d697c698dab4ac5e716d96dbaec9071157d755c3fbef32e9831b79"


def load_template(path=TEST_HELPER, *, expected_sha=TEST_HELPER_SHA256):
    path = Path(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_sha, "template identity changed"
    spec = importlib.util.spec_from_file_location("cme_compact_frozen_template", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.FROZEN_SOURCE_SHA256 == FIRP_FROZEN_SOURCE_SHA256
    return module


class CompactConsumer:
    def __init__(self, data, *, source="tape", n0=1., target=.1, order="C", cpu_budget=1,
                 helper_path=TEST_HELPER, helper_sha=TEST_HELPER_SHA256, error_policy="raise"):
        self.helper_path = Path(helper_path)
        self.template = load_template(self.helper_path, expected_sha=helper_sha)
        if source == "tape":
            steps, paths, _ = data["x"].shape
            assets, _ = data["beta"].shape
            weights = data["weights"]
            combinations = len(weights)
            self.inputs = {"x": data["x"], "beta": data["beta"], "initial": data["initial"]}
            self.inputs.update({f"w{index}": value for index, value in enumerate(weights)})
        elif source == "period":
            periods = data["periods"]  # Each explicit array has [time,path] axes.
            steps, paths = periods[0].shape
            assets, combinations = 0, len(periods)
            self.inputs = {f"period{index}": value for index, value in enumerate(periods)}
        else:
            raise ValueError("source must be tape or period")
        self.inputs.update(self.template.probability_inputs())
        self.spec = self.template.compact_spec(steps, paths, assets, combinations, source=source)
        self.graph = self.template.compile_compact(self.spec, order=order, error_policy=error_policy)
        self.parameters = {"n0": float(n0), "target": float(target)}
        self.starts, self.ends = np.array([0], np.int64), np.array([steps], np.int64)
        self.scheduler = AdaptiveScheduler(cpu_budget=cpu_budget)
        self.prepared = None

    def close(self):
        self.prepared = None
        self.scheduler.close()

    def plan(self, **kwargs):
        return self.scheduler.plan(self.graph, self.inputs, self.starts, self.ends, **kwargs)

    def run(self, **kwargs):
        return self.scheduler.execute(self.graph, self.inputs, self.starts, self.ends,
                                      parameters=self.parameters, **kwargs)

    def prepare(self, **kwargs):
        self.prepared = self.scheduler.prepare_execution(
            self.graph, self.inputs, self.starts, self.ends, parameters=self.parameters, **kwargs)
        return self.prepared

    def expected_small(self):
        # Scalar-loop correctness oracle only, never the large performance
        # reference or an ordinary native fallback. Source faults are excluded.
        return self.template.expected_named(self.spec, self.inputs, **self.parameters)

    def compare(self, result, expected, *, exact=False):
        self.template.compare_named(result, expected, exact=exact)

    def compact_arrays(self, result):
        """Reference tuple mapping: fan, 14 metrics, samples, A contributions.

        All native statistics remain separate named roots with their own types.
        This optional validation/egress assembly allocates small float vectors;
        include it on both sides if the chosen interface-level timing uses it.
        """
        output = []
        for combination in range(self.spec["combinations"]):
            named = result.named_outputs
            fan = named[f"fan_{combination}"].values[0]
            samples = named[f"samples_{combination}"].values[0]
            metrics = np.array([named[f"stat_{combination}_{field}"].values[0]
                                for field in self.template.METRIC_FIELDS], np.float64)
            contributions = np.array([named[f"contribution_{combination}_{asset}"].values[0]
                                      for asset in range(self.spec["assets"])], np.float64)
            output.append((fan, metrics, samples, contributions))
        return output

    def identity(self):
        return dict(template_sha256=hashlib.sha256(self.helper_path.read_bytes()).hexdigest(),
                    frozen_upstream_source_sha256=FIRP_FROZEN_SOURCE_SHA256,
                    graph_fingerprint=self.graph.fingerprint, shapes={
                        key: tuple(value.shape) for key, value in self.inputs.items()},
                    scope="successful_fixed_transformed_tape_compact_numeric_consumer",
                    excluded=["coverage", "old_seed", "covariance_root", "factor_transform",
                              "limits", "json", "stage_ordered_first_fault"])
