"""Root-run exact fixed-signature transform extraction; never production runtime."""
from pathlib import Path
import ast,hashlib,importlib.util,sys,time
SOURCE=Path('/Users/chenjunming/Desktop/KevinGit/CppCalAST/FundInvestmentResearchPlatform/backend/scenario_stress/numba_kernels.py')
EXPECTED='bb53056653d697c698dab4ac5e716d96dbaec9071157d755c3fbef32e9831b79'
DEST=Path(__file__).resolve().parent/'transform_signature_kernel.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def astsha(n):return hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()
def load():
    assert sha(SOURCE)==EXPECTED
    tree=ast.parse(SOURCE.read_bytes())
    aliases=[n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('_F64_1D','_F64_2D','_F64_3D')]
    function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='transform_factor_draws_kernel')
    text='from __future__ import annotations\nimport numpy as np\nfrom numba import njit,types\n\n'+'\n\n'.join(ast.unparse(n) for n in [*aliases,function])+'\n'
    parsed=ast.parse(text)
    fn=next(n for n in parsed.body if isinstance(n,ast.FunctionDef));assert astsha(fn)==astsha(function)
    assert [astsha(n) for n in parsed.body if isinstance(n,ast.Assign)]==[astsha(n) for n in aliases]
    if DEST.exists():assert DEST.read_text()==text
    else:DEST.write_text(text)
    spec=importlib.util.spec_from_file_location('raw_transform_fixed_signature',DEST)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    start=time.perf_counter_ns();spec.loader.exec_module(module);ms=(time.perf_counter_ns()-start)/1e6
    dispatcher=module.transform_factor_draws_kernel;dispatcher.disable_compile()
    assert len(dispatcher.signatures)==len(dispatcher.nopython_signatures)==1 and not dispatcher._can_compile
    return module,dict(upstream_sha256=EXPECTED,complete_function_and_decorator_ast_identical=True,function_ast_sha256=astsha(function),
        alias_ast_sha256={n.targets[0].id:astsha(n) for n in aliases},extracted_sha256=sha(DEST),extractor_sha256=sha(__file__),
        explicit_writable_C_signature_preserved=True,eager_load_ms_excluded=ms,production_runtime_imported=False,
        error_model='source omits error_model; current Numba python default is retained',targetoptions=dict(dispatcher.targetoptions),
        signature=[str(s) for s in dispatcher.signatures],request_compilation_disabled=True)
