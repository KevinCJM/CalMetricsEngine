"""Controlled complete fixed-tape reference and native validation adapters.

Never imported by the production engine. Numerical imports and execution are
performed only when the root agent launches a driver. The upstream runtime is
never imported, and the large hand-written Python oracle is never called.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("CME_MC_SOURCE_ROOT", "/Users/chenjunming/Desktop/KevinGit/CppCalAST/CalMetricsEngine")).resolve()
UPSTREAM = Path("/Users/chenjunming/Desktop/KevinGit/CppCalAST/FundInvestmentResearchPlatform/backend/scenario_stress/numba_kernels.py")
UPSTREAM_SHA = "bb53056653d697c698dab4ac5e716d96dbaec9071157d755c3fbef32e9831b79"
PROJECTION_SHA = "2fbe9575318b3c7432d581d8cb16047a8e2b49e24e022538564160f0f69219e5"
NAV_FAN_SHA = "45e2ff60a55291697b55796725f79e96fff8ede8a1a3f89e758faa141d307c7f"
CONSUMER_SHA = "51ae6edde13686a1ed7fc1fceeae03a7f185f9c840633d75081b374a67b5985f"
TEMPLATE_SHA = "ce9390dfec5378b7022102575233c9d871a54c1a90290978b7e42d0831e697af"
HEAP_HELPER_SHA = "b3862bb22e58f01f874bad0fd8466a3eb63ac4f3803186846184aafb47f4d7f8"
HEAP_PROBE_SOURCE_SHA = "4fd0d0dd27b3b7eca07a2ffce20866628540293adbaf225f397d8cb89a07d64c"
HEAP_PROBE_BINARY_SHA = "cb63a1888c89c28687e704e251d63146ff4ad32f77f5f482cd905ae19bdd95b0"
SCOPE = "successful_fixed_transformed_tape_projection_nav_fan_14stats_12samples_asset_contributions"
EXCLUDED = ["coverage", "old_random_stream", "covariance_root", "factor_transform",
            "limits", "JSON_packaging", "stage_ordered_first_fault_prefix"]
CASES = {
    "large_c1": dict(steps=200, paths=10000, factors=4, assets=32, combinations=1, tier="large"),
    "large_c8": dict(steps=200, paths=10000, factors=4, assets=32, combinations=8, tier="large"),
    "short_many": dict(steps=5, paths=50000, factors=32, assets=32, combinations=32, tier="large_short_wide_horizon"),
    "micro_tiny": dict(steps=3, paths=8, factors=4, assets=3, combinations=1, tier="diagnostic_only"),
}


def pin_threads():
    for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
                "MKL_NUM_THREADS", "NUMBA_NUM_THREADS", "BLIS_NUM_THREADS"):
        os.environ[key] = "1"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(131072), b""):
            digest.update(block)
    return digest.hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, Path(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verified_identity(manifest_path, install, package):
    import json

    expected_id = os.environ.get("CME_MC_EXPECT_BUILD_ID")
    if (not expected_id or len(expected_id) != 64 or
            any(character not in "0123456789abcdef" for character in expected_id)):
        raise RuntimeError("CME_MC_EXPECT_BUILD_ID must identify the newly built compact wheel")
    manifest_path, install = Path(manifest_path).resolve(), Path(install).resolve()
    manifest = json.loads(manifest_path.read_text())
    if manifest["build_id"] != expected_id:
        raise RuntimeError("manifest is not the explicitly selected new build")
    sources = {name: sha(ROOT / name) for name in manifest["source"]}
    actual_names = {str(path.relative_to(ROOT)) for path in (ROOT / "cpp").rglob("*") if path.is_file()}
    actual_names.update(("CMakeLists.txt", "pyproject.toml"))
    if set(sources) != actual_names or sources != manifest["source"]:
        raise RuntimeError("complete current C++/CMake source identity mismatch")
    native = Path(package._native.__file__).resolve()
    if not native.is_relative_to(install):
        raise RuntimeError("native extension was loaded from another installation")
    binaries = {name: sha(install / name) for name in manifest["installed_binaries"]}
    relative_native = str(native.relative_to(install))
    if (binaries != manifest["installed_binaries"] or relative_native not in binaries or
            binaries[relative_native] != sha(native)):
        raise RuntimeError("native/worker installed binary identity mismatch")
    return dict(build_id=expected_id, build_id_verified=True, source_root=str(ROOT),
                manifest_path=str(manifest_path), manifest_sha256=sha(manifest_path),
                native_path=str(native), installed_binary_sha256=binaries,
                source_sha256=sources, source_count=len(sources),
                compiler=manifest.get("compiler"), wheel_sha256=manifest.get("wheel_sha256"))


def load_runtime(install, manifest):
    pin_threads()
    install = Path(install).resolve()
    if not (install / "calmetrics_engine").is_dir():
        raise RuntimeError("selected installed package is missing")
    sys.path.insert(0, str(install))
    import numpy as np
    import calmetrics_engine as package
    import numba
    from numba import set_num_threads

    set_num_threads(1)
    identity = verified_identity(manifest, install, package)
    paths = {"projection": HERE / "frozen_projection.py", "nav_fan": HERE / "frozen_nav_fan.py",
             "consumer": HERE / "compact-consumer.py", "template": ROOT / "tests/test_mc_compact_graph.py"}
    expected = dict(projection=PROJECTION_SHA, nav_fan=NAV_FAN_SHA,
                    consumer=CONSUMER_SHA, template=TEMPLATE_SHA)
    if {name: sha(path) for name, path in paths.items()} != expected or sha(UPSTREAM) != UPSTREAM_SHA:
        raise RuntimeError("frozen reference/template/upstream identity changed")
    original = ast.parse(UPSTREAM.read_text())
    original_functions = {node.name: node for node in original.body if isinstance(node, ast.FunctionDef)}
    bodies = {}
    for filename, names in ((paths["projection"], {"frozen_one": "monte_carlo_projection_kernel"}),
                            (paths["nav_fan"], {name: name for name in (
                                "returns_to_nav_kernel", "quantile_sorted_kernel", "fan_statistics_kernel")})):
        frozen = {node.name: node for node in ast.parse(filename.read_text()).body
                  if isinstance(node, ast.FunctionDef)}
        for frozen_name, original_name in names.items():
            # Decorator/cache location and projection function name differ;
            # the complete mathematical statement tree must be identical.
            left = ast.dump(ast.Module(body=frozen[frozen_name].body, type_ignores=[]), include_attributes=False)
            right = ast.dump(ast.Module(body=original_functions[original_name].body, type_ignores=[]), include_attributes=False)
            if left != right:
                raise RuntimeError("NJIT mathematical body differs: " + original_name)
            bodies[original_name] = hashlib.sha256(left.encode()).hexdigest()
    projection = load_module("compact_frozen_projection", paths["projection"])
    nav_fan = load_module("compact_frozen_nav_fan", paths["nav_fan"])
    consumer = load_module("compact_complete_consumer", paths["consumer"])
    reference = ReferenceRunner(projection, nav_fan)
    evidence = dict(upstream_path=str(UPSTREAM), upstream_sha256=UPSTREAM_SHA,
                    frozen_file_sha256=expected, mathematical_ast_sha256=bodies,
                    mathematical_bodies_identical=True, support_sha256=sha(__file__),
                    runtime_versions=dict(numpy=np.__version__, numba=numba.__version__, python=sys.version),
                    reference_compilation="lazy frozen NJIT decorators, fastmath=False; upstream runtime is not imported",
                    original_quantile_inline_policy="upstream inline=always; frozen historical evidence decorator is lazy default")
    return np, package, consumer, reference, identity, evidence


def inputs(np, case, seed=17):
    dimensions = dict(CASES[case]) if isinstance(case, str) else dict(case)
    t, p, f, a, c = (dimensions[key] for key in ("steps", "paths", "factors", "assets", "combinations"))
    if min(t, p, f, a, c) < 1 or t * p * f > 8_000_000:
        raise ValueError("fixture is outside the frozen successful transformed-tape scope")
    rng = np.random.default_rng(seed)
    data = dict(dimensions, n=t * p, seed=seed,
                x=rng.normal(0., .01, size=(t, p, f)), beta=rng.normal(0., .08, size=(a, f)),
                initial=rng.normal(0., .0002, size=a), weights=rng.uniform(.1, 1., size=(c, a)))
    for row in data["weights"]:
        row /= row.sum()
    for name in ("x", "beta", "initial", "weights"):
        data[name].flags.writeable = False
    data["available"] = np.ones(a, np.uint8)
    data["available"].flags.writeable = False
    return data


def input_fingerprints(data):
    # Fixed fixtures are C-contiguous. No 64MB tobytes copy is made for hashing.
    return {key: hashlib.sha256(memoryview(data[key]).cast("B")).hexdigest()
            for key in ("x", "beta", "initial", "weights", "available")}


def common_input_bytes(data):
    return sum(data[name].nbytes for name in ("x", "beta", "initial", "weights"))


class ReferenceRunner:
    def __init__(self, projection, nav_fan):
        self.projection, self.nav_fan = projection, nav_fan

    def run(self, data):
        # Preserve the actual per-combination source call order and its result
        # replacement lifetime. No shared/full-L/R NJIT tensor is introduced.
        results = []
        for combination in range(data["combinations"]):
            period, contribution, status, _, _, _ = self.projection.frozen_one(
                data["x"], data["beta"], data["initial"], data["weights"][combination], data["available"])
            if status:
                raise RuntimeError("REFERENCE_OUTSIDE_SUCCESSFUL_PROJECTION_SCOPE")
            nav, terminal, drawdowns, status, _, _, _ = self.nav_fan.returns_to_nav_kernel(period, 1.)
            if status:
                raise RuntimeError("REFERENCE_OUTSIDE_SUCCESSFUL_NAV_SCOPE")
            fan, metrics = self.nav_fan.fan_statistics_kernel(nav, terminal, drawdowns, .1)
            samples = nav[:min(12, data["paths"])].copy()
            results.append((fan, metrics, samples, contribution))
        return results

    def signatures(self):
        return {name: [str(signature) for signature in getattr(module, name).signatures]
                for module, names in ((self.projection, ("frozen_one",)),
                                      (self.nav_fan, ("returns_to_nav_kernel", "quantile_sorted_kernel", "fan_statistics_kernel")))
                for name in names}


class NativeBundle:
    __slots__ = ("raw", "compact")

    def __init__(self, raw, compact):
        self.raw, self.compact = raw, compact


class NativeRunner:
    def __init__(self, module, data, mode="ordinary", order="C"):
        self.data, self.mode = data, mode
        self.consumer = module.CompactConsumer(data, order=order, cpu_budget=1,
                                               helper_path=ROOT / "tests/test_mc_compact_graph.py",
                                               helper_sha=TEMPLATE_SHA)
        self.input_hashes = {key: hashlib.sha256(memoryview(value).cast("B")).hexdigest()
                             for key, value in self.consumer.inputs.items()}
        try:
            self.plan = self.consumer.plan()
            if "bounded_compact_scan_consumer_closure" not in self.plan.reason_codes:
                raise RuntimeError("compact budget proof missing; refuse a large canonical R/NAV materialization")
            if self.plan.lane != "single" or self.plan.cpu_budget != 1:
                raise RuntimeError("same-core complete comparison requires CPU1/single")
            self.prepared = self.consumer.prepare(plan=self.plan) if mode == "prepared_snapshot" else None
        except BaseException:
            self.consumer.close()
            raise

    def run(self):
        raw = self.prepared.run_snapshot() if self.prepared is not None else self.consumer.run()
        # Complete numerical egress on both sides: fan, metrics, samples,
        # contributions. Packing is a small interface adapter, not mathematics.
        return NativeBundle(raw, self.consumer.compact_arrays(raw))

    def close(self):
        self.prepared = None
        self.consumer.close()

    def verify_inputs(self):
        hashes = {key: hashlib.sha256(memoryview(value).cast("B")).hexdigest()
                  for key, value in self.consumer.inputs.items()}
        if hashes != self.input_hashes:
            raise AssertionError("native readonly model/tape/weights/probability input changed")
        return hashes


def arrays(result):
    return result.compact if isinstance(result, NativeBundle) else result


def flattened_arrays(result):
    return [array for combination in arrays(result) for array in combination]


def payload_hash(result):
    digest = hashlib.sha256()
    for array in flattened_arrays(result):
        digest.update(str((array.shape, str(array.dtype))).encode())
        digest.update(memoryview(array.ravel(order="K")).cast("B"))
    return digest.hexdigest()


def independent(np, previous, current):
    left, right = flattened_arrays(previous), flattened_arrays(current)
    if len(left) != len(right):
        raise AssertionError("retained-result schema changed")
    for a, b in zip(left, right, strict=True):
        if np.shares_memory(a, b):
            raise AssertionError("previous/current compact results alias")
        np.testing.assert_array_equal(a, b)
    if isinstance(previous, NativeBundle):
        # Typed results deliberately have no flat .values interface. Check
        # native scalar roots too: compact egress copies those into vectors.
        for old, new in zip(previous.raw.outputs, current.raw.outputs, strict=True):
            for a, b in zip(old.values, new.values, strict=True):
                if np.shares_memory(a, b):
                    raise AssertionError("previous/current native typed root owners alias")


def native_audit(np, runner, result):
    audit = dict(result.raw.audit)
    if audit["engine_build_id"] != os.environ["CME_MC_EXPECT_BUILD_ID"]:
        raise AssertionError("actual executing binary build ID differs")
    if audit["result_lifetime"] != "independent":
        raise AssertionError("borrowed result is outside the benchmark contract")
    for key in ("python_fallback", "python_operator_calls", "request_time_compilation", "python_worker_callbacks"):
        if audit[key]:
            raise AssertionError("unexpected Python/JIT execution: " + key)
    if audit["cpu_budget"] != 1 or audit["process_count"] != 1 or audit["thread_count"] != 1:
        raise AssertionError("comparison must use the same single-core budget")
    if "bounded_compact_scan_consumer_closure" not in audit["reason_codes"]:
        raise AssertionError("actual native plan lacks compact admission proof")
    chunks = audit["native_chunks"]
    groups = sum(chunk["compact_path_groups"] for chunk in chunks)
    batches = sum(chunk["compact_path_batches"] for chunk in chunks)
    steps = sum(chunk["compact_path_steps"] for chunk in chunks)
    interval_rows = len(runner.consumer.starts)
    if (groups != runner.data["combinations"] * interval_rows or
            not interval_rows <= batches <= groups or
            steps != runner.data["steps"] * batches):
        raise AssertionError("dedicated compact execution counters do not prove the selected chain")
    direct_minimum = sum(row[0].nbytes + row[2].nbytes for row in result.compact)
    if sum(chunk["direct_output_bytes"] for chunk in chunks) < direct_minimum:
        raise AssertionError("fan/samples were not written into independent roots")
    components = {key: max((chunk[key] for chunk in chunks), default=0) for key in (
        "operator_workspace_capacity_bytes", "numeric_arena_bytes", "mask_arena_bytes", "order_scratch_capacity_bytes")}
    if components["operator_workspace_capacity_bytes"] > runner.plan.estimated_worker_scratch_bytes:
        raise AssertionError("actual stream/post operator capacity exceeds Planner bound")
    if sum(components.values()) > runner.plan.estimated_worker_scratch_bytes:
        raise AssertionError("actual stream/post workspaces exceed Planner bound: " + str(components))
    roots = result.raw.named_outputs
    if list(roots) != list(runner.consumer.spec["expressions"]):
        raise AssertionError("complete named-root schema differs")
    for name, output in roots.items():
        np.testing.assert_array_equal(output.root_statuses, [0], err_msg=name)
        if not output.shape_known[0] or output.values[0].flags.writeable:
            raise AssertionError("healthy native root must have known shape and readonly ownership")
        if output.statuses[0] is not None:
            np.testing.assert_array_equal(output.statuses[0], 0, err_msg=name)
    return dict(audit=audit, plan=runner.plan.metadata(), proof=dict(groups=groups, batches=batches, steps=steps),
                audited_workspace_components=components, audited_workspace_sum_bytes=sum(components.values()),
                stream_plus_descriptor_capacity_bytes=max((chunk["pointwise_workspace_capacity_bytes"] for chunk in chunks), default=0),
                workspace_component_scope="operator + numeric + mask + order capacities; stream-plus-descriptor overlaps operator and is reported separately",
                logical_native_root_payload_bytes=sum(output.values[0].nbytes for output in roots.values()),
                compact_egress_payload_bytes=sum(value.nbytes for value in flattened_arrays(result)),
                compact_evidence="dedicated counters plus Planner bounded-consumer reason")


def compare_complete(np, runner, native, expected, rtol=2e-12, atol=2e-13):
    evidence = native_audit(np, runner, native)
    named = native.raw.named_outputs
    targets = {}
    fields = runner.consumer.template.METRIC_FIELDS
    for combination, (fan, metrics, samples, contributions) in enumerate(expected):
        targets[f"fan_{combination}"] = fan
        targets[f"samples_{combination}"] = samples
        for field, value in zip(fields, metrics, strict=True):
            targets[f"stat_{combination}_{field}"] = np.asarray(value, np.float64)
        for asset, value in enumerate(contributions):
            targets[f"contribution_{combination}_{asset}"] = np.asarray(value, np.float64)
    if set(named) != set(targets):
        raise AssertionError("reference is missing a complete public root")
    parity = {}
    for name, target in targets.items():
        value = named[name].values[0]
        if value.shape != target.shape or value.dtype != target.dtype:
            raise AssertionError("shape/dtype differs: " + name)
        for classify in (np.isnan, np.isposinf, np.isneginf):
            np.testing.assert_array_equal(classify(value), classify(target), err_msg=name)
        if name.endswith(("loss_probability", "target_hit_probability")):
            np.testing.assert_array_equal(value, target, err_msg=name)
        else:
            np.testing.assert_allclose(value, target, rtol=rtol, atol=atol, equal_nan=True, err_msg=name)
        parity[name] = dict(shape=list(value.shape), dtype=str(value.dtype), nbytes=value.nbytes,
                            max_absolute_error=float(np.abs(value - target).max(initial=0)))
    for actual_row, expected_row in zip(native.compact, expected, strict=True):
        for actual, target in zip(actual_row, expected_row, strict=True):
            np.testing.assert_allclose(actual, target, rtol=rtol, atol=atol, equal_nan=True)
    evidence.update(parity=parity, rtol=rtol, atol=atol, discrete_probability_results_exact=True,
                    all_selected_roots_compared=True, successful_scope_statuses_exact=True)
    return evidence


def verify_threadpools(info):
    if any(isinstance(pool.get("num_threads"), int) and pool["num_threads"] > 1 for pool in info):
        raise AssertionError("a mature numerical library is using more than one effective thread")
