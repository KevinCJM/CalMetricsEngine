"""Isolated exact-decorator extraction of four current FIRP NJIT functions.

Importing this preparation module does not import NumPy/Numba or the upstream
runtime. The root-run driver calls load() before either observation interval.
Only the extracted /tmp module is imported; its cache remains beside that file.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
from pathlib import Path
import sys
import time

SOURCE = Path("/Users/chenjunming/Desktop/KevinGit/CppCalAST/FundInvestmentResearchPlatform/backend/scenario_stress/numba_kernels.py")
SOURCE_SHA = "bb53056653d697c698dab4ac5e716d96dbaec9071157d755c3fbef32e9831b79"
NAMES = ("monte_carlo_projection_kernel", "returns_to_nav_kernel",
         "quantile_sorted_kernel", "fan_statistics_kernel")
ALIASES = ("_F64_1D", "_F64_2D", "_F64_3D", "_U8_1D")
DESTINATION = Path(__file__).resolve().parent / "production_signature_kernels.py"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tree_digest(node):
    return hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


def load():
    payload = SOURCE.read_bytes()
    if hashlib.sha256(payload).hexdigest() != SOURCE_SHA:
        raise RuntimeError("exact production-signature upstream source changed")
    tree = ast.parse(payload)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in NAMES]
    aliases = [node for node in tree.body if isinstance(node, ast.Assign) and
               len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and
               node.targets[0].id in ALIASES]
    if (tuple(node.name for node in functions) != NAMES or
            tuple(node.targets[0].id for node in aliases) != ALIASES):
        raise RuntimeError("production function/type dependency extraction changed")
    # No decorator, signature, annotation, arithmetic or inline-policy edit.
    text = ("# Root-run isolated exact FIRP AST snapshot; no production import.\n"
            "from __future__ import annotations\n"
            "import numpy as np\n"
            "from numba import njit, types\n\n" +
            "\n\n".join(ast.unparse(node) for node in (*aliases, *functions)) + "\n")
    generated = ast.parse(text)
    by_name = {node.name: node for node in generated.body if isinstance(node, ast.FunctionDef)}
    generated_aliases = {node.targets[0].id: node for node in generated.body
                        if isinstance(node, ast.Assign)}
    if (any(tree_digest(node) != tree_digest(by_name[node.name]) for node in functions) or
            any(tree_digest(node) != tree_digest(generated_aliases[node.targets[0].id]) for node in aliases)):
        raise RuntimeError("serialization changed the exact production AST")
    if DESTINATION.exists():
        if DESTINATION.read_text() != text:
            raise RuntimeError("preserve frozen generated production baseline; extraction differs")
    else:
        with DESTINATION.open("x") as stream:
            stream.write(text)
    module_name = "cme_isolated_exact_production_signature_kernels"
    spec = importlib.util.spec_from_file_location(module_name, DESTINATION)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    started = time.perf_counter_ns()
    spec.loader.exec_module(module)
    load_ms = (time.perf_counter_ns() - started) / 1e6
    for name in NAMES:
        dispatcher = getattr(module, name)
        dispatcher.disable_compile()
        if len(dispatcher.signatures) != 1 or len(dispatcher.nopython_signatures) != 1 or dispatcher._can_compile:
            raise RuntimeError("expected one precompiled disabled production signature: " + name)
        if not dispatcher.targetoptions.get("nogil"):
            raise RuntimeError("production nogil policy lost: " + name)
    if module.quantile_sorted_kernel.targetoptions.get("inline") != "always":
        raise RuntimeError("production quantile inline=always policy lost")
    evidence = dict(upstream_path=str(SOURCE), upstream_sha256=SOURCE_SHA,
                    extraction_loader_sha256=digest(__file__), extracted_path=str(DESTINATION),
                    extracted_source_sha256=digest(DESTINATION),
                    complete_function_ast_sha256={node.name: tree_digest(node) for node in functions},
                    decorator_ast_sha256={node.name: tree_digest(ast.Module(body=node.decorator_list, type_ignores=[])) for node in functions},
                    type_alias_ast_sha256={node.targets[0].id: tree_digest(node) for node in aliases},
                    full_function_and_decorator_ast_identical=True, type_alias_ast_identical=True,
                    fixed_c_dtype_signatures_preserved=True, cache_and_nogil_preserved=True,
                    quantile_inline="always", production_runtime_imported=False,
                    extracted_module_load_and_eager_compilation_ms_excluded=load_ms,
                    compilation_policy="one explicit production signature per function, request-time compilation disabled",
                    cache_scope="generated /tmp module; no FIRP module import or cache write")
    return module, evidence
