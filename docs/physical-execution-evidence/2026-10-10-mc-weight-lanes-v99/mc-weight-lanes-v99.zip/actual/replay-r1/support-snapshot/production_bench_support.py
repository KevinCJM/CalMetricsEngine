"""Exact production-signature variant of the frozen complete-chain harness.

The historical seven files remain untouched. Their nonnumerical evidence and
complete-tuple orchestration helpers are reused; only the NJIT loader and the
shared physical input/view discipline differ for the formal baseline.
"""
from __future__ import annotations

import ast
import hashlib
import os
from pathlib import Path
import sys
from types import SimpleNamespace

import complete_bench_support as historical
import production_reference

HERE, ROOT = historical.HERE, historical.ROOT
SCOPE, EXCLUDED, CASES = historical.SCOPE, historical.EXCLUDED, historical.CASES
HEAP_HELPER_SHA = historical.HEAP_HELPER_SHA
HEAP_PROBE_SOURCE_SHA = historical.HEAP_PROBE_SOURCE_SHA
HEAP_PROBE_BINARY_SHA = historical.HEAP_PROBE_BINARY_SHA
pin_threads, sha, load_module = historical.pin_threads, historical.sha, historical.load_module
verified_identity = historical.verified_identity
input_fingerprints, common_input_bytes = historical.input_fingerprints, historical.common_input_bytes
flattened_arrays, payload_hash = historical.flattened_arrays, historical.payload_hash
independent, verify_threadpools = historical.independent, historical.verify_threadpools
HISTORICAL_SUPPORT_SHA = "5653592ad84febd205a772e79c9d8c25accfe4b35f8ff44bff58095bf7d85c1d"


class ProductionReferenceRunner(historical.ReferenceRunner):
    def __init__(self, module):
        # Alias only the dispatcher for the unchanged historical orchestration;
        # the extracted original function itself keeps its production name.
        super().__init__(SimpleNamespace(frozen_one=module.monte_carlo_projection_kernel), module)
        self.module = module

    def signatures(self):
        return {name: dict(signatures=[str(value) for value in getattr(self.module, name).signatures],
                           nopython_signatures=[str(value) for value in getattr(self.module, name).nopython_signatures],
                           can_compile=getattr(self.module, name)._can_compile,
                           targetoptions=dict(getattr(self.module, name).targetoptions))
                for name in production_reference.NAMES}


def load_runtime(install, manifest):
    pin_threads()
    install = Path(install).resolve()
    if not (install / "calmetrics_engine").is_dir():
        raise RuntimeError("selected installed package is missing")
    sys.path.insert(0, str(install))
    cache_directory = HERE / "production-numba-cache"
    cache_directory.mkdir(exist_ok=True)
    os.environ["NUMBA_CACHE_DIR"] = str(cache_directory)
    import numpy as np
    import numba
    import calmetrics_engine as package

    numba.set_num_threads(1)
    identity = verified_identity(manifest, install, package)
    if (sha(historical.__file__) != HISTORICAL_SUPPORT_SHA or
            sha(HERE / "compact-consumer.py") != historical.CONSUMER_SHA or
            sha(ROOT / "tests/test_mc_compact_graph.py") != historical.TEMPLATE_SHA):
        raise RuntimeError("compact consumer/template identity changed")
    module, extraction = production_reference.load()
    consumer = load_module("compact_production_consumer", HERE / "compact-consumer.py")
    reference = ProductionReferenceRunner(module)
    evidence = dict(extraction, support_sha256=sha(__file__),
                    historical_support_sha256=HISTORICAL_SUPPORT_SHA,
                    compact_consumer_sha256=historical.CONSUMER_SHA,
                    compact_template_sha256=historical.TEMPLATE_SHA,
                    orchestration_run_ast_sha256=hashlib.sha256(ast.dump(
                        next(function for node in ast.parse(Path(historical.__file__).read_text()).body
                             if isinstance(node, ast.ClassDef) and node.name == "ReferenceRunner"
                             for function in node.body if isinstance(function, ast.FunctionDef) and function.name == "run"),
                        include_attributes=False).encode()).hexdigest(),
                    runtime_versions=dict(numpy=np.__version__, numba=numba.__version__, python=sys.version),
                    reference_compilation="exact production explicit dtype/C signatures/cache/nogil/quantile inline=always",
                    numba_cache_directory=str(cache_directory),
                    input_contract="one writable physical base per input for production NJIT; shared readonly views for C++")
    return np, package, consumer, reference, identity, evidence


def inputs(np, case, seed=17):
    data = historical.inputs(np, case, seed)
    for name in ("x", "beta", "initial", "weights", "available"):
        data[name].flags.writeable = True
    return data


class NativeRunner(historical.NativeRunner):
    def __init__(self, module, data, mode="ordinary", order="C"):
        import numpy as np

        native_data = dict(data)
        shared = {}
        for name in ("x", "beta", "initial", "weights"):
            base = data[name]
            if not base.flags.c_contiguous or not base.flags.writeable or base.dtype != np.float64:
                raise AssertionError("production NJIT requires writable C float64 physical input: " + name)
            view = base.view()
            view.flags.writeable = False
            if (not np.shares_memory(base, view) or base.ctypes.data != view.ctypes.data or
                    base.shape != view.shape or base.strides != view.strides):
                raise AssertionError("C++ readonly input view must share the exact physical buffer: " + name)
            native_data[name] = view
            shared[name] = dict(shape=list(base.shape), strides=list(base.strides), dtype=str(base.dtype),
                                nbytes=base.nbytes, base_writable=True, native_view_readonly=True,
                                exact_buffer_shared=True, extra_payload_copy_bytes=0)
        super().__init__(module, native_data, mode, order)
        self.shared_inputs = shared

    def verify_inputs(self):
        if any(value.flags.writeable for value in self.consumer.inputs.values()):
            raise AssertionError("C++ input view lost readonly boundary")
        return super().verify_inputs()


def native_audit(np, runner, result):
    evidence = historical.native_audit(np, runner, result)
    evidence.update(production_signature_baseline=True, physical_shared_inputs=runner.shared_inputs)
    return evidence


def compare_complete(np, runner, native, expected, rtol=2e-12, atol=2e-13):
    evidence = historical.compare_complete(np, runner, native, expected, rtol, atol)
    evidence.update(production_signature_baseline=True, physical_shared_inputs=runner.shared_inputs)
    return evidence
