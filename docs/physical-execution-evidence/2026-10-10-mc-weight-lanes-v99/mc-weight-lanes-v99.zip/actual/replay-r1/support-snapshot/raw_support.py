"""Read-only raw fixed-tape replay. This is not the source owned/RNG request."""
from pathlib import Path
import os,sys,copy,hashlib
BASE=Path('/private/tmp/calmetrics-mc-owned-current-v98-20261010/support');sys.path.insert(0,str(BASE))
import production_bench_support as old
import transform_reference
SCOPE='successful_readonly_raw_fixed_tape_transform_projection_nav_fan_14stats_samples_contributions'
EXCLUDED=['old_random_stream','covariance_root_generation','coverage','limits','JSON_packaging','platform_stage_ordered_first_fault']
CASES=old.CASES

def load_runtime(install,manifest):
    np,package,consumer,reference,identity,frozen=old.load_runtime(install,manifest)
    transform,tevidence=transform_reference.load()
    frozen=dict(frozen,transform=tevidence)
    return np,package,consumer,reference,transform,identity,frozen

def inputs(np,case,student,seed=17):
    data=old.inputs(np,case,seed);data['x']/=.01
    rng=np.random.default_rng(seed+1003);f=data['factors']
    data['root']=np.eye(f)*.009+rng.normal(0,.0003,(f,f))
    data['means']=rng.normal(0,.0001,f)
    data['chi']=rng.chisquare(5.,(data['steps'],data['paths'])) if student else np.ones((1,1),np.float64)
    data['student']=bool(student);data['df']=5.
    return data

def raw_spec(template,data):
    s=template.compact_spec(data['steps'],data['paths'],data['assets'],data['combinations'],source='tape')
    variables=s['variables'];variables.pop('x')
    d=template.declaration
    variables.update(raw=d('tensor',['time','path','component'],['T','P','F']),
        root=d('matrix',['factor','component'],['F','F']),means=d('vector',['factor'],['F']))
    prefix={'rotated':'affine_contract(raw,transpose(root),0)'}
    if data['student']:
        variables.update(chi3=d('tensor',['time','path','factor'],['T','P','1']),df=d('scalar'))
        prefix['scale']='divide(sqrt(divide(subtract(df,2),df)),sqrt(divide(chi3,df)))'
        prefix['x']='add(broadcast_like(means,rotated),multiply(rotated,broadcast_like(scale,rotated)))'
    else:prefix['x']='add(broadcast_like(means,rotated),multiply(rotated,1))'
    s['root_bindings']=[dict(prefix,**b) for b in s['root_bindings']]
    return s

def fingerprint(data):
    return {n:hashlib.sha256(memoryview(data[n]).cast('B')).hexdigest() for n in ['x','root','means','chi','beta','initial','weights','available']}

def common_bytes(data):return sum(data[n].nbytes for n in ['x','root','means','chi','beta','initial','weights','available'])

class RawConsumer:
    def __init__(self,module,data,order='C'):
        import numpy as np
        self.template=module.load_template(old.ROOT/'tests/test_mc_compact_graph.py',expected_sha=old.historical.TEMPLATE_SHA)
        self.spec=raw_spec(self.template,data)
        self.inputs={}
        for n,k in [('raw','x'),('root','root'),('means','means'),('beta','beta'),('initial','initial')]:
            view=data[k].view();view.flags.writeable=False;assert view.ctypes.data==data[k].ctypes.data
            self.inputs[n]=view
        for c,w in enumerate(data['weights']):v=w.view();v.flags.writeable=False;self.inputs['w'+str(c)]=v
        if data['student']:
            v=data['chi'].reshape(data['steps'],data['paths'],1).view();v.flags.writeable=False
            assert np.shares_memory(v,data['chi']);self.inputs['chi3']=v
        self.inputs.update(self.template.probability_inputs())
        self.graph=self.template.compile_compact(self.spec,order=order)
        self.parameters={'n0':1.,'target':.1}
        if data['student']:self.parameters['df']=data['df']
        self.starts=np.array([0],np.int64);self.ends=np.array([data['steps']],np.int64)
        self.scheduler=module.AdaptiveScheduler(cpu_budget=1)
    def close(self):self.scheduler.close()

class NativeRunner:
    def __init__(self,module,data,mode='ordinary',order='C'):
        self.data=data;self.mode=mode;self.consumer=RawConsumer(module,data,order)
        self.consumer.compact_arrays=module.CompactConsumer.compact_arrays.__get__(self.consumer)
        self.plan=self.consumer.scheduler.plan(self.consumer.graph,self.consumer.inputs,self.consumer.starts,self.consumer.ends)
        self.prepared=self.consumer.scheduler.prepare_execution(self.consumer.graph,self.consumer.inputs,self.consumer.starts,self.consumer.ends,
                parameters=self.consumer.parameters,plan=self.plan) if mode=='prepared_snapshot' else None
        self.input_hashes={n:hashlib.sha256(memoryview(v).cast('B')).hexdigest() for n,v in self.consumer.inputs.items()}
    def run(self):
        c=self.consumer
        raw=self.prepared.run_snapshot() if self.prepared else c.scheduler.execute(c.graph,c.inputs,c.starts,c.ends,parameters=c.parameters)
        return old.historical.NativeBundle(raw,c.compact_arrays(raw))
    def close(self):self.prepared=None;self.consumer.close()
    def verify_inputs(self):
        actual={n:hashlib.sha256(memoryview(v).cast('B')).hexdigest() for n,v in self.consumer.inputs.items()}
        assert actual==self.input_hashes;return actual

class ReferenceRunner:
    def __init__(self,reference,transform):self.reference=reference;self.transform=transform
    def run(self,data):
        # Immutable replay needs a new writable tape per call. The source RNG
        # already creates an owned writable tape and does NOT pay this extra copy.
        working=data['x'].copy(order='C')
        self.transform.transform_factor_draws_kernel(working,data['chi'],data['root'],data['means'],int(data['student']),data['df'])
        changed=dict(data,x=working)
        return self.reference.run(changed)
    def signatures(self):
        return dict(self.reference.signatures(),transform=dict(signatures=[str(s) for s in self.transform.transform_factor_draws_kernel.signatures],can_compile=self.transform.transform_factor_draws_kernel._can_compile))

def compare(np,native,result,expected,data):
    targets={};fields=native.consumer.template.METRIC_FIELDS
    for c,(fan,metrics,samples,contributions) in enumerate(expected):
        targets.update({f'fan_{c}':fan,f'samples_{c}':samples})
        targets.update({f'stat_{c}_{n}':np.asarray(v) for n,v in zip(fields,metrics,strict=True)})
        targets.update({f'contribution_{c}_{a}':np.asarray(v) for a,v in enumerate(contributions)})
    named=result.raw.named_outputs
    assert set(named)==set(targets)
    for n,e in targets.items():
        o=named[n];v=o.values[0];assert v.shape==e.shape and v.dtype==e.dtype
        np.testing.assert_array_equal(o.root_statuses,[0])
        if 'loss_probability' in n or 'target_hit_probability' in n:np.testing.assert_array_equal(v,e)
        else:np.testing.assert_allclose(v,e,rtol=2e-12,atol=2e-13)
    audit=result.raw.audit
    for k in ['python_fallback','python_operator_calls','request_time_compilation','python_worker_callbacks']:assert not audit[k]
    assert audit['cpu_budget']==audit['thread_count']==audit['process_count']==1
    assert audit['engine_build_id']==os.environ['CME_MC_EXPECT_BUILD_ID']
    return dict(all_named_roots_compared=len(targets),exact_discrete_probabilities=True,float_rtol=2e-12,float_atol=2e-13,
        audit=audit,plan=native.plan.metadata(),readonly_inputs_unchanged=native.verify_inputs())
